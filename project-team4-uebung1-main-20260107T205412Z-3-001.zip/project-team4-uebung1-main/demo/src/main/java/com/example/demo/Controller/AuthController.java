package com.example.demo.Controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import com.example.demo.Model.Projekt.Projekt;
import com.example.demo.Model.User.MyAppUser;
import com.example.demo.Model.User.MyAppUserRepository;

@RestController
public class AuthController {

    @Autowired
    private MyAppUserRepository userRepository;

    @GetMapping("/auth/status")
    public Map<String, Object> getAuthStatus(@RequestParam(required = false) String projectid) {
        boolean isAuthenticated = false;
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        if (authentication != null
                && authentication.isAuthenticated()
                && !(authentication instanceof AnonymousAuthenticationToken)) {

            String username = authentication.getName();
            MyAppUser user = userRepository.findByUsername(username).orElse(null);

            if (user != null) {
                if (projectid == null || projectid.isEmpty()) {
                    isAuthenticated = true;
                } else {
                    try {
                        Long projectIdLong = Long.parseLong(projectid);
                            List<Projekt> projekte = user.getProjekt();
                                for (Projekt projekt : projekte) {
                                    if (projekt.getId().equals(projectIdLong)) {
                                        isAuthenticated = true;
                                        break;
                                    }
                                }
                    } catch (NumberFormatException e) {
                    }
                }
            }
        }

        Map<String, Object> response = new HashMap<>();
        response.put("isAuthenticated", isAuthenticated);
        return response;
    }
}