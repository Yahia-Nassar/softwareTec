package com.example.demo.Controller.CommentController.CommentController;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Model.Tasks.Comment;
import com.example.demo.Model.Tasks.CommentRepository;

@RestController
@RequestMapping("/comments")
public class CommentGetController {

    @Autowired
    private CommentRepository commentRepository;

    @GetMapping("/{id}")
    public Optional<Comment> getComment(@PathVariable Long id) {
        return commentRepository.findById(id);
    }

    @GetMapping
    public List<Comment> getAllComments() {
        return commentRepository.findAll();
    }
}