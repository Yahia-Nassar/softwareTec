package com.example.demo.Controller.CommentController.CommentController;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Model.Tasks.Comment;
import com.example.demo.Model.Tasks.CommentRepository;

@RestController
@RequestMapping("/comments")
public class CommentSaveController {

    @Autowired
    private CommentRepository commentRepository;

    @PostMapping(consumes = "application/json")
    public Comment createComment(@RequestBody Comment comment) {
        return commentRepository.save(comment);
    }
}