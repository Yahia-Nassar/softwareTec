package com.example.demo.Controller;

import com.example.demo.Model.User.MyAppUserService;
import com.example.demo.Model.User.EmailService;
import com.example.demo.Model.User.MyAppUser;
import com.example.demo.Model.User.MyAppUserRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import java.util.UUID;

@Controller
public class ForgotPasswordController {

    //Trace: "ForgotPasswordController" in https://git.informatik.uni-rostock.de/softwaretechnik-ws-2024-25/uebung1/team4/abgabedokument-sprint-4/-/blob/5f41bdf8c1770d6e342ab58ddca00db73b12077c/Klassendiagramm_Sprint_4.svg

    @Autowired
    private MyAppUserService userService;

    @Autowired
    private EmailService emailService;

    @Autowired
    private MyAppUserRepository userRepository;

    @PostMapping("/forgot-password")
    public String processForgotPassword(@RequestParam("email") String email) {
        MyAppUser user = userService.findByEmail(email);
        if (user != null) {
            String token = generateResetToken();
            user.setResetToken(token);
            userRepository.save(user);
            
            sendResetEmail(user, token);
            return "redirect:/login?resetEmailSent";
        }
        return "redirect:/forgot-password?error";
    }

    private String generateResetToken() {
        return UUID.randomUUID().toString();
    }

    private void sendResetEmail(MyAppUser user, String token) {
        String subject = "Password Reset Request";
        String resetLink = "http://localhost:8080/reset-password?token=" + token;
        String message = String.format(
            "Hello %s,\n\nPlease click the link below to reset your password:\n%s\n\nBest regards,\nYour Team",
            user.getUsername(),
            resetLink
        );
        emailService.sendEmail(user.getEmail(), subject, message);
    }
}