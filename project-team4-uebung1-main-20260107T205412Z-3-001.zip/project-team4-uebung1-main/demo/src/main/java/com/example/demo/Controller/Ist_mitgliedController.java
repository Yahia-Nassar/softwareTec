package com.example.demo.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.ResponseEntity;


import java.util.List;
import java.util.Optional;
//import java.util.function.Function;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import com.example.demo.Model.Ist_mitglied.ist_mitglied;
//import com.Softwaretechnik.Projekt.Repository.ist_mitgliedRepository;
import com.example.demo.Model.Ist_mitglied.ist_mitgliedService;
import com.example.demo.Model.Nutzer.NutzerService;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import com.example.demo.Model.Team.*;
import com.example.demo.Model.Nutzer.*;


//import org.springframework.dao.InvalidDataAccessApiUsageException;


@RestController
@RequestMapping("/api/istmitglied")
public class Ist_mitgliedController {
    //Trace: https://git.informatik.uni-rostock.de/softwaretechnik-ws-2024-25/uebung1/team4/abgabedokument-sprint/-/blob/main/Komponentendiagramm_-_Teamstruktur.jpg?ref_type=heads

    @Autowired
    private ist_mitgliedService ist_mitgliedService;

    @Autowired
    private NutzerService nutzerService;

    @Autowired TeamService teamService;

    @PostMapping("/create")
    public ResponseEntity<ist_mitglied> createIst_mitglied(@RequestBody ist_mitglied ist_mitglied){

        Nutzer nutzer = nutzerService.getNutzerById(ist_mitglied.getNutzer().getNutzer_id())
        .orElseThrow(()-> new ResourceNotFoundException("Nutzer nicht gefunden"));

        Team team = teamService.getTeamById(ist_mitglied.getTeam().getTeam_id())
        .orElseThrow(()-> new ResourceNotFoundException("Prev_Team nicht gefunden"));

        ist_mitglied.setNutzer(nutzer);
        ist_mitglied.setTeam(team);


        ist_mitglied savedIst_mitglied = ist_mitgliedService.saveIst_mitglied(ist_mitglied);
        return new ResponseEntity<ist_mitglied>(savedIst_mitglied,HttpStatus.CREATED);
    }


    @PutMapping("/{id}")
    public ResponseEntity<ist_mitglied> updateIst_mitglied(@RequestBody ist_mitglied neuesIst_mitglied, @PathVariable Long id){
        Optional<ist_mitglied> optionalIst_mitglied = ist_mitgliedService.getIst_mitgliedById(id);
        if(optionalIst_mitglied.isPresent()){
            ist_mitglied ist_mitglied = optionalIst_mitglied.get();
            ist_mitglied.setRolle(neuesIst_mitglied.getRolle());
            ist_mitglied updatedIst_mitglied = ist_mitgliedService.saveIst_mitglied(ist_mitglied);
            return new ResponseEntity<>(updatedIst_mitglied,HttpStatus.OK);
        }
        else{
            ist_mitglied savedIst_mitglied = ist_mitgliedService.saveIst_mitglied(neuesIst_mitglied);
            return new ResponseEntity<>(savedIst_mitglied,HttpStatus.CREATED);
        }

    }    
        @GetMapping
        public List<ist_mitglied> getAllIst_mitglied(){
            return ist_mitgliedService.getAllIst_mitglied();
        }


        @GetMapping("{id}")
        public Optional<ist_mitglied> getIst_mitgliedById(@PathVariable Long id){
            return ist_mitgliedService.getIst_mitgliedById(id);
        }


        @DeleteMapping("/{id}")
        public void deleteIst_mitgliedById(@PathVariable Long id){
            ist_mitgliedService.deleteIst_mitgliedById(id);
        }
        
        




}
