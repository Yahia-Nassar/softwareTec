package com.example.demo.Controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Model.Meetings.Meeting;
import com.example.demo.Model.Meetings.MeetingRepository;
import com.example.demo.Model.Projekt.Projekt;
import com.example.demo.Model.Projekt.ProjektRepository;
import com.example.demo.Model.User.MyAppUser;
import com.example.demo.Model.User.MyAppUserRepository;

@RestController
public class MeetingController {

    //Trace: "MeetingController" in https://git.informatik.uni-rostock.de/softwaretechnik-ws-2024-25/uebung1/team4/abgabedokument-sprint-4/-/blob/5f41bdf8c1770d6e342ab58ddca00db73b12077c/Klassendiagramm_Sprint_4.svg
    
    @Autowired
    private MyAppUserRepository userRepository;    

    @Autowired
    private ProjektRepository projectRepository;

    @Autowired
    private MeetingRepository meetingRepository;

    @GetMapping("/getmeetings")
    public List<Meeting> getAllMeetings(@RequestParam String projectid) {
        Projekt projekt = projectRepository.findById(Long.parseLong(projectid)).orElse(null);

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();
        MyAppUser user = userRepository.findByUsername(username).orElseThrow(() -> new RuntimeException("User not found"));

        if (projekt != null) {
            List<Meeting> meetings = projekt.getMeetings();
            List<Meeting> result = new ArrayList<>();

            for (Meeting meeting : meetings) {
                if (meeting.getUsers().stream().anyMatch(u -> u.getId().equals(user.getId()))) {
                    result.add(meeting);
                }
            }

            return result;

        } else {;
            return null;
        }
    }

    @PostMapping("/deletemeeting")
    public List<Meeting> deleteMeetingByPost(@RequestParam String projectid, @RequestParam Long meetingId) {
    System.out.println("Delete Meeting request received: projectid=" + projectid + ", meetingId=" + meetingId);

    Projekt projekt = projectRepository.findById(Long.parseLong(projectid))
            .orElseThrow(() -> new RuntimeException("Project not found"));

    System.out.println("Project found: " + projekt.getName());

    Meeting meeting = meetingRepository.findById(meetingId)
            .orElseThrow(() -> new RuntimeException("Meeting not found"));

    meeting.getUsers().forEach(user -> {
        user.getMeetings().remove(meeting);
    });
    meeting.getUsers().clear();

    userRepository.saveAll(meeting.getUsers());

    meetingRepository.save(meeting);

    meetingRepository.deleteById(meetingId);
    System.out.println("Meeting deleted: " + meetingId);

    projekt = projectRepository.findById(Long.parseLong(projectid))
            .orElseThrow(() -> new RuntimeException("Project not found"));

    return projekt.getMeetings();
}


@PutMapping("/editmeeting")
public List<Meeting> editMeeting(@RequestBody Meeting updatedMeeting, @RequestParam String projectid) {
    Meeting existingMeeting = meetingRepository.findById(updatedMeeting.getMeetingId())
        .orElseThrow(() -> new RuntimeException("Meeting not found"));

    existingMeeting.setDescription(updatedMeeting.getDescription());
    existingMeeting.setDate(updatedMeeting.getDate());
    existingMeeting.setTime(updatedMeeting.getTime());

    meetingRepository.save(existingMeeting);

    Projekt projekt = projectRepository.findById(Long.parseLong(projectid))
        .orElseThrow(() -> new RuntimeException("Project not found"));

    return projekt.getMeetings();
}

    @PostMapping(value="/createmeeting", consumes = "application/json")
    public List<Meeting> createMeetings(@RequestBody List<Meeting> meetings, @RequestParam String projectid) {
        List<Meeting> savedMeetings = new ArrayList<>();

    
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();
        MyAppUser user = userRepository.findByUsername(username).orElseThrow(() -> new RuntimeException("User not found"));
        
        Projekt projekt = projectRepository.findById(Long.parseLong(projectid)).orElseThrow(() -> new RuntimeException("Project not found"));
            for (Meeting met : meetings) {
                Optional<Meeting> existingmet = meetingRepository.findByDescription(met.getDescription()); // irgendwann zu Id oder ähnlich ändern...

                if (existingmet.isPresent()) {
                    Meeting updatedmet = existingmet.get();
                    updatedmet.setDescription(met.getDescription());
                    updatedmet.setProject(met.getProject());
                    updatedmet.setUsers(met.getUsers());
        
                    savedMeetings.add(meetingRepository.save(updatedmet));
                }
                else {
                    met.setProject(projekt);

                    Meeting savedMeeting = meetingRepository.save(met);

                    List<MyAppUser> userList = new ArrayList<>();
                    userList.add(user);

                    user.getMeetings().add(met);
                    userRepository.save(user);

                    savedMeetings.add(savedMeeting);
                }
            }

        return savedMeetings;
    }

}
