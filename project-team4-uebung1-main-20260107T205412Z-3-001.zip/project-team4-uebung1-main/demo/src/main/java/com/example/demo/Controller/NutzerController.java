package com.example.demo.Controller;

import com.example.demo.Model.Nutzer.Nutzer;
import com.example.demo.Model.Nutzer.NutzerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.ResponseEntity;


import java.util.List;
import java.util.Optional;
//import java.util.function.Function;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;


@RestController//markiert die Klasse als Spring MVC Controller-Klasse der REStful Webservices bereistelt. Kombiniert die annotationen @Controller und @ResponseBody. @ResponseBody stellt sicher, dass der Rückgabewert der Methoden des Controller im JSON Format direkt im HTTP-Anwortkörper zurückgegeben werden kann.
@RequestMapping("/api/nutzer")//legt den URL-Zugriffspfad für diese Controller Klasse fest.
public class NutzerController {
    //Trace: https://git.informatik.uni-rostock.de/softwaretechnik-ws-2024-25/uebung1/team4/abgabedokument-sprint/-/blob/main/Komponentendiagramm_-_Teamstruktur.jpg?ref_type=heads

    @Autowired//Annotation weist Spring Boot an automatisch die Dependency Injection für die Variable zu übernehmen.
    private NutzerService nutzerService;




    @PostMapping("/create")//die Post-mapping Methode zum erstellen von Datensätzen in der Datenbank
    public ResponseEntity<Nutzer> createNutzer(@RequestBody Nutzer nutzer){//mit Response Entity Klasse lassen sich HTTP-anworten mit zusätzlicher Metainformation (wie hier der Statuscode) angeben.
        Nutzer savedNutzer = nutzerService.saveNutzer(nutzer);
        return new ResponseEntity<Nutzer>(savedNutzer, HttpStatus.CREATED);
    }

    

    @PutMapping("/{id}")//Put-Mapping Methode zum Aktualisieren von Datensätzen in der Datenbank. Im URL Pfad wird letztlich auch die id in form einer ganzzahl angegeben, um anzugeben welcher datensatz verändert werden soll. Und zusätzlich auch noch der neue Nutzer im Json Format, damit der alte Nutzer mit den neuen Daten aktualisiert werden kann.
    public ResponseEntity<Nutzer> updateNutzer(@RequestBody Nutzer neuerNutzer, @PathVariable Long id){
     Optional<Nutzer> optionalNutzer = nutzerService.getNutzerById(id);//Objekt der Optional Klasse...falls kein mitglied mit der id gefunden wird enthält OptionalMitglied ein leeres Optional 
     if(optionalNutzer.isPresent()){//isPresent schaut, ob die Variable ein Mitglied enthält
        Nutzer nutzer = optionalNutzer.get();//die Methode get() in der Optional-Klasse liefert den Wert zurück, der im Optional-Objekt enthalten ist, wenn diesre Wert vorhanden ist. Fals keiner vorhanden ist, wirft sie eine NoSuchElementException
        nutzer.setVorname(neuerNutzer.getVorname());
        nutzer.setNachname(neuerNutzer.getNachname());
        Nutzer updatedNutzer = nutzerService.saveNutzer(nutzer);
        return new ResponseEntity<>(updatedNutzer,HttpStatus.OK);
     }
     else{
        Nutzer savedNutzer = nutzerService.saveNutzer(neuerNutzer);
        return new ResponseEntity<>(savedNutzer, HttpStatus.CREATED);
     }
    }

    @GetMapping
    public List<Nutzer> getAllNutzer(){
        return nutzerService.getAllNutzer();
    }

    @GetMapping("/{id}")
    public Optional<Nutzer> getNutzerById(@PathVariable Long id){
        return nutzerService.getNutzerById(id);
    }

    @DeleteMapping("/{id}")
    public void deleteNutzer(@PathVariable Long id){
        nutzerService.deleteNutzer(id);
    }
    
}
