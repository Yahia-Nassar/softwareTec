package com.example.demo.Controller;


import com.example.demo.Model.Projekt.Projekt;
import com.example.demo.Model.Projekt.ProjektRepository;
import com.example.demo.Model.Role.Role;
import com.example.demo.Model.Role.RoleId;
import com.example.demo.Model.Role.RoleRepository;
import com.example.demo.Model.Sprints.Sprint;
import com.example.demo.Model.User.MyAppUser;
import com.example.demo.Model.User.MyAppUserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
public class ProfileController {

    @Autowired
    private MyAppUserRepository userRepository;

    @Autowired
    private RoleRepository roleRepository;

    @Autowired
    private ProjektRepository projektRepository;

    @PostMapping("/editrole")
    public ResponseEntity<Void> editRole(@RequestBody Role newRole, @RequestParam String projectid) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth == null || !auth.isAuthenticated() || auth instanceof AnonymousAuthenticationToken)
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();

        Optional<Projekt> projektOpt = projektRepository.findById(Long.parseLong(projectid));
        if (!projektOpt.isPresent())
            return ResponseEntity.notFound().build();

        MyAppUser user = userRepository.findByUsername(auth.getName()).orElse(null);
        if (user == null)
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();

        RoleId pk      = new RoleId(user.getId(), projektOpt.get().getId());
        Role role      = roleRepository.findById(pk).orElseGet(() -> {
            Role r = new Role();
            r.setId(pk);
            return r;
        });

        role.setRole(newRole.getRole());
        roleRepository.save(role);

        return ResponseEntity.ok().build();
    }

    @GetMapping("/getUsername")
    public ResponseEntity<String> getUsername() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        if (authentication == null
                || !authentication.isAuthenticated()
                || authentication instanceof AnonymousAuthenticationToken) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }

        String username = authentication.getName();
        MyAppUser user   = userRepository.findByUsername(username).orElse(null);

        if (user == null) {
            return ResponseEntity.notFound().build();
        }

        return ResponseEntity.ok(user.getUsername());
    }

    @GetMapping("/getUserEmail")
    public ResponseEntity<String> getUserEmail() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        if (authentication == null
                || !authentication.isAuthenticated()
                || authentication instanceof AnonymousAuthenticationToken) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }

        String username = authentication.getName();
        MyAppUser user   = userRepository.findByUsername(username).orElse(null);

        if (user == null) {
            return ResponseEntity.notFound().build();
        }

        return ResponseEntity.ok(user.getEmail());
    }

    @GetMapping("/getmeetingnotification")
    public ResponseEntity<Integer> getmeeting_notification(@RequestParam String projectid) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        Optional<Projekt>  projekt = projektRepository.findById(Long.parseLong(projectid));

        if (authentication != null){
            String username = authentication.getName();
            MyAppUser user = userRepository.findByUsername(username).orElse(null);

            if (user != null){
                Role role =  roleRepository.findByIdProjektIdAndIdUserId(projekt.get().getId(), user.getId());

                return ResponseEntity.ok(role.getMeeting_notification());
            }
        }

        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
    }

    @GetMapping("/gettasknotification")
    public ResponseEntity<Integer> gettask_notification(@RequestParam String projectid) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        Optional<Projekt>  projekt = projektRepository.findById(Long.parseLong(projectid));

        if (authentication != null){
            String username = authentication.getName();
            MyAppUser user = userRepository.findByUsername(username).orElse(null);

            if (user != null){
                Role role =  roleRepository.findByIdProjektIdAndIdUserId(projekt.get().getId(), user.getId());

                return ResponseEntity.ok(role.getTask_notification());
            }
        }

        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
    }

    @PostMapping("/editmeetingnotification")
    public ResponseEntity<Void> editMeetingNotification(@RequestBody Integer newNotification,
                                                        @RequestParam String projectid) {

        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth == null || !auth.isAuthenticated() || auth instanceof AnonymousAuthenticationToken)
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();

        Long projId   = Long.parseLong(projectid);
        MyAppUser user = userRepository.findByUsername(auth.getName()).orElse(null);
        if (user == null) return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();

        RoleId pk   = new RoleId(user.getId(), projId);
        Role role   = roleRepository.findById(pk).orElse(null);
        if (role == null) return ResponseEntity.notFound().build();   // Datensatz MUSS existieren

        role.setMeeting_notification(newNotification);
        roleRepository.save(role);   // merge ⇒ UPDATE

        return ResponseEntity.ok().build();
    }

    @PostMapping("/edittasknotification")
    public ResponseEntity<Void> editTaskNotification(@RequestBody Integer newNotification,
                                                     @RequestParam String projectid) {

        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth == null || !auth.isAuthenticated() || auth instanceof AnonymousAuthenticationToken)
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();

        Long projId   = Long.parseLong(projectid);
        MyAppUser user = userRepository.findByUsername(auth.getName()).orElse(null);
        if (user == null) return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();

        RoleId pk   = new RoleId(user.getId(), projId);
        Role role   = roleRepository.findById(pk).orElse(null);
        if (role == null) return ResponseEntity.notFound().build();

        role.setTask_notification(newNotification);
        roleRepository.save(role);

        return ResponseEntity.ok().build();
    }

}
