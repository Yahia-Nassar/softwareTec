package com.example.demo.Controller;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import com.example.demo.Model.User.MyAppUserDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Model.Projekt.Projekt;
import com.example.demo.Model.Projekt.ProjektDto;
import com.example.demo.Model.Projekt.ProjektRepository;
import com.example.demo.Model.Sprints.Sprint;
import com.example.demo.Model.Sprints.SprintRepository;
import com.example.demo.Model.Tasks.Task;
import com.example.demo.Model.Tasks.TaskDto;
import com.example.demo.Model.Tasks.TaskRepository;
import com.example.demo.Model.UserStories.UserStory;
import com.example.demo.Model.UserStories.UserStoryDto;
import com.example.demo.Model.UserStories.UserStoryRepository;
import com.example.demo.Model.Tasks.statustask;
import com.example.demo.Model.User.MyAppUser;
import com.example.demo.Model.User.MyAppUserRepository;
import com.example.demo.Model.UserStories.statususerstory;

@RestController
public class ProjektController {

    //Trace: "ProjectController" in https://git.informatik.uni-rostock.de/softwaretechnik-ws-2024-25/uebung1/team4/abgabedokument-sprint-4/-/blob/5f41bdf8c1770d6e342ab58ddca00db73b12077c/Klassendiagramm_Sprint_4.svg

    @Autowired
    private ProjektRepository projektRepository;

    @Autowired
    private TaskRepository taskRepository;

    @Autowired
    private UserStoryRepository userStoryRepository;

    @Autowired
    private MyAppUserRepository userRepository;  
    
    @Autowired
    private SprintRepository sprintRepository;

    @GetMapping("/gettasks")
    public List<TaskDto> getAllTasks(@RequestParam String projectid) {
        Projekt projekt = projektRepository.findById(Long.parseLong(projectid)).orElse(null);
        if (projekt != null) {
            List<Task> tasks =  projekt.getTasks();
            for (Task ts : tasks) {
                ts.setTemp(false);
            }

            return tasks.stream()
                        .map(task -> {
                            TaskDto dto = new TaskDto();
                            dto.setId(task.getid());
                            dto.setTitle(task.getTitle());
                            dto.setDescription(task.getDescription());
                            dto.setStatus(task.getStatus());
                            dto.setPriority(task.getPriority());
                            dto.setCreatedAt(task.getCreatedAt());
                            dto.setEstTime(task.getEstTime());
                            dto.setActTime(task.getActTime());
                            dto.setInProgressAt(task.getInProgressAt());
                            dto.setCompletedAt(task.getCompletedAt());
                            dto.setSprint(task.getSprint());
                            dto.setUserStory(task.getUserStory());
                            dto.setUserInfos(task.getUsers() == null ? Collections.emptyList() : task.getUsers()
                                                                                                    .stream().map(user -> {
                                                                                                        Map<String, Object> userMap = new HashMap<>();
                                                                                                        userMap.put("id", user.getId());
                                                                                                        userMap.put("username", user.getUsername());
                                                                                                        return userMap;
                                                                                                    }).collect(Collectors.toList()));
                            return dto;
                        })
                        .collect(Collectors.toList());
        } else {
            return null;
        }
    }

    @GetMapping("/getusertasks")
    public List<TaskDto> getAllUserTasks(@RequestParam String projectid) {

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        
            if (authentication != null 
                    && authentication.isAuthenticated() 
                    && !(authentication instanceof AnonymousAuthenticationToken)) {
        
                String username = authentication.getName();
                MyAppUser user = userRepository.findByUsername(username).orElse(null);
                List<Task> tasks = user.getTasks();

                return tasks.stream()
                            .map(task -> {
                                TaskDto dto = new TaskDto();
                                dto.setId(task.getid());
                                dto.setTitle(task.getTitle());
                                dto.setDescription(task.getDescription());
                                dto.setStatus(task.getStatus());
                                dto.setPriority(task.getPriority());
                                dto.setCreatedAt(task.getCreatedAt());
                                dto.setEstTime(task.getEstTime());
                                dto.setActTime(task.getActTime());
                                dto.setInProgressAt(task.getInProgressAt());
                                dto.setCompletedAt(task.getCompletedAt());
                                dto.setSprint(task.getSprint());
                                dto.setUserStory(task.getUserStory());
                                dto.setUserInfos(
                                    task.getUsers() == null
                                        ? Collections.emptyList()
                                        : task.getUsers().stream().map(us -> {
                                            Map<String, Object> userMap = new HashMap<>();
                                            userMap.put("id", us.getId());
                                            userMap.put("username", us.getUsername());
                                            return userMap;
                                        }).collect(Collectors.toList())
                                );
                                return dto;
                            })
                            .collect(Collectors.toList());
                                }
        else{
            return null;
        }
    }

    @GetMapping("/getsprinttasks")
public List<TaskDto> getTasksByProjectAndSprint(@RequestParam String projectid,
                                                @RequestParam String sprintid) {
    Projekt projekt = projektRepository.findById(Long.parseLong(projectid)).orElse(null);
    Sprint sprint = sprintRepository.findById(Long.parseLong(sprintid)).orElse(null);

    if (projekt == null || sprint == null) {
        return Collections.emptyList();
    }

    List<Task> tasks = taskRepository.findByProjektAndSprint(projekt, sprint);
    System.out.println(tasks);
    return tasks.stream()
        .map(task -> {
            TaskDto dto = new TaskDto();
            dto.setId(task.getid());
            dto.setTitle(task.getTitle());
            dto.setDescription(task.getDescription());
            dto.setStatus(task.getStatus());
            dto.setCreatedAt(task.getCreatedAt());
            dto.setPriority(task.getPriority());
            dto.setEstTime(task.getEstTime());
            dto.setActTime(task.getActTime());
            dto.setInProgressAt(task.getInProgressAt());
            dto.setCompletedAt(task.getCompletedAt());
            dto.setSprint(task.getSprint());
            dto.setUserStory(task.getUserStory());
            dto.setUserInfos(
                task.getUsers() == null
                    ? Collections.emptyList()
                    : task.getUsers().stream().map(user -> {
                        Map<String, Object> userMap = new HashMap<>();
                        userMap.put("id", user.getId());
                        userMap.put("username", user.getUsername());
                        return userMap;
                    }).collect(Collectors.toList())
            );
            return dto;
        })
        .collect(Collectors.toList());
}

@GetMapping("/getusersprinttasks")
public List<TaskDto> getTasksByUserAndSprint(@RequestParam String projectid,
                                             @RequestParam String sprintid) {
    Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

    if (authentication != null
            && authentication.isAuthenticated()
            && !(authentication instanceof AnonymousAuthenticationToken)) {

        String username = authentication.getName();
        MyAppUser user = userRepository.findByUsername(username).orElse(null);
        Projekt projekt = projektRepository.findById(Long.parseLong(projectid)).orElse(null);
        Sprint sprint = sprintRepository.findById(Long.parseLong(sprintid)).orElse(null);

        if (user == null || projekt == null || sprint == null) {
            return Collections.emptyList();
        }

        List<Task> tasks = user.getTasks().stream()
            .filter(task -> projekt.equals(task.getProjekt()) && sprint.equals(task.getSprint()))
            .collect(Collectors.toList());

        return tasks.stream()
            .map(task -> {
                TaskDto dto = new TaskDto();
                dto.setId(task.getid());
                dto.setTitle(task.getTitle());
                dto.setDescription(task.getDescription());
                dto.setStatus(task.getStatus());
                dto.setCreatedAt(task.getCreatedAt());
                dto.setPriority(task.getPriority());
                dto.setEstTime(task.getEstTime());
                dto.setActTime(task.getActTime());
                dto.setInProgressAt(task.getInProgressAt());
                dto.setCompletedAt(task.getCompletedAt());
                dto.setSprint(task.getSprint());
                dto.setUserStory(task.getUserStory());
                dto.setUserInfos(
                    task.getUsers() == null
                        ? Collections.emptyList()
                        : task.getUsers().stream().map(userInTask -> {
                            Map<String, Object> userMap = new HashMap<>();
                            userMap.put("id", userInTask.getId());
                            userMap.put("username", userInTask.getUsername());
                            return userMap;
                        }).collect(Collectors.toList())
                );
                return dto;
            })
            .collect(Collectors.toList());
    } else {
        return Collections.emptyList();
    }
}

    @GetMapping("/getuserstories")
    public List<UserStoryDto> getAllUserStories(@RequestParam String projectid) {
        Projekt projekt = projektRepository.findById(Long.parseLong(projectid)).orElse(null);
        if (projekt != null) {
            List<UserStory> stories = projekt.getUserStories();
            for (UserStory us : stories) {
                us.setTemp(false);
            }
            return stories.stream()
                    .map(us -> {
                        UserStoryDto dto = new UserStoryDto();
                        dto.setId(us.getId());
                        dto.setTemp(us.isTemp());
                        dto.setTitle(us.getTitle());
                        dto.setStatus(us.getstatus());
                        dto.setDescription(us.getDescription());
                        dto.setAcceptanceCriteria(us.getAcceptanceCriteria());
                        dto.setPriority(us.getPriority());
                        dto.setSprint(us.getSprint() != null ? us.getSprint().getSprintid() : null);
                        //dto.setTaskIds(
                        //    us.getTasks() != null
                        //            ? us.getTasks().stream().map(Task::getid).collect(Collectors.toList())
                        //            : Collections.emptyList()
                        //);
                        return dto;
                    })
                    .collect(Collectors.toList());
        } else {
            return null;
        }
    }

    @GetMapping("/getsprintUS")
    public List<UserStoryDto> getUSByProjectAndSprint(@RequestParam String projectid, @RequestParam String sprintid) {
        Projekt projekt = projektRepository.findById(Long.parseLong(projectid)).orElse(null);
        Sprint sprint = sprintRepository.findById(Long.parseLong(sprintid)).orElse(null);
        if (projekt != null && sprint != null) {
            return userStoryRepository.findByProjektAndSprint(projekt, sprint).stream()
                    .map(us -> {
                        UserStoryDto dto = new UserStoryDto();
                        dto.setId(us.getId());
                        dto.setTemp(us.isTemp());
                        dto.setTitle(us.getTitle());
                        dto.setStatus(us.getstatus());
                        dto.setDescription(us.getDescription());
                        dto.setAcceptanceCriteria(us.getAcceptanceCriteria());
                        dto.setPriority(us.getPriority());
                        dto.setSprint(us.getSprint() != null ? us.getSprint().getSprintid() : null);
                        //dto.setTaskIds(
                        //    us.getTasks() != null
                        //            ? us.getTasks().stream().map(Task::getid).collect(Collectors.toList())
                        //            : Collections.emptyList()
                        //);
                        return dto;
                    })
                    .collect(Collectors.toList());
        } else {
            return new ArrayList<>();
        }
    }


    @PostMapping(value = "/saveTasks", consumes = "application/json")
    public List<Task> createTasks(@RequestBody List<Task> tasks, @RequestParam String projectid) {
        List<Task> savedTasks = new ArrayList<>();
        
        Optional<Projekt> projekt = projektRepository.findById(Long.parseLong(projectid));

        if (projekt.isPresent()){
        
            for (Task ts : tasks) {
                Optional<Task> existingTask = taskRepository.findById(ts.getid());

                Long sprintId = ts.getSprint().getSprintid();
                Sprint existingSprint = sprintRepository.findById(sprintId).orElse(null);
                    

                if (ts.isTemp()) {
                    ts.setid(null);
                }
                
                if (ts.getStatus()==statustask.BURNBARREL){
                    if (existingTask.isPresent()){
                        taskRepository.delete(existingTask.get());
                    }
                }
                else if (existingTask.isPresent()) {
                    Task updateTask = existingTask.get();
                    updateTask.setStatus(ts.getStatus());
                    updateTask.setTitle(ts.getTitle());
                    updateTask.setPriority(ts.getPriority());
                    updateTask.setEstTime(ts.getEstTime());
                    updateTask.setActTime(ts.getActTime());
                    updateTask.setInProgressAt(ts.getInProgressAt());
                    updateTask.setCompletedAt(ts.getCompletedAt());
                    updateTask.setDescription(ts.getDescription());
                    updateTask.updateComments(ts.getComments());
                    updateTask.setSprint(existingSprint);

                    List<MyAppUser> resolvedUsers = new ArrayList<>();
                    if (ts.getUsers() != null) {
                        for (MyAppUser partialUser : ts.getUsers()) {
                            MyAppUser existingUser = userRepository.findById(partialUser.getId()).orElse(null);
                            if (existingUser != null) {
                                resolvedUsers.add(existingUser);
                            }
                        }
                    }
                    updateTask.setUsers(resolvedUsers);

                    System.out.println(updateTask);
                    if (ts.getUserStory() != null) {
                        Long userStoryId = ts.getUserStory().getId();
                        UserStory existingUs = userStoryRepository.findById(userStoryId).orElse(null);
                        System.out.println(existingUs);
                        updateTask.setUserStory(existingUs);
                    }
                    updateTask.setProjekt(projekt.get());
                    savedTasks.add(taskRepository.save(updateTask));
                }
                else if (ts.getStatus()==statustask.BURNBARREL){
                    taskRepository.delete(ts);
                }
                else {
                    ts.setProjekt(projekt.get());
                    ts.setSprint(existingSprint);
                    ts.setCreatedAt(ts.getCreatedAt());

                    List<MyAppUser> resolvedUsers = new ArrayList<>();
                    if (ts.getUsers() != null) {
                        for (MyAppUser partialUser : ts.getUsers()) {
                            MyAppUser existingUser = userRepository.findById(partialUser.getId()).orElse(null);
                            if (existingUser != null) {
                                resolvedUsers.add(existingUser);
                            }
                        }
                    }
                    ts.setUsers(resolvedUsers);

                    if (ts.getUserStory() != null) {
                        Long userStoryId = ts.getUserStory().getId();
                        UserStory existingUs = userStoryRepository.findById(userStoryId).orElse(null);
                        System.out.println(existingUs);
                        ts.setUserStory(existingUs);
                    }
            
                    savedTasks.add(taskRepository.save(ts));
                }
            }

            //projekt.get().Tasks(savedTasks);
            //projektRepository.save(projekt.get());

    }

        return new ArrayList<>();
    }

    @PostMapping(value = "/saveUSCards", consumes = "application/json")
public List<UserStory> createUS(@RequestBody List<UserStory> userStories, @RequestParam String projectid) {
    List<UserStory> savedUserStories = new ArrayList<>();
    Optional<Projekt> projekt = projektRepository.findById(Long.parseLong(projectid));

    if (projekt.isPresent()) {
        for (UserStory us : userStories) {

            if (us.isTemp()) {
                us.setId(null);
            }

            Optional<UserStory> existingUS = (us.getId() == null) 
                ? Optional.empty()
                : userStoryRepository.findById(us.getId());

            Long sprintId = us.getSprint().getSprintid();
            Sprint existingSprint = sprintRepository.findById(sprintId).orElse(null);

            if (us.getstatus() == statususerstory.BURNBARREL) {
                existingUS.ifPresent(userStoryRepository::delete);
            }
            else if (existingUS.isPresent()) {
                UserStory updateUS = existingUS.get();
                updateUS.setTitle(us.getTitle());
                updateUS.setDescription(us.getDescription());
                updateUS.setAcceptanceCriteria(us.getAcceptanceCriteria());
                updateUS.setPriority(us.getPriority());
                updateUS.setstatus(us.getstatus());
                if (existingSprint.getSprintid().equals(us.getSprint().getSprintid())){
                    List<Task> tasks = taskRepository.findByUserStory(existingUS.get());
                    for (Task ts : tasks){
                        ts.setSprint(existingSprint);
                    }
                }
                updateUS.setSprint(existingSprint);
                updateUS.setProjekt(projekt.get());
                //updateUS.setTasks(us.getTasks());

                savedUserStories.add(userStoryRepository.save(updateUS));
            }
            else {
                us.setProjekt(projekt.get());
                us.setSprint(existingSprint);
                savedUserStories.add(userStoryRepository.save(us));
            }
        }

        //List<UserStory> projektUserStories = projekt.get().getUserStories();
        //projektUserStories.clear();
        //projektUserStories.addAll(savedUserStories);
    }

    return new ArrayList<>();
}

    @GetMapping("/getprojects")
    public List<ProjektDto> getAllProjects() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();
        MyAppUser user = userRepository.findByUsername(username).orElseThrow(() -> new RuntimeException("User not found"));

        List<Projekt> projekte = user.getProjekt();

        return projekte.stream().map(ProjektDto::fromEntity).collect(Collectors.toList());
    }
        
        @PostMapping("/createproject")
        public Projekt createProject(@RequestBody Projekt projekt) {
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        
            if (authentication != null 
                    && authentication.isAuthenticated() 
                    && !(authentication instanceof AnonymousAuthenticationToken)) {
        
                String username = authentication.getName();
                MyAppUser user = userRepository.findByUsername(username).orElse(null);
        
                if (user != null) {
                    projekt.getUsers().add(user);
                    user.getProjekt().add(projekt);
                    
                    Projekt savedProjekt = projektRepository.save(projekt);
                    userRepository.save(user);

                    Sprint sprint = new Sprint();
                    sprint.setName("Backlog");
                    sprint.setSprintid((long) 1);
                    sprint.setProjekt(savedProjekt);
                    sprintRepository.save(sprint);
                    
                    System.out.println("Created project: " + savedProjekt.getName() + 
                                     " for user: " + user.getUsername());
                    return savedProjekt;
                }
            }
            return null;
        }


    @GetMapping("/getprojectusers")
    public List<MyAppUserDto> getProjectUsers(@RequestParam String projectid) {
        List<MyAppUser> users = userRepository.findAllByProjektId(Long.parseLong(projectid));
        return users.stream().map(user -> {
            MyAppUserDto dto = new MyAppUserDto();
            dto.setId(user.getId());
            dto.setUsername(user.getUsername());
            dto.setEmail(user.getEmail());
            dto.setEnabled(user.getEnabled());
            dto.setVerificationToken(user.getVerificationToken());
            dto.setResetToken(user.getResetToken());
            return dto;
        }).collect(Collectors.toList());
    }
        
}
    