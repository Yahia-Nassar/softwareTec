package com.example.demo.Controller;

import java.util.Optional;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.ui.Model;

import com.example.demo.Model.User.MyAppUser;
import com.example.demo.Model.User.MyAppUserRepository;
import com.example.demo.util.event.OnRegistrationCompleteEvent;

@Controller
public class RegistrationController {
    
    //Trace: "RegistrationController" in https://git.informatik.uni-rostock.de/softwaretechnik-ws-2024-25/uebung1/team4/abgabedokument-sprint-4/-/blob/5f41bdf8c1770d6e342ab58ddca00db73b12077c/Klassendiagramm_Sprint_4.svg

    @Autowired
    private MyAppUserRepository myAppUserRepository;
    
    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private ApplicationEventPublisher eventPublisher;
    
    @PostMapping(value = "/req/signup", consumes = "application/json")
    public ResponseEntity<String> createUser(@RequestBody MyAppUser user){
        Optional<MyAppUser> existingUser = myAppUserRepository.findByEmail(user.getEmail());
    if (existingUser.isPresent()) {
        return ResponseEntity
                .status(HttpStatus.CONFLICT)
                .body("Account with this e-mail already exists.");
    }
    
        user.setPassword(passwordEncoder.encode(user.getPassword()));
        user.setEnabled(false);
        myAppUserRepository.save(user);

        String token = UUID.randomUUID().toString();
        user.setVerificationToken(token);
        myAppUserRepository.save(user);


        eventPublisher.publishEvent(new OnRegistrationCompleteEvent(user));

        return ResponseEntity.ok("redirect:/verify-email");
    }

    public String validateVerificationToken(String token) {
        MyAppUser user = myAppUserRepository.findByVerificationToken(token).orElse(null);
        if (user == null) {
            return "invalid";
        }

        user.setEnabled(true);
        myAppUserRepository.save(user);
        return "valid";
    }

    @GetMapping("/verify-email")
    public String verifyEmail(@RequestParam("token") String token, Model model) {
        String result = validateVerificationToken(token);
        if (result.equals("valid")) {
            model.addAttribute("message", "You're verified!");
        } else {
            model.addAttribute("message", "Invalid verification token.");
        }
        return "verify-email";
    }
}
