package com.example.demo.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.example.demo.Model.User.MyAppUser;
import com.example.demo.Model.User.MyAppUserRepository;
import com.example.demo.Model.User.MyAppUserService;


@Controller
public class ResetPasswordController {

    //Trace: "ResetPasswordController" in https://git.informatik.uni-rostock.de/softwaretechnik-ws-2024-25/uebung1/team4/abgabedokument-sprint-4/-/blob/5f41bdf8c1770d6e342ab58ddca00db73b12077c/Klassendiagramm_Sprint_4.svg

    @Autowired
    private MyAppUserService userService;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private MyAppUserRepository myAppUserRepository;

    @GetMapping("/reset-password")
    public String showResetPasswordForm(@RequestParam("token") String token, Model model) {
        MyAppUser user = userService.findByResetToken(token);
        if (user != null) {
            model.addAttribute("token", token);
            return "resetPassword";
        }
        return "redirect:/req/signup";
    }

    @PostMapping(value = "/reset-password", consumes = "application/json")
    public String createUser(@RequestBody MyAppUser user){
        //System.out.println("User created");
        user.setPassword(passwordEncoder.encode(user.getPassword()));

        MyAppUser dbuser = userService.findByResetToken(user.getResetToken());

        user.setId(dbuser.getId());
        user.setEmail(dbuser.getEmail());
        user.setVerificationToken(dbuser.getVerificationToken());
        user.setUsername(dbuser.getUsername());
        user.setEnabled(dbuser.getEnabled());
        user.setProjekt(dbuser.getProjekt());
        user.setMeetings(dbuser.getMeetings());
        user.setTasks(dbuser.getTasks());


        myAppUserRepository.save(user);

        return "redirect:/login";
    }
}
