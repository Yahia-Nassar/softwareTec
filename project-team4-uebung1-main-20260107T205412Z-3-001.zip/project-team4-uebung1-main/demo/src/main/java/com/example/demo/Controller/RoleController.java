package com.example.demo.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Model.Projekt.Projekt;
import com.example.demo.Model.Projekt.ProjektRepository;
import com.example.demo.Model.Role.Role;
import com.example.demo.Model.Role.RoleEnum;
import com.example.demo.Model.Role.RoleRepository;
import com.example.demo.Model.User.MyAppUser;
import com.example.demo.Model.User.MyAppUserRepository;

@RestController
public class RoleController {

    @Autowired
    private MyAppUserRepository userRepository;

    @Autowired
    private ProjektRepository projektRepository;

    @Autowired
    private RoleRepository roleRepository;

    @GetMapping("/getRole")
    public RoleEnum getRole(@RequestParam String projectid) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();
        MyAppUser user = userRepository.findByUsername(username).orElseThrow(() -> new RuntimeException("User not found"));

        Projekt project = projektRepository.findById(Long.parseLong(projectid)).orElseThrow(() -> new RuntimeException("Project not found"));

        Role role = roleRepository.findByIdProjektIdAndIdUserId(project.getId(), user.getId());

        if (role != null) {
            return role.getRole();
        } else {
            return null;
        }
    }
}
