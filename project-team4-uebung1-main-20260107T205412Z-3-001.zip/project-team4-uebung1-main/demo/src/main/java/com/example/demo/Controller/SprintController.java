package com.example.demo.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Model.Projekt.Projekt;
import com.example.demo.Model.Projekt.ProjektRepository;
import com.example.demo.Model.Sprints.Sprint;
import com.example.demo.Model.Sprints.SprintRepository;
import com.example.demo.Model.UserStories.UserStory;
import com.example.demo.Model.UserStories.UserStoryRepository;

// Trace: "SprintController" in https://git.informatik.uni-rostock.de/softwaretechnik-ws-2024-25/uebung1/team4/abgabedokument-sprint-4/-/blob/5f41bdf8c1770d6e342ab58ddca00db73b12077c/Klassendiagramm_Sprint_4.svg

@RestController
public class SprintController {
    @Autowired
    private UserStoryRepository userStoryRepository;

    @Autowired
    private SprintRepository sprintRepository;

    @Autowired
    private ProjektRepository projektRepository;   

    @GetMapping("/getsprints")
    public List<Sprint> getSprints(@RequestParam String projectId){
        return sprintRepository.findByProjekt_Id(Long.parseLong(projectId));
    }

    @PostMapping("/createSprint")
    public Sprint createSprint(@RequestBody Sprint sprint, @RequestParam String projectId){
        Projekt project = projektRepository.findById(Long.parseLong(projectId)).orElse(null);

        sprint.setProjekt(project);
        
        Long idx = sprintRepository.findMaxSprintid() + 1;
        sprint.setSprintid(idx);

        return sprintRepository.save(sprint);
    }

@PostMapping("/deleteSprint")
public ResponseEntity<?> deleteSprint(@RequestParam String sprintId) {
    Sprint backlog = sprintRepository.findById(1L)
        .orElseThrow(() -> new RuntimeException("Backlog Sprint not found"));

    List<UserStory> userStories = userStoryRepository.findBySprint_Sprintid(Long.parseLong(sprintId));

    for (UserStory us : userStories) {
        us.setSprint(backlog);
    }
    userStoryRepository.saveAll(userStories);

    sprintRepository.deleteById(Long.parseLong(sprintId));

    return ResponseEntity.ok("Sprint deleted and UserStories moved to backlog");
}

@PutMapping("/editSprint")
public Sprint editSprint(
    @RequestParam String projectId,
    @RequestBody Sprint updatedSprint
) {
    Sprint existingSprint = sprintRepository.findById(updatedSprint.getSprintid())
        .orElseThrow(() -> new RuntimeException("Sprint nicht gefunden"));

    existingSprint.setName(updatedSprint.getName());
    existingSprint.setStartDate(updatedSprint.getStartDate());

    sprintRepository.save(existingSprint);

    return sprintRepository.findById(existingSprint.getSprintid()).orElse(null);
}
}