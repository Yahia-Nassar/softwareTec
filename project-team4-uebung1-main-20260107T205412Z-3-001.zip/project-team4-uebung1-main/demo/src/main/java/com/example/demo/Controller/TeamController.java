package com.example.demo.Controller;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import com.example.demo.Model.User.MyAppUserDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Model.Projekt.Projekt;
import com.example.demo.Model.Projekt.ProjektDto;
import com.example.demo.Model.Projekt.ProjektRepository;
import com.example.demo.Model.Role.Role;
import com.example.demo.Model.Role.RoleRepository;
import com.example.demo.Model.Sprints.Sprint;
import com.example.demo.Model.Sprints.SprintRepository;
import com.example.demo.Model.Tasks.Task;
import com.example.demo.Model.Tasks.TaskDto;
import com.example.demo.Model.Tasks.TaskRepository;
import com.example.demo.Model.UserStories.UserStory;
import com.example.demo.Model.UserStories.UserStoryDto;
import com.example.demo.Model.UserStories.UserStoryRepository;
import com.example.demo.Model.Tasks.statustask;
import com.example.demo.Model.User.MyAppUser;
import com.example.demo.Model.User.MyAppUserRepository;
import com.example.demo.Model.UserStories.statususerstory;

//Trace: "TeamController" in https://git.informatik.uni-rostock.de/softwaretechnik-ws-2024-25/uebung1/team4/abgabedokument-sprint-4/-/blob/5f41bdf8c1770d6e342ab58ddca00db73b12077c/Klassendiagramm_Sprint_4.svg

@RestController
public class TeamController {

    @Autowired
    private MyAppUserRepository userRepository;

    @Autowired
    private ProjektRepository projectRepository;

    @Autowired
    private RoleRepository roleRepository;

    @GetMapping("/getrolesinproject")
    public List<Map<String, Object>> getRolesInProject(@RequestParam("projectid") Long projectId) {
        List<Role> roles = roleRepository.findByIdProjektId(projectId);
    
        return roles.stream().map(role -> {
            Map<String, Object> map = new HashMap<>();
            map.put("userId", role.getId().getUserId());
            map.put("projectId", role.getId().getProjektId());
            map.put("role", role.getRole().name());
            return map;
        }).collect(Collectors.toList());
    }
    
    @GetMapping("/getusersinproject")
    public List<MyAppUserDto> getUsersInProject(@RequestParam("projectid") Long projectId) {
        Projekt project = projectRepository.findById(projectId)
                .orElseThrow(() -> new RuntimeException("Project not found"));
        List<MyAppUser> users = userRepository.findByProjectsContaining(project);
        return users.stream().map(user -> {
            MyAppUserDto dto = new MyAppUserDto();
            dto.setId(user.getId());
            dto.setUsername(user.getUsername());
            dto.setEmail(user.getEmail());
            dto.setEnabled(user.getEnabled());
            dto.setVerificationToken(user.getVerificationToken());
            dto.setResetToken(user.getResetToken());
            return dto;
        }).collect(Collectors.toList());
    }

    @PostMapping("/addusertoproject")
    public Map<String, String> addUserToProject(
            @RequestParam("projectid") Long projectId,
            @RequestBody Map<String, String> body
    ) {
        String username = body.get("username");
        if (username == null || username.isEmpty()) {
            return Collections.singletonMap("message", "Username cannot be empty");
        }

        MyAppUser user = userRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("No user found with username: " + username));

        Projekt project = projectRepository.findById(projectId)
                .orElseThrow(() -> new RuntimeException("Project not found"));

        if (user.getProjekt().contains(project)) {
            return Collections.singletonMap("message", "User is already in this project");
        }

        user.getProjekt().add(project);
        userRepository.save(user);

        return Collections.singletonMap("message", "User added successfully");
    }
    @PostMapping("/removeuserfromproject")
    public String removeUserFromProject(@RequestParam Long projectid, @RequestParam String username) {
        Optional<Projekt> projektOpt = projectRepository.findById(projectid);
        Optional<MyAppUser> userOpt = userRepository.findByUsername(username);

        if (projektOpt.isPresent() && userOpt.isPresent()) {
            Projekt projekt = projektOpt.get();
            MyAppUser user = userOpt.get();

            projekt.getUsers().remove(user);
            user.getProjekt().remove(projekt);

            projectRepository.save(projekt);
            userRepository.save(user);

            return "User removed from project";
        }
        return "Project or User not found";
    }

    @PostMapping("/leaveproject")
    public String leaveProject(@RequestParam Long projectid) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        if (authentication != null
                && authentication.isAuthenticated()
                && !(authentication instanceof AnonymousAuthenticationToken)) {

            String username = authentication.getName();
            Optional<MyAppUser> userOpt = userRepository.findByUsername(username);
            Optional<Projekt> projektOpt = projectRepository.findById(projectid);

            if (userOpt.isPresent() && projektOpt.isPresent()) {
                MyAppUser user = userOpt.get();
                Projekt projekt = projektOpt.get();

                projekt.getUsers().remove(user);
                user.getProjekt().remove(projekt);

                projectRepository.save(projekt);
                userRepository.save(user);

                return "User left the project";
            }
        }

        return "Failed to leave project";
    }

    @GetMapping("/currentuser")
    public Map<String, String> getCurrentUser() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication != null && authentication.isAuthenticated()
            && !(authentication instanceof AnonymousAuthenticationToken)) {
            String username = authentication.getName();
            return Collections.singletonMap("username", username);
        }
        return Collections.singletonMap("username", "");
    }

}
