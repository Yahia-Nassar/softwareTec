/*package com.example.demo.Controller;

import com.example.demo.Model.Team.Team;
import com.example.demo.Model.Team.TeamService;
//import com.Softwaretechnik.Projekt.Repository.TeamRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.http.HttpStatus;


@RestController//Gibt an, dass diese Klasse als Spring MVC Controller-Klasse die Http-Anfragen verarbeitet und im Json Format zurückgibt (kombiniert @Controller und @ResponseBody in einer Annotation)
@RequestMapping("/api/teams")//gibt den Http-Zugriffspfad an, der bei einer Anfrage angegeben werden muss
public class TeamController {
    //Trace: https://git.informatik.uni-rostock.de/softwaretechnik-ws-2024-25/uebung1/team4/abgabedokument-sprint/-/blob/main/Komponentendiagramm_-_Teamstruktur.jpg?ref_type=heads


@Autowired
private TeamService teamService;

@PostMapping("/create")
public Team createTeam (@RequestBody Team team){
    return teamService.saveTeam(team);
}

@PutMapping("{id}")
public ResponseEntity<Team> updateTeam(@PathVariable Long id, @RequestBody Team neuesTeam){
Optional<Team> optionalTeam = teamService.getTeamById(id);
if(optionalTeam.isPresent()){
    Team bestehendesTeam = optionalTeam.get();
    bestehendesTeam.setName(neuesTeam.getName());
    Team updatedTeam = teamService.saveTeam(bestehendesTeam);
    return new ResponseEntity<>(updatedTeam, HttpStatus.OK);
}
Team savedTeam = teamService.saveTeam(neuesTeam);
return new ResponseEntity<>(savedTeam, HttpStatus.CREATED);

}

@GetMapping
public List<Team> getAllTeams(){
    return teamService.getAllTeams();
}

@GetMapping("/{id}")//Diese Annotation bedeutet, dass die Methode eine GET-Anfrage an den Pfad /api/teams/{id} verarbeitet. Das id in der UR ist ein Platzhalter für eine dynamische Variable. Das bedeutet, dass die Methode Anfragen wie /api/teams/1 oder /api/teams/42 verarbeiten kann, wobei 1 und 43 die Werte für id sind. {id} ist der Platzhalter für die Variable id, die aus dem URL-fad extrahiert wird. Der tatsächliche Wert der id wird zur Laufzeit aus der Anfrage-URL entnommen und der Methode als Parameter übergeben.
public Optional<Team> getTeamById(@PathVariable Long id){// Die Annotation @PathVariable wird verwendet, um den Wert der dynamischn Variable aus der URL zu extrahieren und ihn an den Parameter der Methode zu binden.
    return teamService.getTeamById(id);
}


@DeleteMapping("/{id}")
public void deleteTeam(@PathVariable Long id){
    teamService.deleteTeam(id);
}

}*/



