package com.example.demo.Model.Ist_mitglied;

import com.example.demo.Model.Team.Team;
import com.example.demo.Model.Nutzer.Nutzer;

import jakarta.persistence.Entity;
import jakarta.persistence.GenerationType;
//import jakarta.persistence.IdClass;
import jakarta.persistence.GeneratedValue;
//import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
//import jakarta.persistence.OneToMany;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.Table;
//import jakarta.persistence.EmbeddedId;
import jakarta.persistence.UniqueConstraint;

@Entity
@Table(name = "ist_mitglied", uniqueConstraints = {@UniqueConstraint(columnNames = {"nutzer_id", "team_id"})})//ist_mitglied Tabelle repräsentiert die Zwischentabelle mit dem zusätzlichen Attribut Rolle, um zu wissen welcher Rolle der Nutzer in jeweiligen Prev_Team hat
public class ist_mitglied {
    //Trace: https://git.informatik.uni-rostock.de/softwaretechnik-ws-2024-25/uebung1/team4/abgabedokument-sprint/-/blob/main/Komponentendiagramm_-_Teamstruktur.jpg?ref_type=heads

    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Long id;
    

    
    private String rolle;


    @ManyToOne//zweimal @ManyToOne damit die Tabelle ist_mitglied jeweils die Fremschlüssel von Nutzer und Prev_Team enthält
    @JoinColumn(name="nutzer_id")
    private Nutzer nutzer;

    @ManyToOne
    @JoinColumn(name="team_id")
    private Team team;

    //anbei die getter und setter

    public String getRolle(){
        return this.rolle;
    }

    
    public void setRolle(String rolle){
        this.rolle=rolle;
    }

    public Nutzer getNutzer(){
        return this.nutzer;
    }

    public void setNutzer(Nutzer nutzer){
        this.nutzer=nutzer;
    }

    public Team getTeam(){
        return this.team;
    }

    public void setTeam(Team team){
        this.team=team;
    }




}
