package com.example.demo.Model.Ist_mitglied;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;



import java.util.List;
import java.util.Optional;

@Service
public class ist_mitgliedService {
    //Trace: https://git.informatik.uni-rostock.de/softwaretechnik-ws-2024-25/uebung1/team4/abgabedokument-sprint/-/blob/main/Komponentendiagramm_-_Teamstruktur.jpg?ref_type=heads


    @Autowired
    private ist_mitgliedRepository ist_mitgliedRepository;


    public ist_mitglied saveIst_mitglied(ist_mitglied ist_mitglied){
        return ist_mitgliedRepository.save(ist_mitglied);
    }

    public List<ist_mitglied> getAllIst_mitglied(){
        return ist_mitgliedRepository.findAll();
    }

    public Optional<ist_mitglied> getIst_mitgliedById(Long id){
        return ist_mitgliedRepository.findById(id);
    }

    public void deleteIst_mitgliedById(Long id){
        ist_mitgliedRepository.deleteById(id);
    }



}
