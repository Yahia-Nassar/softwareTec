package com.example.demo.Model.Meetings;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

import com.example.demo.Model.Projekt.Projekt;
import com.example.demo.Model.User.MyAppUser;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.ManyToOne;

@Entity

public class Meeting {

    //Trace: "Meeting" in https://git.informatik.uni-rostock.de/softwaretechnik-ws-2024-25/uebung1/team4/abgabedokument-sprint-4/-/blob/5f41bdf8c1770d6e342ab58ddca00db73b12077c/Klassendiagramm_Sprint_4.svg

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long meetingId;

    public Long getMeetingId() {
        return meetingId;
    }
    public void setMeetingId(Long meetingId) {
        this.meetingId = meetingId;
    }

    private String description;
    @JsonFormat(pattern="yyyy-MM-dd")
    private LocalDate date;
    public LocalDate getDate() {
        return date;
    }
    public void setDate(LocalDate date) {
        this.date = date;
    }

    @JsonFormat(pattern="HH:mm")
    private LocalTime time;

    public LocalTime getTime() {
        return time;
    }
    public void setTime(LocalTime time) {
        this.time = time;
    }
    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        this.description = description;
    }

    @ManyToMany(mappedBy = "meetings")
    @JsonIgnore
    private List<MyAppUser> users = new ArrayList<>();

    public List<MyAppUser> getUsers() {
        return users;
    }
    public void setUsers(List<MyAppUser> users) {
        this.users = users;
    }

    @ManyToOne
    @JsonIgnore
    private Projekt project;

    public Projekt getProject() {
        return project;
    }
    public void setProject(Projekt project) {
        this.project = project;
    }

}
