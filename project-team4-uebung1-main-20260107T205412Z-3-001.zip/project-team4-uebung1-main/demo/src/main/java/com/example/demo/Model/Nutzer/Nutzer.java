package com.example.demo.Model.Nutzer;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.OneToMany;
import com.example.demo.Model.Ist_mitglied.ist_mitglied;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity//Diese Annotation gibt an, dass es sich bei dieser Klasse um eine Entität in der  mit dieser Anwendung verbundenen Datenbank handelt
@Table(name = "nutzer")//Name der Tabelle in der Datenbank
public class Nutzer {
    //Trace: https://git.informatik.uni-rostock.de/softwaretechnik-ws-2024-25/uebung1/team4/abgabedokument-sprint/-/blob/main/Komponentendiagramm_-_Teamstruktur.jpg?ref_type=heads

    @Id//diese annotation gibt an, dass dieses Attribut der Primärschlüssel in der Datenbank für die Entität Nutzer ist
    @GeneratedValue(strategy = GenerationType.IDENTITY)//das weist Spring Boot an automatisch eine strategie für das erstellen von Primärschlüsselwerten für die Datenbank vorzunehmen und bei Hinzufügen von Datensätzen zu nutzen. Dafür habe ich bei meiner Postgresql Datenbank auch eine Sequenz für das Attribut nutzer_id (Primärschlüssel) in der Tabelle Nutzer eingerichtet. Auf diese Weise wird bei jedem Einfügen der nächste ganzzahlige Wert für nutzer_id verwendet.
    private Long nutzer_id;
    
    private String vorname;//andere Attribute von Nutzer
    private String nachname;

    
   @OneToMany(mappedBy="nutzer")
   @JsonIgnore
   private List<ist_mitglied> ist_mitglieder;

   




   //getter und setter für die Attribute
    public Long getNutzer_id(){
        return this.nutzer_id;
    }

    public String getVorname(){
        return this.vorname;
    }
    

    public String getNachname(){
        return this.nachname;
    }

    

    public void setNutzer_id(Long nutzer_id){
        this.nutzer_id = nutzer_id;
    }

    public void setVorname(String vorname){
        this.vorname = vorname;
    }


    public void setNachname(String nachname){
        this.nachname = nachname;
    }

   
    

}

