package com.example.demo.Model.Nutzer;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository//durch die Annotation wird ein Bean von "NutzerRepository" im IoC-Container automatisch von Spring Boot verwaltettet. Spring Bootwird angewiesen eine Instanz dieser Kllasse zu registrieren und zu verwalten.
public interface NutzerRepository extends JpaRepository<Nutzer,Long> {//das Jpa-Repository stellt die grundlegenden CRUD-Operationen bereit (CREATE, READ, UPDATE und DELETe) und das für die tabellen der jeweiligen entitäten, deshalb der generische Typ der Nutzer zusammen mit dem Typ des Primärschlüssels, in diesem Fall long
    //wenn man noch genauere Abfragen als nur die CRUD-Operationen benötigt kann man diese hier deefenieren
    //Trace: https://git.informatik.uni-rostock.de/softwaretechnik-ws-2024-25/uebung1/team4/abgabedokument-sprint/-/blob/main/Komponentendiagramm_-_Teamstruktur.jpg?ref_type=heads
}