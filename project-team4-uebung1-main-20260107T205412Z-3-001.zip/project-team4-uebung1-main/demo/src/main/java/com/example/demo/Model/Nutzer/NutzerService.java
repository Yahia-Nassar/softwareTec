package com.example.demo.Model.Nutzer;



import jakarta.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;


@Service
public class NutzerService {
    //Trace: https://git.informatik.uni-rostock.de/softwaretechnik-ws-2024-25/uebung1/team4/abgabedokument-sprint/-/blob/main/Komponentendiagramm_-_Teamstruktur.jpg?ref_type=heads

    @Autowired
    private NutzerRepository nutzerRepository;

   
    @Transactional
    public Nutzer saveNutzer(Nutzer mitglied){
        return nutzerRepository.save(mitglied);
    }


    @Transactional
    public List<Nutzer> getAllNutzer(){
        return nutzerRepository.findAll();
    }

    @Transactional
    public Optional<Nutzer> getNutzerById(Long id){
        return nutzerRepository.findById(id);
    }

    @Transactional
    public void deleteNutzer(Long id){
        nutzerRepository.deleteById(id);
    }
}
