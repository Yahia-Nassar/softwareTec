package com.example.demo.Model.Projekt;

import java.util.ArrayList;
import java.util.List;

import com.example.demo.Model.Meetings.Meeting;
import com.example.demo.Model.Tasks.Task;
import com.example.demo.Model.User.MyAppUser;
import com.example.demo.Model.UserStories.UserStory;
import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.OneToMany;

@Entity

public class Projekt {

    //Trace: "Projekt" in https://git.informatik.uni-rostock.de/softwaretechnik-ws-2024-25/uebung1/team4/abgabedokument-sprint-4/-/blob/5f41bdf8c1770d6e342ab58ddca00db73b12077c/Klassendiagramm_Sprint_4.svg

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    private String name;
    private String description;

    @ManyToMany(mappedBy = "projects")
    @JsonIgnore
    private List<MyAppUser> users = new ArrayList<>();

    public List<MyAppUser> getUsers() {
        return users;
    }
    public void setUsers(List<MyAppUser> users) {
        this.users = users;
    }
    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        this.description = description;
    }

    @OneToMany(mappedBy = "projekt", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Task> tasks = new ArrayList<>();
    
    
    /*public void updateTasks(List<Task> newTasks) {
        this.tasks.clear();
        this.tasks.addAll(newTasks);
    }*/
    

    public List<Task> getTasks() {
        return tasks;
    }
    public void setTasks(List<Task> tasks) {
        this.tasks = tasks;
    }

    @OneToMany(mappedBy = "projekt", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<UserStory> userStories = new ArrayList<>();
    
    public List<UserStory> getUserStories() {
        return userStories;
    }
    public void setUserStories(List<UserStory> userStories) {
        this.userStories = userStories;
    }

    @OneToMany(mappedBy = "project")
    private List<Meeting> meetings = new ArrayList<>();

    public List<Meeting> getMeetings() {
        return meetings;
    }
    public void setMeetings(List<Meeting> meetings) {
        this.meetings = meetings;
    }

}
