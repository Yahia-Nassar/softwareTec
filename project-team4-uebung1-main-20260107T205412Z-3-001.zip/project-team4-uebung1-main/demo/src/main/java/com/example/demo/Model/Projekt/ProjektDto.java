package com.example.demo.Model.Projekt;

import java.util.List;
import java.util.stream.Collectors;

import com.example.demo.Model.Tasks.Task;
import com.example.demo.Model.User.MyAppUser;
import com.example.demo.Model.UserStories.UserStory;

public class ProjektDto {

    private Long id;
    private String name;
    private String description;

    private List<Long> userIds;
    private List<Long> taskIds;
    private List<Long> userStoryIds;
    private List<Long> meetingIds;

    public ProjektDto() {
    }

    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        this.description = description;
    }

    public List<Long> getUserIds() {
        return userIds;
    }
    public void setUserIds(List<Long> userIds) {
        this.userIds = userIds;
    }

    public List<Long> getTaskIds() {
        return taskIds;
    }
    public void setTaskIds(List<Long> taskIds) {
        this.taskIds = taskIds;
    }

    public List<Long> getUserStoryIds() {
        return userStoryIds;
    }
    public void setUserStoryIds(List<Long> userStoryIds) {
        this.userStoryIds = userStoryIds;
    }

    public List<Long> getMeetingIds() {
        return meetingIds;
    }
    public void setMeetingIds(List<Long> meetingIds) {
        this.meetingIds = meetingIds;
    }

    public static ProjektDto fromEntity(Projekt projekt) {
        ProjektDto dto = new ProjektDto();
        dto.setId(projekt.getId());
        dto.setName(projekt.getName());
        dto.setDescription(projekt.getDescription());

        dto.setUserIds(
            projekt.getUsers().stream()
                .map(MyAppUser::getId)
                .collect(Collectors.toList())
        );
        dto.setTaskIds(
            projekt.getTasks().stream()
                .map(Task::getid)
                .collect(Collectors.toList())
        );
        dto.setUserStoryIds(
            projekt.getUserStories().stream()
                .map(UserStory::getId)
                .collect(Collectors.toList())
        );

    
        return dto;
    }
}
