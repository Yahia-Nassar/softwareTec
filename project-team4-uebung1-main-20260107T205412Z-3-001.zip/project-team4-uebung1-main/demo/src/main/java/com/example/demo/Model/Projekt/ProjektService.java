package com.example.demo.Model.Projekt;

public class ProjektService {
    private final ProjektRepository projektRepository;

    public ProjektService(ProjektRepository projektRepository) {
        this.projektRepository = projektRepository;
    }

    public void saveProjekt(Projekt projekt) {
        projektRepository.save(projekt);
    }

    public void deleteProjekt(Long id) {
        projektRepository.deleteById(id);
    }

    public Projekt getProjektById(Long id) {
        return projektRepository.findById(id).orElse(null);
    }
}
