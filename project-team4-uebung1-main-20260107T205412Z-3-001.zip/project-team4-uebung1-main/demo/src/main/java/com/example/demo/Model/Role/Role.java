package com.example.demo.Model.Role;

import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;

@Entity
public class Role {

    @EmbeddedId
    private RoleId id;

    private RoleEnum role;

    public RoleId getId() {
        return id;
    }

    public void setId(RoleId id) {
        this.id = id;
    }

    public RoleEnum getRole() {
        return role;
    }

    public void setRole(RoleEnum role) {
        this.role = role;
    }

    public void setMeeting_notification(int meeting_notification) {
        this.meeting_notification = meeting_notification;
    }

    public void setTask_notification(int task_notification) {
        this.task_notification = task_notification;
    }

    private int task_notification;

    public int getMeeting_notification() {
        return meeting_notification;
    }

    public int getTask_notification() {
        return task_notification;
    }

    private int meeting_notification;

}