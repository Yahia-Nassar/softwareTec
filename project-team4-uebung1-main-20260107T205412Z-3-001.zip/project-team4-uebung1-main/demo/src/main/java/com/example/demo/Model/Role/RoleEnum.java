package com.example.demo.Model.Role;

//Trace: "Enumeration Role" in https://git.informatik.uni-rostock.de/softwaretechnik-ws-2024-25/uebung1/team4/abgabedokument-sprint-4/-/blob/5f41bdf8c1770d6e342ab58ddca00db73b12077c/Klassendiagramm_Sprint_4.svg
public enum RoleEnum {
    PRODUCT_OWNER,
    DEVELOPER
}
