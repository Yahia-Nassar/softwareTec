package com.example.demo.Model.Role;

import java.io.Serializable;

import jakarta.persistence.Embeddable;

@Embeddable
public class RoleId implements Serializable {

    private Long userId;
    private Long projektId;

    public RoleId() {
    }

    public RoleId(Long userId, Long projektId) {
        this.userId = userId;
        this.projektId = projektId;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public Long getProjektId() {
        return projektId;
    }

    public void setProjektId(Long projektId) {
        this.projektId = projektId;
    }


}
