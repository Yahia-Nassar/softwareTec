package com.example.demo.Model.Role;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface RoleRepository extends JpaRepository<Role, RoleId> {
    Role findByIdProjektIdAndIdUserId(Long projektId, Long userId);
    List<Role> findByIdProjektId(Long projektId);
}
