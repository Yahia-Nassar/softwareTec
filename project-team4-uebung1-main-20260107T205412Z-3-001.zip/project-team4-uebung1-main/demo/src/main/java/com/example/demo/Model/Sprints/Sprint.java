package com.example.demo.Model.Sprints;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;

import java.util.List;

import com.example.demo.Model.Projekt.Projekt;
import com.example.demo.Model.UserStories.UserStory;
import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
//Trace: "Sprint" in https://git.informatik.uni-rostock.de/softwaretechnik-ws-2024-25/uebung1/team4/abgabedokument-sprint-4/-/blob/5f41bdf8c1770d6e342ab58ddca00db73b12077c/Klassendiagramm_Sprint_4.svg
public class Sprint {
    
    @Id
    private Long sprintid;
    
    private String name; 
    private String startDate; 
    private String endDate; 

    @OneToMany(mappedBy = "sprint")
    @JsonIgnore
    private List<UserStory> userStories;

    public List<UserStory> getUserStories() {
        return userStories;
    }

    public void setUserStories(List<UserStory> userStories) {
        this.userStories = userStories;
    }

    @ManyToOne
    @JoinColumn(name="projekt_id")
    @JsonIgnore
    private Projekt projekt;

    public Projekt getProjekt() {
        return projekt;
    }

    public void setProjekt(Projekt projekt) {
        this.projekt = projekt;
    }

    public Long getSprintid() {
        return sprintid;
    }

    public void setSprintid(Long sprintId) {
        this.sprintid = sprintId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }
}