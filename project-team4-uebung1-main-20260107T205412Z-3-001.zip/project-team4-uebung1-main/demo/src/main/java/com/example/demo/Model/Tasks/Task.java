package com.example.demo.Model.Tasks;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.example.demo.Model.Projekt.Projekt;
import com.example.demo.Model.Sprints.Sprint;
import com.example.demo.Model.User.MyAppUser;
import com.example.demo.Model.UserStories.UserStory;
import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.CascadeType;
import jakarta.persistence.ConstraintMode;
import jakarta.persistence.ForeignKey;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Transient;

@Entity
public class Task {
    
    //Trace: "Task" in https://git.informatik.uni-rostock.de/softwaretechnik-ws-2024-25/uebung1/team4/abgabedokument-sprint-4/-/blob/5f41bdf8c1770d6e342ab58ddca00db73b12077c/Klassendiagramm_Sprint_4.svg
    
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    private String title;

    private String description;

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Enumerated(EnumType.STRING)
    private statustask status;

    @Enumerated(EnumType.STRING)
    private priorityEnum priority;

    public LocalDate getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDate createdAt) {
        this.createdAt = createdAt;
    }

    private LocalDate createdAt;

    private int estTime; 
    private int actTime; 
    private LocalDate inProgressAt;
    public LocalDate getInProgressAt() {
        return inProgressAt;
    }

    public void setInProgressAt(LocalDate inProgressAt) {
        this.inProgressAt = inProgressAt;
    }

    private LocalDate completedAt;
   



    public LocalDate getCompletedAt() {
        return completedAt;
    }

    public void setCompletedAt(LocalDate completedAt) {
        this.completedAt = completedAt;
    }

    @OneToMany(mappedBy = "task", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Comment> comments = new ArrayList<>();
    
    @ManyToMany() 
    @JoinTable(
        name = "user_task",
        joinColumns = @JoinColumn(name = "task_id"), 
        inverseJoinColumns = @JoinColumn(name = "user_id")
    )
    private List<MyAppUser> users = new ArrayList<>();

    @ManyToOne(optional = true)
    @JoinColumn(
                name = "user_story_id", 
                referencedColumnName = "id",
                foreignKey = @ForeignKey(value = ConstraintMode.NO_CONSTRAINT)
                )
    private UserStory userStory;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "projekt_id")
    @JsonIgnore
    private Projekt projekt;

    @ManyToOne
    private Sprint sprint;

    public Sprint getSprint() {
        return sprint;
    }

    public void setSprint(Sprint sprint) {
        this.sprint = sprint;
    }

    public Projekt getProjekt() {
        return projekt;
    }
 public int getActTime() {
        return actTime;
    }

    public void setActTime(int actTime) {
        this.actTime = actTime;
    }
    public void setProjekt(Projekt projekt) {
        this.projekt = projekt;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public statustask getStatus() {
        return status;
    }

    public void setStatus(statustask status) {
        this.status = status;
    }

    public Long getid(){
        return id;
    }

    public void setid(Long id){
        this.id = id;
    }

    public priorityEnum getPriority() {
        return priority;
    }

    public void setPriority(priorityEnum priority) {
        this.priority = priority;
    }

    public int getEstTime() {
        return estTime;
    }

    public void setEstTime(int estTime) {
        this.estTime = estTime;
    }

    public List<Comment> getComments() {
        return comments;
    }

    public void updateComments(List<Comment> newComments) {
        this.comments.clear();
        this.comments.addAll(newComments);
    }    

    public List<MyAppUser> getUsers() {
        return users;
    }

    public void setUsers(List<MyAppUser> users) {
        this.users = users;
    }
    
    public UserStory getUserStory() {
        return userStory;
    }

    public void setUserStory(UserStory userStory) {
        this.userStory = userStory;
    }

    @Transient
    private boolean isTemp;

    public boolean isTemp() {
        return isTemp;
    }

    public void setTemp(boolean isTemp) {
        this.isTemp = isTemp;
    }
}