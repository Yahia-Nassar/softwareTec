package com.example.demo.Model.Tasks;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

import com.example.demo.Model.Sprints.Sprint;
import com.example.demo.Model.UserStories.UserStory;

import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import org.springframework.cglib.core.Local;

public class TaskDto {
    private Long id;
    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    private String title;
    public String getTitle() {
        return title;
    }
    public void setTitle(String title) {
        this.title = title;
    }
    private String description;

    public LocalDate getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDate createdAt) {
        this.createdAt = createdAt;
    }

    private LocalDate createdAt;

    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        this.description = description;
    }
    @Enumerated(EnumType.STRING)
    private statustask status;

    public statustask getStatus() {
        return status;
    }
    public void setStatus(statustask status) {
        this.status = status;
    }
    @Enumerated(EnumType.STRING)
    private priorityEnum priority;

    public priorityEnum getPriority() {
        return priority;
    }
    public void setPriority(priorityEnum priority) {
        this.priority = priority;
    }
    private int estTime; 
    public int getEstTime() {
        return estTime;
    }
    public void setEstTime(int estTime) {
        this.estTime = estTime;
    }
    private int actTime;
    
    public int getActTime() {
        return actTime;
    }
    public void setActTime(int actTime) {
        this.actTime = actTime;
    }
    public LocalDate inProgressAt;
    public LocalDate getInProgressAt() {
        return inProgressAt;
    }
    public void setInProgressAt(LocalDate inProgressAt) {
        this.inProgressAt = inProgressAt;
    }
    public LocalDate completedAt;
    public LocalDate getCompletedAt() {
        return completedAt;
    }
    public void setCompletedAt(LocalDate completedAt) {
        this.completedAt = completedAt;
    }
    
    private List<Map<String, Object>> userInfos;    

    public List<Map<String, Object>> getUserInfos() {
        return userInfos;
    }
    public void setUserInfos(List<Map<String, Object>> userInfos) {
        this.userInfos = userInfos;
    }
    private UserStory userStory;
    public UserStory getUserStory() {
        return userStory;
    }
    public void setUserStory(UserStory userStory) {
        this.userStory = userStory;
    }
    private Sprint sprint;
    public Sprint getSprint() {
        return sprint;
    }
    public void setSprint(Sprint sprint) {
        this.sprint = sprint;
    }

}
