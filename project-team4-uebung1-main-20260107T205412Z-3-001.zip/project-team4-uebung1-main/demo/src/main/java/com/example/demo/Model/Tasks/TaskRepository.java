package com.example.demo.Model.Tasks;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.Model.Projekt.Projekt;
import com.example.demo.Model.Sprints.Sprint;
import com.example.demo.Model.UserStories.UserStory;

@Repository
public interface TaskRepository extends JpaRepository<Task, Long>{
   
    //Trace: "TaskRepository" in https://git.informatik.uni-rostock.de/softwaretechnik-ws-2024-25/uebung1/team4/abgabedokument-sprint-4/-/blob/5f41bdf8c1770d6e342ab58ddca00db73b12077c/Klassendiagramm_Sprint_4.svg

    Optional<Task> findByTitle(String title);
    
    List<Task> findByUserStory(UserStory userStory);

    List<Task> findBySprint(Sprint sprint);

    List<Task> findByProjektAndSprint(Projekt projekt, Sprint sprint);
}