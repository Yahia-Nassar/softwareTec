package com.example.demo.Model.Tasks;

public enum priorityEnum {
    LOW,
    MEDIUM,
    HIGH
}
