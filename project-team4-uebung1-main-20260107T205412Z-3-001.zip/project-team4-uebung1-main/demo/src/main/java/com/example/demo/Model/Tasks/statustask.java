package com.example.demo.Model.Tasks;

public enum statustask {
    NOT_STARTED,          
    IN_PROGRESS,
    IN_TESTING,   
    COMPLETED,           
    BLOCKED,
    BURNBARREL,         
}