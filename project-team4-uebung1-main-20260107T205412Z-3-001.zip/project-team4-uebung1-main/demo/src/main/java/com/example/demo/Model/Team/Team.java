package com.example.demo.Model.Team;


import com.example.demo.Model.Ist_mitglied.ist_mitglied;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.OneToMany;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name="team")
public class Team {
    //Trace: https://git.informatik.uni-rostock.de/softwaretechnik-ws-2024-25/uebung1/team4/abgabedokument-sprint/-/blob/main/Komponentendiagramm_-_Teamstruktur.jpg?ref_type=heads

    @Id//gibt an, dass dieses Attribut der Primärschlüssel in der Datenbank ist
    @GeneratedValue(strategy = GenerationType.IDENTITY)//generiert die Werte für den Primärschlüssel in der Datenbank
    private Long team_id;
    private String name;

    @OneToMany(mappedBy="team")
    @JsonIgnore
    private List<ist_mitglied>ist_mitglieder;

    //anbei getter und setter

    public Long getTeam_id(){
        return this.team_id;
    }
    public String getName(){
        return this.name;
    }

    public List<ist_mitglied> getIst_mitglieder(){
        return this.ist_mitglieder;
    }

    public void setId(Long team_id){
        this.team_id = team_id;
    }
    public void setName(String name){
        this.name = name;
    }

    public void setIst_mitglieder(List<ist_mitglied> ist_mitglieder){
            this.ist_mitglieder = ist_mitglieder;
    }
}
