package com.example.demo.Model.Team;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class TeamService {
    //Trace: https://git.informatik.uni-rostock.de/softwaretechnik-ws-2024-25/uebung1/team4/abgabedokument-sprint/-/blob/main/Komponentendiagramm_-_Teamstruktur.jpg?ref_type=heads
    @Autowired
    private TeamRepository teamRepository;

    public Team saveTeam(Team team){
        return teamRepository.save(team);
    }

    public List<Team> getAllTeams(){
        return teamRepository.findAll();
    }

    public Optional<Team> getTeamById(Long id){
        return teamRepository.findById(id);
    }

    public void deleteTeam(Long id){
        teamRepository.deleteById(id);
    }


}
