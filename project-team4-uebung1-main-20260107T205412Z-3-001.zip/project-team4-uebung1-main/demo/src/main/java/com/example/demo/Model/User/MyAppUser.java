package com.example.demo.Model.User;

import java.util.ArrayList;
import java.util.List;

import com.example.demo.Model.Meetings.Meeting;
import com.example.demo.Model.Projekt.Projekt;
import com.example.demo.Model.Tasks.Task;
import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;

@Entity
public class MyAppUser {
    
    //Trace: "User" in https://git.informatik.uni-rostock.de/softwaretechnik-ws-2024-25/uebung1/team4/abgabedokument-sprint-4/-/blob/5f41bdf8c1770d6e342ab58ddca00db73b12077c/Klassendiagramm_Sprint_4.svg

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    private String username;
    private String email;
    private String password;
    private String verificationToken;
    private boolean enabled;

    @ManyToMany(mappedBy = "users", cascade = CascadeType.ALL)
    @JsonIgnore
    private List<Task> tasks = new ArrayList<>();

    @ManyToMany(cascade = {CascadeType.ALL})
    @JoinTable(
        name = "user_projects",
        joinColumns = {@JoinColumn(name = "user_id")},
        inverseJoinColumns = {@JoinColumn(name = "projekt_id")}
    )
    @JsonIgnore
    List<Projekt> projects = new ArrayList<>();
    

    public List<Projekt> getProjekt() {
        return projects;
    }

    public void setProjekt(List<Projekt> projects) {
        this.projects = projects;
    }

    @ManyToMany(cascade = {CascadeType.ALL})
    @JoinTable(
        name = "user_meetings",
        joinColumns = {@JoinColumn(name = "user_id")},
        inverseJoinColumns = {@JoinColumn(name = "meeting_id")}
    )
    List<Meeting> meetings = new ArrayList<>();
    

    public List<Meeting> getMeetings() {
        return meetings;
    }

    public void setMeetings(List<Meeting> meetings) {
        this.meetings = meetings;
    }


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public List<Task> getTasks() {
        return tasks;
    }

    public void setTasks(List<Task> tasks) {
        this.tasks = tasks;
    }

    public String getVerificationToken(){
        return verificationToken;
    }

    public void setVerificationToken(String token){
        this.verificationToken = token;
    }

    public boolean getEnabled(){
        return enabled;
    }

    public void setEnabled(boolean ena){
        this.enabled = ena;
    }

    private String resetToken;
    
    public String getResetToken() {
        return resetToken;
    }
    
    public void setResetToken(String resetToken) {
        this.resetToken = resetToken;
    }
}