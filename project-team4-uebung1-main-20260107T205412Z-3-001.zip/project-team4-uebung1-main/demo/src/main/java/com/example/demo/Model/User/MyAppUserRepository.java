package com.example.demo.Model.User;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

//Trace: "UserRepository" in https://git.informatik.uni-rostock.de/softwaretechnik-ws-2024-25/uebung1/team4/abgabedokument-sprint-4/-/blob/5f41bdf8c1770d6e342ab58ddca00db73b12077c/Klassendiagramm_Sprint_4.svg

import com.example.demo.Model.Projekt.Projekt;

@Repository
public interface MyAppUserRepository extends JpaRepository<MyAppUser, Long>{
    
    Optional<MyAppUser> findByUsername(String username);
    Optional<MyAppUser> findByEmail(String email);
    Optional<MyAppUser> findByVerificationToken(String token);
    Optional<MyAppUser> findByResetToken(String token);

    List<MyAppUser> findByProjectsNotContaining(Projekt project);
    List<MyAppUser> findByProjectsContaining(Projekt projekt);

    @Query("SELECT u FROM MyAppUser u JOIN u.projects p WHERE p.id = :projektId")
    List<MyAppUser> findAllByProjektId(@Param("projektId") Long projektId);

}