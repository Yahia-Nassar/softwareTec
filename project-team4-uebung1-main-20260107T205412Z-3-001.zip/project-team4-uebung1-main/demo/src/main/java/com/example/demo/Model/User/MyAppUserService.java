package com.example.demo.Model.User;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor 
public class MyAppUserService implements UserDetailsService{
    //Trace: "UserService" in https://git.informatik.uni-rostock.de/softwaretechnik-ws-2024-25/uebung1/team4/abgabedokument-sprint/-/blob/main/Klassendiagramm-Anmelden-Ausmelden.png?ref_type=heads

    @Autowired
    private MyAppUserRepository repository;

    public MyAppUser findByEmail(String email) {
        return repository.findByEmail(email)
            .orElseThrow(() -> new UsernameNotFoundException("User not found with email: " + email));
    }

    public MyAppUser findByResetToken(String token) {
        return repository.findByResetToken(token)
            .orElseThrow(() -> new IllegalArgumentException("Invalid reset token"));
    }

    public void updatePassword(MyAppUser user, String newPassword) {
        user.setPassword(newPassword);
        repository.save(user);
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        
        Optional<MyAppUser> user = repository.findByUsername(username);

        if (user.isPresent()) {
            var userObj = user.get();
            if (userObj.getEnabled()){
                return User.builder()
                        .username(userObj.getUsername())
                        .password(userObj.getPassword())
                        .build();  
            }
            else{
                throw new UsernameNotFoundException(username);
            }  
        } else {
            throw new UsernameNotFoundException(username);
        }
    }
}