package com.example.demo.Model.User;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class VerificationTokenService {

    //Trace2: "VerificationTokenService" in  https://git.informatik.uni-rostock.de/softwaretechnik-ws-2024-25/uebung1/team4/abgabedokument-sprint-4/-/blob/5f41bdf8c1770d6e342ab58ddca00db73b12077c/Klassendiagramm_Sprint_4.svg

    @Autowired
    private MyAppUserRepository userRepository;

    public void createVerificationToken(MyAppUser user, String token) {
        user.setVerificationToken(token);
        userRepository.save(user);
    }

    public String validateVerificationToken(String token) {
        MyAppUser user = userRepository.findByVerificationToken(token).orElse(null);
        if (user == null) {
            return "invalid";
        }

        user.setEnabled(true);
        userRepository.save(user);
        return "valid";
    }
}

