package com.example.demo.Model.UserStories;

import java.util.ArrayList;
import java.util.List;

import com.example.demo.Model.Projekt.Projekt;
import com.example.demo.Model.Sprints.Sprint;
import com.example.demo.Model.Tasks.Task;
import com.example.demo.Model.Tasks.priorityEnum;
import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Transient;

@Entity
public class UserStory {
    
    //Trace: "UserStory" in https://git.informatik.uni-rostock.de/softwaretechnik-ws-2024-25/uebung1/team4/abgabedokument-sprint-4/-/blob/5f41bdf8c1770d6e342ab58ddca00db73b12077c/Klassendiagramm_Sprint_4.svg

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id; 

    @Transient
    private boolean isTemp;

    public boolean isTemp() {
        return isTemp;
    }

    public void setTemp(boolean isTemp) {
        this.isTemp = isTemp;
    }

    private String title; 

    @Enumerated(EnumType.STRING)
    private statususerstory status;

    private String description; 
    private String acceptanceCriteria; 

    @Enumerated(EnumType.STRING)
    private priorityEnum priority; 

    @ManyToOne
    @JoinColumn(name = "sprint_id")
    private Sprint sprint;

    //@OneToMany(mappedBy = "userStory") //cascade = CascadeType.ALL, orphanRemoval = true)
   // @OnDelete(action = OnDeleteAction.CASCADE) 

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "projekt_id")
    @JsonIgnore
    private Projekt projekt;
   
    public Projekt getProjekt() {
        return projekt;
    }

    public void setProjekt(Projekt projekt) {
        this.projekt = projekt;
    }

    //@OneToMany(mappedBy = "userStory")
    //private List<Task> tasks = new ArrayList<>();

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public statususerstory getstatus() {
        return status;
    }

    public void setstatus(statususerstory status) {
        this.status = status;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getAcceptanceCriteria() {
        return acceptanceCriteria;
    }

    public void setAcceptanceCriteria(String acceptanceCriteria) {
        this.acceptanceCriteria = acceptanceCriteria;
    }

    public priorityEnum getPriority() {
        return priority;
    }

    public void setPriority(priorityEnum priority) {
        this.priority = priority;
    }

    public Sprint getSprint() {
        return sprint;
    }

    public void setSprint(Sprint sprint) {
        this.sprint = sprint;
    }

}