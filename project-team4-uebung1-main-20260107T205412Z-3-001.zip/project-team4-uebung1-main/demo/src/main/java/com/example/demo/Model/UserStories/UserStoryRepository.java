package com.example.demo.Model.UserStories;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.Model.Projekt.Projekt;
import com.example.demo.Model.Sprints.Sprint;

@Repository
public interface UserStoryRepository extends JpaRepository<UserStory, Long>{
    
    //Trace: "UserStoryRepository" in https://git.informatik.uni-rostock.de/softwaretechnik-ws-2024-25/uebung1/team4/abgabedokument-sprint-4/-/blob/5f41bdf8c1770d6e342ab58ddca00db73b12077c/Klassendiagramm_Sprint_4.svg

    Optional<UserStory> findByTitle(String title);
    List<UserStory> findBySprint_Sprintid(Long sprintid);
    List<UserStory> findByProjektAndSprint(Projekt projekt, Sprint sprint);

    
}