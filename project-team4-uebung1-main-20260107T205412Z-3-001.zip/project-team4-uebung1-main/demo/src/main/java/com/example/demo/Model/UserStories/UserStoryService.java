package com.example.demo.Model.UserStories;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Model.Tasks.Task;
import com.example.demo.Model.Tasks.TaskRepository;

import jakarta.persistence.EntityNotFoundException;

@Service
public class UserStoryService {

    @Autowired
    private UserStoryRepository userStoryRepository;

    @Autowired
    private TaskRepository taskRepository;

    public void deleteUserStory(Long userStoryId) {

        UserStory userStory = userStoryRepository.findById(userStoryId)
                .orElseThrow(() -> new EntityNotFoundException("Userstory not found"));


        List<Task> tasksToDelete = taskRepository.findByUserStory(userStory);
        taskRepository.deleteAll(tasksToDelete);


        userStoryRepository.delete(userStory);
    }
}
