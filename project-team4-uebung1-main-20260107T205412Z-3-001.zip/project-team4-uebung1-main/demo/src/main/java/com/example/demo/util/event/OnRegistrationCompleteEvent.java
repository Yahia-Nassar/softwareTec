package com.example.demo.util.event;

import com.example.demo.Model.User.MyAppUser;
import org.springframework.context.ApplicationEvent;

public class OnRegistrationCompleteEvent extends ApplicationEvent {

    //Trace: "OnRegistrationCompleteEvent" in https://git.informatik.uni-rostock.de/softwaretechnik-ws-2024-25/uebung1/team4/abgabedokument-sprint-4/-/blob/5f41bdf8c1770d6e342ab58ddca00db73b12077c/Klassendiagramm_Sprint_4.svg

    private final MyAppUser user;

    public OnRegistrationCompleteEvent(MyAppUser user) {
        super(user);
        this.user = user;
    }

    public MyAppUser getUser() {
        return user;
    }
}

