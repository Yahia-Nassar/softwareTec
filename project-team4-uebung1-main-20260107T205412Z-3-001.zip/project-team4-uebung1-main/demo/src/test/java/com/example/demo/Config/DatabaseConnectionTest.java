package com.example.demo.Config;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

import org.junit.jupiter.api.Test;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DatabaseConnectionTest {
        
    // CO.DBC.1

    @Test
    public void testDatabaseConnection() throws SQLException {
        // Mocken der Verbindung und Abfrage
        Connection mockConnection = mock(Connection.class);
        Statement mockStatement = mock(Statement.class);
        ResultSet mockResultSet = mock(ResultSet.class);

        // Verhalten der Mocks definieren
        when(mockConnection.createStatement()).thenReturn(mockStatement);
        when(mockStatement.executeQuery(anyString())).thenReturn(mockResultSet);
        when(mockResultSet.next()).thenReturn(true).thenReturn(false);
        when(mockResultSet.getInt("id")).thenReturn(1);
        when(mockResultSet.getString("name")).thenReturn("TestName");

        // Simulierte Abfrage ausführen
        Statement statement = mockConnection.createStatement();
        ResultSet resultSet = statement.executeQuery("SELECT * FROM tabellenname");

        if (resultSet.next()) {
            int id = resultSet.getInt("id");
            String name = resultSet.getString("name");

            // Tests
            assertEquals(1, id);
            assertEquals("TestName", name);
        }

        // Verifikation der Mock-Interaktionen
        verify(mockStatement).executeQuery(anyString());
        verify(mockResultSet).next();
    }
}
