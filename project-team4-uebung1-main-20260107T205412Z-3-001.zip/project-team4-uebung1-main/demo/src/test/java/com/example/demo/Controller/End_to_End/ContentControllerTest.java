package com.example.demo.Controller.End_to_End;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@AutoConfigureMockMvc
@DirtiesContext(classMode = DirtiesContext.ClassMode.BEFORE_EACH_TEST_METHOD)
public class ContentControllerTest {

    @Autowired
    private MockMvc mockMvc;

    // E2E.CC.1
    @Test
    public void testLoginEndpoint() throws Exception {
        mockMvc.perform(get("/req/login"))
            .andExpect(status().isOk())
            .andExpect(view().name("login"));
    }

    // E2E.CC.2
    @Test
    public void testSignupEndpoint() throws Exception {
        mockMvc.perform(get("/req/signup"))
            .andExpect(status().isOk())
            .andExpect(view().name("signup"));
    }

    // E2E.CC.3
    @Test
    public void testForgotPasswordEndpoint() throws Exception {
        mockMvc.perform(get("/forgot-password"))
            .andExpect(status().isOk())
            .andExpect(view().name("forgotPassword"));
    }

    // E2E.CC.4
    @Test
    public void testProjectsRedirect() throws Exception {
        mockMvc.perform(get("/projects"))
            .andExpect(status().is3xxRedirection())
            .andExpect(redirectedUrl("http://localhost/req/login"));
    }
}
