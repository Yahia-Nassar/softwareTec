/* package com.example.demo.Controller.End_to_End;

import com.example.demo.Model.User.MyAppUser;
import com.example.demo.Model.User.MyAppUserRepository;
import com.example.demo.Model.User.EmailService;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.web.servlet.MockMvc;

import static org.mockito.ArgumentMatchers.argThat;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import java.util.Optional;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@AutoConfigureMockMvc
@DirtiesContext(classMode = DirtiesContext.ClassMode.BEFORE_EACH_TEST_METHOD)
public class ForgotPasswordControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private MyAppUserRepository userRepository;

    @MockBean
    private EmailService emailService;

    @LocalServerPort
    private int port;

    @BeforeEach
    void setUp() {
        userRepository.deleteAll();
        MyAppUser user = new MyAppUser();
        user.setUsername("Max Mustermann");
        user.setEmail("max@example.com");
        user.setPassword("geheim");
        userRepository.save(user);
    }

    // E2E.FPC.1
    @Test
    void testForgotPasswordProcess() throws Exception {

        // Simuliere das Abschicken des Formulars
        mockMvc.perform(post("/forgot-password")
                .param("email", "max@example.com"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/login?resetEmailSent"));

        // Stelle sicher, dass ein Reset-Token generiert wurde
        Optional<MyAppUser> optionalUser = userRepository.findByEmail("max@example.com");
        MyAppUser user = optionalUser.orElseThrow(() -> new RuntimeException("User not found"));

        assertNotNull(user.getResetToken());

        // Verifiziere, dass die Mail korrekt verschickt wurde
        verify(emailService, times(1)).sendEmail(
            eq("max@example.com"),
            eq("Password Reset Request"),
            argThat(body -> body.contains("/reset-password?token=" + user.getResetToken()))
        ); 
    }
}*/
