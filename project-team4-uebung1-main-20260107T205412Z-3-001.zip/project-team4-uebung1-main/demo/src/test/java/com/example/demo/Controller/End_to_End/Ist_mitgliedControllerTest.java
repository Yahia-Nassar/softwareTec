package com.example.demo.Controller.End_to_End;

import com.example.demo.Model.Ist_mitglied.ist_mitglied;
import com.example.demo.Model.Nutzer.Nutzer;
import com.example.demo.Model.Team.Team;
import com.example.demo.Model.Nutzer.NutzerRepository;
import com.example.demo.Model.Team.TeamRepository;
import com.example.demo.Model.Ist_mitglied.ist_mitgliedRepository;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.databind.ObjectMapper;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@AutoConfigureMockMvc
@DirtiesContext(classMode = DirtiesContext.ClassMode.BEFORE_EACH_TEST_METHOD)
public class Ist_mitgliedControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private NutzerRepository nutzerRepository;

    @Autowired
    private TeamRepository teamRepository;

    @Autowired
    private ist_mitgliedRepository ist_mitgliedRepository;

    @Autowired
    private ObjectMapper objectMapper;

    private Nutzer testNutzer;
    private Team testTeam;

    private ist_mitglied istMitglied;

    @BeforeEach
    public void setUp() {
        testNutzer = new Nutzer();
        testNutzer.setVorname("Dieter");
        testNutzer = nutzerRepository.save(testNutzer);

        testTeam = new Team();
        testTeam.setName("Dev Team");
        testTeam = teamRepository.save(testTeam);

        istMitglied = new ist_mitglied();
        istMitglied.setRolle("MITGLIED");
        istMitglied.setNutzer(testNutzer);
        istMitglied.setTeam(testTeam);
    }

    // E2E.IC.1
    @Test
    public void testCreateIst_mitglied_success() throws Exception {
        mockMvc.perform(post("/api/istmitglied/create")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(istMitglied)))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("http://localhost/req/login"));
    }

    // E2E.IC.2
    @Test
    public void testGetIst_mitgliedById_success() throws Exception {
        ist_mitglied saved = ist_mitgliedRepository.save(istMitglied);

        mockMvc.perform(get("/api/istmitglied/" + saved.getNutzer().getNutzer_id()))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("http://localhost/req/login"));
    }

    // E2E.IC.3
    @Test
    public void testUpdateIst_mitglied_success() throws Exception {
        ist_mitglied saved = ist_mitgliedRepository.save(istMitglied);
        saved.setRolle("TEAMLEITER");

        mockMvc.perform(put("/api/istmitglied/" + saved.getNutzer().getNutzer_id())
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(saved)))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("http://localhost/req/login"));
    }

    // E2E.IC.4
    @Test
    public void testDeleteIst_mitglied_success() throws Exception {
        ist_mitglied saved = ist_mitgliedRepository.save(istMitglied);

        mockMvc.perform(delete("/api/istmitglied/" + saved.getNutzer().getNutzer_id()))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("http://localhost/req/login"));

        mockMvc.perform(get("/api/istmitglied/" + saved.getNutzer().getNutzer_id()))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("http://localhost/req/login"))
                .andExpect(content().string(""));
    }

}
