/*package com.example.demo.Controller.End_to_End;

import com.example.demo.Model.Meetings.Meeting;
import com.example.demo.Model.Projekt.Projekt;
import com.example.demo.Model.User.MyAppUser;
import com.example.demo.Model.User.MyAppUserRepository;
import com.example.demo.Model.Projekt.ProjektRepository;
import com.example.demo.Model.Meetings.MeetingRepository;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.web.servlet.MockMvc;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;


@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@AutoConfigureMockMvc
@DirtiesContext(classMode = DirtiesContext.ClassMode.BEFORE_EACH_TEST_METHOD)
public class MeetingControllerTest {

    @Autowired 
    private MockMvc mockMvc;

    @Autowired 
    private MyAppUserRepository userRepository;

    @Autowired 
    private ProjektRepository projektRepository;

    @Autowired 
    private MeetingRepository meetingRepository;

    @Autowired 
    private ObjectMapper objectMapper;

    private MyAppUser user;

    private Projekt projekt;

    @BeforeEach
    void setup() {
        user = new MyAppUser();
        user.setUsername("testuser"); // passt zu @WithMockUser(username = "testuser")
        user.setPassword("pass");
        
        userRepository.deleteAll(); // alle vorherigen Users entfernen

        user = userRepository.save(user);

        projekt = new Projekt();
        projekt.setName("Testprojekt");
        projekt = projektRepository.save(projekt);
    }

    // E2E.MC.1
    @Test
    @WithMockUser(username = "testuser")
    public void testCreateAndGetMeeting() throws Exception {
        Meeting meeting = new Meeting();
        meeting.setDescription("Sprint Planning");
        meeting.setDate(LocalDate.now());
        meeting.setTime(LocalTime.of(10, 0));

        List<Meeting> list = List.of(meeting);
        String body = objectMapper.writeValueAsString(list);

        mockMvc.perform(post("/createmeeting")
                .contentType(MediaType.APPLICATION_JSON)
                .param("projectid", projekt.getId().toString())
                .content(body))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].description").value("Sprint Planning"));

        mockMvc.perform(get("/getmeetings")
                .param("projectid", projekt.getId().toString()))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].description").value("Sprint Planning"));
    }

    // E2E.MC.2
    @Test
    @WithMockUser(username = "testuser")
    public void testEditMeeting() throws Exception {
        // Erstellt und speichert ein Meeting
        Meeting meeting = new Meeting();
        meeting.setDescription("Initial");
        meeting.setDate(LocalDate.now());
        meeting.setTime(LocalTime.of(9, 0));
        meeting.setProject(projekt);
        meeting = meetingRepository.save(meeting);

        // Aktualisieren
        meeting.setDescription("Updated Description");
        meeting.setTime(LocalTime.of(13, 45));

        String updatedBody = objectMapper.writeValueAsString(meeting);

        mockMvc.perform(put("/editmeeting")
                .param("projectid", projekt.getId().toString())
                .contentType(MediaType.APPLICATION_JSON)
                .content(updatedBody))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].description").value("Updated Description"));
    }

    // E2E.MC.3
    @Test
    @WithMockUser(username = "testuser")
    public void testDeleteMeeting() throws Exception {
        Meeting meeting = new Meeting();
        meeting.setDescription("To Delete");
        meeting.setDate(LocalDate.now());
        meeting.setTime(LocalTime.of(16, 0));
        meeting.setProject(projekt);
        meeting = meetingRepository.save(meeting);

        mockMvc.perform(post("/deletemeeting")
                .param("projectid", projekt.getId().toString())
                .param("meetingId", meeting.getMeetingId().toString()))
                .andExpect(status().isOk());

        mockMvc.perform(get("/getmeetings")
                .param("projectid", projekt.getId().toString()))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$").isEmpty());
    }
}*/
