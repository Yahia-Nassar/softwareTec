/*package com.example.demo.Controller.End_to_End;

import com.example.demo.Model.Nutzer.Nutzer;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;

@SpringBootTest
@AutoConfigureMockMvc
@DirtiesContext(classMode = DirtiesContext.ClassMode.BEFORE_EACH_TEST_METHOD)
public class NutzerControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    public void testCreateAndGetNutzer() throws Exception {
        Nutzer nutzer = new Nutzer();
        nutzer.setVorname("Lina");
        nutzer.setNachname("Testfrau");

        // Nutzer erstellen
        String jsonNutzer = objectMapper.writeValueAsString(nutzer);
        String responseJson = mockMvc.perform(post("/api/nutzer/create")
                .contentType(MediaType.APPLICATION_JSON)
                .content(jsonNutzer))
            .andExpect(status().is3xxRedirection())
            .andReturn()
            .getResponse()
            .getContentAsString();

        Nutzer created = objectMapper.readValue(responseJson, Nutzer.class);

        // Nutzer abrufen
        mockMvc.perform(get("/api/nutzer/" + created.getNutzer_id()))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.vorname").value("Lina"))
            .andExpect(jsonPath("$.nachname").value("Testfrau"));
    }

    @Test
    public void testUpdateNutzer() throws Exception {
        Nutzer original = new Nutzer();
        original.setVorname("Tom");
        original.setNachname("Alt");

        // Erstellt Nutzer
        String originalJson = objectMapper.writeValueAsString(original);
        String responseJson = mockMvc.perform(post("/api/nutzer/create")
                .contentType(MediaType.APPLICATION_JSON)
                .content(originalJson))
            .andExpect(status().isCreated())
            .andReturn()
            .getResponse()
            .getContentAsString();
        Nutzer saved = objectMapper.readValue(responseJson, Nutzer.class);

        // Updated Daten
        Nutzer updated = new Nutzer();
        updated.setVorname("Tom");
        updated.setNachname("Neu");

        mockMvc.perform(put("/api/nutzer/" + saved.getNutzer_id())
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(updated)))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.nachname").value("Neu"));
    }

    @Test
    public void testDeleteNutzer() throws Exception {
        Nutzer nutzer = new Nutzer();
        nutzer.setVorname("Zum");
        nutzer.setNachname("Löschen");

        String json = objectMapper.writeValueAsString(nutzer);
        String responseJson = mockMvc.perform(post("/api/nutzer/create")
                .contentType(MediaType.APPLICATION_JSON)
                .content(json))
            .andExpect(status().isCreated())
            .andReturn()
            .getResponse()
            .getContentAsString();
        Nutzer saved = objectMapper.readValue(responseJson, Nutzer.class);

        // Löschen
        mockMvc.perform(delete("/api/nutzer/" + saved.getNutzer_id()))
            .andExpect(status().isOk());

        // Versuch, gelöschten Nutzer abzurufen
        mockMvc.perform(get("/api/nutzer/" + saved.getNutzer_id()))
            .andExpect(status().isOk()); // abhängig davon, wie getNutzerById() mit leerem Optional umgeht
    }
}
*/