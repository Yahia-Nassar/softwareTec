/*package com.example.demo.Controller.End_to_End;

import com.example.demo.Model.Projekt.Projekt;
import com.example.demo.Model.Role.Role;
import com.example.demo.Model.Role.RoleEnum;
import com.example.demo.Model.Role.RoleId;
import com.example.demo.Model.Role.RoleRepository;
import com.example.demo.Model.User.MyAppUser;
import com.example.demo.Model.User.MyAppUserRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;

@SpringBootTest
@AutoConfigureMockMvc
@DirtiesContext(classMode = DirtiesContext.ClassMode.BEFORE_EACH_TEST_METHOD)
public class ProfileControllerTest {

    @Autowired 
    private MockMvc mockMvc;

    @Autowired 
    private ObjectMapper objectMapper;

    @Autowired 
    private MyAppUserRepository userRepository;

    @Autowired 
    private RoleRepository roleRepository;

    private MyAppUser user;

    private Projekt projekt;

    @BeforeEach
    void setup() {
        user = new MyAppUser();
        user.setUsername("testuser");
        user.setEmail("test@example.com");
        user.setPassword("secret");
        userRepository.save(user);

        projekt = new Projekt();
        projekt.setName("Testprojekt");
        projekt.setDescription("Beschreibung");

        Role role = new Role();
        role.setId(new RoleId(user.getId(), projekt.getId()));
        role.setRole(RoleEnum.PRODUCT_OWNER);
        role.setMeeting_notification(1);
        role.setTask_notification(0);
        roleRepository.save(role);
    }

    @Test
    @WithMockUser(username = "testuser")
    public void testGetUsername() throws Exception {
        mockMvc.perform(get("/getUsername"))
            .andExpect(status().isOk())
            .andExpect(content().string("testuser"));
    }

    @Test
    @WithMockUser(username = "testuser")
    public void testEditRole() throws Exception {
        Role newRole = new Role();
        newRole.setRole(RoleEnum.DEVELOPER);

        mockMvc.perform(post("/editrole")
                .param("projectid", String.valueOf(projekt.getId()))
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(newRole)))
            .andExpect(status().isOk());
    }

    @Test
    @WithMockUser(username = "testuser")
    public void testEditAndGetMeetingNotification() throws Exception {
        mockMvc.perform(post("/editmeetingnotification")
                .param("projectid", String.valueOf(projekt.getId()))
                .contentType(MediaType.APPLICATION_JSON)
                .content("2"))
            .andExpect(status().isOk());

        mockMvc.perform(get("/getmeetingnotification")
                .param("projectid", String.valueOf(projekt.getId())))
            .andExpect(status().isOk())
            .andExpect(content().string("2"));
    }

    @Test
    @WithMockUser(username = "testuser")
    public void testEditAndGetTaskNotification() throws Exception {
        mockMvc.perform(post("/edittasknotification")
                .param("projectid", String.valueOf(projekt.getId()))
                .contentType(MediaType.APPLICATION_JSON)
                .content("1"))
            .andExpect(status().isOk());

        mockMvc.perform(get("/gettasknotification")
                .param("projectid", String.valueOf(projekt.getId())))
            .andExpect(status().isOk())
            .andExpect(content().string("1"));
    }
}*/
