package com.example.demo.Controller.End_to_End;

import com.example.demo.Model.User.MyAppUser;
import com.example.demo.Model.User.MyAppUserRepository;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@AutoConfigureMockMvc
@DirtiesContext(classMode = DirtiesContext.ClassMode.BEFORE_EACH_TEST_METHOD)
public class RegistrationControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private MyAppUserRepository userRepository;

    private ObjectMapper objectMapper = new ObjectMapper();

    // E2E.RC.1
    @Test
    public void testUserRegistration() throws Exception {
        MyAppUser user = new MyAppUser();
        user.setUsername("e2etestuser");
        user.setPassword("strongpassword123");
        user.setEmail("e2e@example.com");

        String jsonUser = objectMapper.writeValueAsString(user);

        mockMvc.perform(post("/req/signup")
                .contentType(MediaType.APPLICATION_JSON)
                .content(jsonUser))
            .andExpect(status().isOk())
            .andExpect(content().string("redirect:/verify-email"));

        // Verifiziere, dass der User in der DB gespeichert wurde
        boolean userExists = userRepository.findByEmail("e2e@example.com").isPresent();
        assert(userExists);
    }
}
