package com.example.demo.Controller.End_to_End;

import com.example.demo.Model.User.MyAppUser;
import com.example.demo.Model.User.MyAppUserRepository;

import jakarta.servlet.ServletException;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

@SpringBootTest
@AutoConfigureMockMvc
@AutoConfigureTestDatabase
@DirtiesContext(classMode = DirtiesContext.ClassMode.BEFORE_EACH_TEST_METHOD)
public class ResetPasswordControllerTest {

    @Autowired 
    private MockMvc mockMvc;

    @Autowired 
    private MyAppUserRepository userRepository;

    private MyAppUser user;

    @BeforeEach
    void setup() {
        userRepository.deleteAll();

        user = new MyAppUser();
        user.setUsername("resetuser");
        user.setEmail("reset@example.com");
        user.setPassword("oldPassword");
        user.setResetToken("validToken123");
        user.setEnabled(true);
        userRepository.save(user);
    }

    // E2E.RPC.1
    @Test
    void testShowResetPasswordForm_validToken() throws Exception {
        mockMvc.perform(get("/reset-password")
                        .param("token", "validToken123"))
                .andExpect(status().isOk())
                .andExpect(view().name("resetPassword"))
                .andExpect(model().attributeExists("token"));
    }

    // E2E.RPC.2
    @Test
    void testShowResetPasswordForm_invalidToken_throwsServletException() {
        Exception thrown = assertThrows(ServletException.class, () ->
            mockMvc.perform(get("/reset-password")
                .param("token", "nonexistentToken"))
                .andReturn()
        );

        assertTrue(thrown.getMessage().contains("Invalid reset token"));
    }

    // E2E.RPC.3
    @Test
    void testResetPasswordSubmission_success() throws Exception {
        String jsonPayload = """
            {
              "username": "resetuser",
              "email": "reset@example.com",
              "password": "newSecretPassword",
              "resetToken": "validToken123"
            }
            """;

        mockMvc.perform(post("/reset-password")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(jsonPayload))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/login"));
    }
}
