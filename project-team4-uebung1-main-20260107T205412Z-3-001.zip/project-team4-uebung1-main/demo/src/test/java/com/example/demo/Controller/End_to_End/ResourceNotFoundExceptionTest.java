package com.example.demo.Controller.End_to_End;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.Test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.web.servlet.MockMvc;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@AutoConfigureMockMvc
@DirtiesContext(classMode = DirtiesContext.ClassMode.BEFORE_EACH_TEST_METHOD)
public class ResourceNotFoundExceptionTest {

    @Autowired
    private MockMvc mockMvc;

    // E2E.RNFC.1
    @Test
    @WithMockUser(username = "resetuser")
    void testResourceNotFoundExceptionIsThrown() throws Exception {
        mockMvc.perform(get("/api/demo/resource/99"))
            .andExpect(status().isNotFound())
            .andExpect(content().string(""));
    }
}
