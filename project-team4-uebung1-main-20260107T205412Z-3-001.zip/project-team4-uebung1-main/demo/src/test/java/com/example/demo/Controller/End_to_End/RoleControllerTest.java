package com.example.demo.Controller.End_to_End;

import com.example.demo.Model.Projekt.Projekt;
import com.example.demo.Model.Projekt.ProjektRepository;
import com.example.demo.Model.Role.Role;
import com.example.demo.Model.Role.RoleEnum;
import com.example.demo.Model.Role.RoleId;
import com.example.demo.Model.Role.RoleRepository;
import com.example.demo.Model.User.MyAppUser;
import com.example.demo.Model.User.MyAppUserRepository;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
@AutoConfigureTestDatabase
@DirtiesContext(classMode = DirtiesContext.ClassMode.BEFORE_EACH_TEST_METHOD)
public class RoleControllerTest {

    @Autowired private MockMvc mockMvc;
    @Autowired private MyAppUserRepository userRepository;
    @Autowired private ProjektRepository projektRepository;
    @Autowired private RoleRepository roleRepository;

    private MyAppUser user;
    private Projekt projekt;

    @BeforeEach
    void setup() {
        // Benutzer mit Username „testuser“ anlegen
        user = new MyAppUser();
        user.setUsername("testuser");
        user = userRepository.save(user);

        // Projekt erstellen
        projekt = new Projekt();
        projekt.setName("Projekt Alpha");
        projekt = projektRepository.save(projekt);

        // Rolle verknüpfen
        Role role = new Role();
        role.setId(new RoleId(user.getId(), projekt.getId()));
        role.setRole(RoleEnum.DEVELOPER);
        role.setMeeting_notification(1);
        role.setTask_notification(1);
        roleRepository.save(role);

    }

    // E2E.RC.1
    @Test
    @WithMockUser(username = "testuser")
    void testGetRoleReturnsCorrectEnum() throws Exception {
        mockMvc.perform(get("/getRole")
                .param("projectid", projekt.getId().toString()))
            .andExpect(status().isOk())
            .andExpect(content().string("\"DEVELOPER\""));
    }
}
