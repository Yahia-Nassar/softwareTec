package com.example.demo.Controller.End_to_End;

import com.example.demo.Model.Projekt.Projekt;
import com.example.demo.Model.Projekt.ProjektRepository;
import com.example.demo.Model.Sprints.Sprint;
import com.example.demo.Model.Sprints.SprintRepository;
import com.example.demo.Model.UserStories.UserStoryRepository;

import com.fasterxml.jackson.databind.ObjectMapper;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@AutoConfigureMockMvc
@AutoConfigureTestDatabase
@DirtiesContext(classMode = DirtiesContext.ClassMode.BEFORE_EACH_TEST_METHOD)
public class SprintControllerTest {

    @Autowired 
    private MockMvc mockMvc;

    @Autowired 
    private ObjectMapper objectMapper;

    @Autowired 
    private SprintRepository sprintRepository;

    @Autowired 
    private ProjektRepository projektRepository;

    @Autowired 
    private UserStoryRepository userStoryRepository;

    private Projekt projekt;

    @BeforeEach
    void setUp() {
        userStoryRepository.deleteAll();
        sprintRepository.deleteAll();
        projektRepository.deleteAll();

        projekt = new Projekt();
        projekt.setName("Demo Projekt");
        projekt = projektRepository.save(projekt);

        Sprint backlog = new Sprint();
        backlog.setSprintid(1L);
        backlog.setName("Backlog");
        backlog.setProjekt(projekt);
        sprintRepository.save(backlog);
    }

    // E2E.SC.1
    @Test
    void testCreateAndGetSprint() throws Exception {
        Sprint sprint = new Sprint();
        sprint.setName("Sprint 1");
        sprint.setStartDate("26.06.2025");

        mockMvc.perform(post("/createSprint")
                .param("projectId", projekt.getId().toString())
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(sprint)))
            .andExpect(status().is3xxRedirection());

        mockMvc.perform(get("/getsprints")
                .param("projectId", projekt.getId().toString()))
            .andExpect(status().is3xxRedirection());
    }

    // E2E.SC.2
    @Test
    void testEditSprint() throws Exception {
        Sprint sprint = new Sprint();
        sprint.setSprintid(2L);
        sprint.setName("Alt");
        sprint.setStartDate("26.06.2025");
        sprint.setProjekt(projekt);
        sprint = sprintRepository.save(sprint);

        sprint.setName("Geändert");
        sprint.setStartDate("27.06.2025");

        mockMvc.perform(put("/editSprint")
                .param("projectId", projekt.getId().toString())
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(sprint)))
            .andExpect(status().is3xxRedirection());
    }

    // E2E.SC.3
    @Test
    void testDeleteSprint() throws Exception {
        Sprint sprint = new Sprint();
        sprint.setSprintid(3L);
        sprint.setName("Sprint zum Löschen");
        sprint.setStartDate("26.06.2025");
        sprint.setProjekt(projekt);
        sprint = sprintRepository.save(sprint);

        mockMvc.perform(post("/deleteSprint")
                .param("sprintId", sprint.getSprintid().toString()))
            .andExpect(status().is3xxRedirection());
    }
}
