package com.example.demo.Controller.Integration;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import java.util.Collections;
import java.util.Optional;

import com.example.demo.Model.Projekt.Projekt;
import com.example.demo.Model.User.MyAppUser;
import com.example.demo.Model.User.MyAppUserRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;

@SpringBootTest
@AutoConfigureMockMvc(addFilters = false)
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.ANY)
class AuthControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private MyAppUserRepository userRepository;

    // I.AC.1
    @Test
    public void testUnauthenticated() throws Exception {
        // Hier wird keine Authentifizierung gesetzt. Daher sollten auch keine Repository-Aufrufe stattfinden.
        // Die Antwort für nicht authentifizierte Anfragen soll false sein.
        mockMvc.perform(get("/auth/status"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.isAuthenticated").value(false));
    }

    // I.AC.2
    @Test
    @WithMockUser(username = "testuser")
    public void testAuthenticatedWithoutProject() throws Exception {
        MyAppUser user = new MyAppUser();
        user.setUsername("testuser");
        // Leere Projektliste
        user.setProjekt(Collections.emptyList());
        when(userRepository.findByUsername("testuser")).thenReturn(Optional.of(user));

        mockMvc.perform(get("/auth/status"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.isAuthenticated").value(true));
    }

    // I.AC.3
    @Test
    @WithMockUser(username = "testuser")
    public void testAuthenticatedWithMatchingProject() throws Exception {
        MyAppUser user = new MyAppUser();
        user.setUsername("testuser");
        Projekt projekt = new Projekt();
        projekt.setId(100L);
        // Benutzer besitzt das Projekt mit ID 100
        user.setProjekt(Collections.singletonList(projekt));
        when(userRepository.findByUsername("testuser")).thenReturn(Optional.of(user));

        mockMvc.perform(get("/auth/status").param("projectid", "100"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.isAuthenticated").value(true));
    }

    // I.AC.4
    @Test
    @WithMockUser(username = "testuser")
    public void testAuthenticatedWithNonMatchingProject() throws Exception {
        MyAppUser user = new MyAppUser();
        user.setUsername("testuser");
        Projekt projekt = new Projekt();
        projekt.setId(200L);
        // Der Benutzer besitzt nur ein Projekt mit ID 200, was nicht der angefragten ID entspricht (100)
        user.setProjekt(Collections.singletonList(projekt));
        when(userRepository.findByUsername("testuser")).thenReturn(Optional.of(user));

        mockMvc.perform(get("/auth/status").param("projectid", "100"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.isAuthenticated").value(false));
    }

    // I.AC.5
    @Test
    @WithMockUser(username = "testuser")
    public void testAuthenticatedWithInvalidProjectId() throws Exception {
        MyAppUser user = new MyAppUser();
        user.setUsername("testuser");
        // Auch wenn der Benutzer existiert, führt ein ungültiger Parameter zu keiner weiteren Prüfung.
        user.setProjekt(Collections.emptyList());
        when(userRepository.findByUsername("testuser")).thenReturn(Optional.of(user));

        mockMvc.perform(get("/auth/status").param("projectid", "abc"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.isAuthenticated").value(false));
    }
}
