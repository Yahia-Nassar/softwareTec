package com.example.demo.Controller.Integration;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.redirectedUrl;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

@SpringBootTest
@AutoConfigureMockMvc
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.ANY)
public class ContentControllerTest {

    @Autowired
    private MockMvc mockMvc;

    // I.CC.1
    @Test
    void testLoginEndpoint() throws Exception {
        mockMvc.perform(get("/req/login"))
                .andExpect(status().isOk())
                .andExpect(view().name("login"));
    }

    // I.CC.2
    @Test
    void testSignupEndpoint() throws Exception {
        mockMvc.perform(get("/req/signup"))
                .andExpect(status().isOk())
                .andExpect(view().name("signup"));
    }

    // I.CC.3
    @Test
    void testForgotPasswordEndpoint() throws Exception {
        mockMvc.perform(get("/forgot-password"))
                .andExpect(status().isOk())
                .andExpect(view().name("forgotPassword"));
    }

    // I.CC.4
    @WithMockUser(username = "testUser", roles = {"USER"})
    @Test
    void testProjectsEndpoint() throws Exception {
        mockMvc.perform(get("/projects"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("http://localhost:3000/projectselection"));
    }
}
