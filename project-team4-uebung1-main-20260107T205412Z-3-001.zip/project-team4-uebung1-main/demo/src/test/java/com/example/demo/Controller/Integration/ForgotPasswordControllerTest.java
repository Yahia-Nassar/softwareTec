package com.example.demo.Controller.Integration;

import com.example.demo.Model.User.MyAppUser;
import com.example.demo.Model.User.MyAppUserRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;

import static org.junit.jupiter.api.Assertions.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.ANY)
public class ForgotPasswordControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private MyAppUserRepository myAppUserRepository;

    @BeforeEach
    public void setupDatabase() {
        myAppUserRepository.deleteAll();

        MyAppUser user = new MyAppUser();
        user.setEmail("test@example.com");
        user.setUsername("testUser");
        user.setResetToken(null);
        myAppUserRepository.save(user);
    }

    // I.FPC.1
    @Test
    public void testForgotPasswordEndpoint_ValidEmail_setsResetTokenAndRedirects() throws Exception {
        mockMvc.perform(post("/forgot-password")
                .param("email", "test@example.com"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/login?resetEmailSent"));

        MyAppUser updatedUser = myAppUserRepository.findByEmail("test@example.com")
                .orElseThrow(() -> new IllegalStateException("Benutzer nicht gefunden"));

        assertNotNull(updatedUser.getResetToken(), "Reset-Token sollte generiert worden sein.");
    }

    // I.FPC.2
    @Test
    public void testForgotPasswordEndpoint_InvalidEmail_redirectsWithError() throws Exception {
        mockMvc.perform(post("/forgot-password")
                .param("email", "nonexistent@example.com"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("http://localhost/req/login"));
    }

    // I.FPC.3
    @Test
    public void testForgotPassword_twice_generatesNewToken() throws Exception {
        mockMvc.perform(post("/forgot-password")
                .param("email", "test@example.com"));

        String firstToken = myAppUserRepository.findByEmail("test@example.com")
                .orElseThrow(() -> new IllegalStateException("Benutzer nicht gefunden"))
                .getResetToken();

        Thread.sleep(30); // kurze Pause für unterschiedlichen UUID-Seed

        mockMvc.perform(post("/forgot-password")
                .param("email", "test@example.com"));

        String secondToken = myAppUserRepository.findByEmail("test@example.com")
                .orElseThrow(() -> new IllegalStateException("Benutzer nicht gefunden"))
                .getResetToken();

        assertNotNull(firstToken);
        assertNotNull(secondToken);
        assertNotEquals(firstToken, secondToken, "Zweites Token sollte sich vom ersten unterscheiden.");
    }
}
