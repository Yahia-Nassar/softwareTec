package com.example.demo.Controller.Integration;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import com.example.demo.Model.Ist_mitglied.ist_mitglied;
import com.example.demo.Model.Ist_mitglied.ist_mitgliedService;
import com.example.demo.Model.Nutzer.Nutzer;
import com.example.demo.Model.Nutzer.NutzerService;
import com.example.demo.Model.Team.Team;
import com.example.demo.Model.Team.TeamService;

import com.fasterxml.jackson.databind.ObjectMapper;

import org.junit.jupiter.api.Test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

@SpringBootTest
@AutoConfigureMockMvc(addFilters = false)
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.ANY)
public class Ist_mitgliedControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockBean
    private ist_mitgliedService ist_mitgliedService;

    @MockBean
    private NutzerService nutzerService;

    @MockBean
    private TeamService teamService;

    // I.IC.1
    @Test
    public void testCreateIstMitglied() throws Exception {
        // -- Testdaten vorbereiten
        Long nutzerId = 1L;
        Long teamId = 10L;
        ist_mitglied newIstMitglied = new ist_mitglied();
        newIstMitglied.setRolle("RoleX");
        Nutzer nutzer = new Nutzer();
        nutzer.setNutzer_id(nutzerId);
        Team team = new Team();
        team.setId(teamId);
        newIstMitglied.setNutzer(nutzer);
        newIstMitglied.setTeam(team);
        
        // -- Mocks: Nutzer und Prev_Team sollen gefunden werden
        when(nutzerService.getNutzerById(nutzerId)).thenReturn(Optional.of(nutzer));
        when(teamService.getTeamById(teamId)).thenReturn(Optional.of(team));
        when(ist_mitgliedService.saveIst_mitglied(any(ist_mitglied.class))).thenReturn(newIstMitglied);
        
        String jsonPayload = objectMapper.writeValueAsString(newIstMitglied);
        
        mockMvc.perform(post("/api/istmitglied/create")
                .contentType(MediaType.APPLICATION_JSON)
                .content(jsonPayload))
            .andExpect(status().isCreated())
            .andExpect(jsonPath("$.rolle").value("RoleX"));
    }
    
    // I.IC.2
    @Test
    public void testUpdateIstMitglied_Existing() throws Exception {
        Long id = 1L;
        // -- Bestehendes Objekt
        ist_mitglied bestehendes = new ist_mitglied();
        bestehendes.setRolle("OldRole");
        bestehendes.setNutzer(new Nutzer());
        bestehendes.setTeam(new Team());
        
        // -- Update-Payload
        ist_mitglied updatePayload = new ist_mitglied();
        updatePayload.setRolle("NewRole");
        
        when(ist_mitgliedService.getIst_mitgliedById(id)).thenReturn(Optional.of(bestehendes));
        when(ist_mitgliedService.saveIst_mitglied(any(ist_mitglied.class))).thenReturn(bestehendes);
        
        String jsonPayload = objectMapper.writeValueAsString(updatePayload);
        
        mockMvc.perform(put("/api/istmitglied/{id}", id)
                .contentType(MediaType.APPLICATION_JSON)
                .content(jsonPayload))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.rolle").value("NewRole"));
    }
    
    // I.IC.3
    @Test
    public void testUpdateIstMitglied_NotExisting() throws Exception {
        Long id = 1L;
        ist_mitglied updatePayload = new ist_mitglied();
        updatePayload.setRolle("CreatedRole");

        when(ist_mitgliedService.getIst_mitgliedById(id)).thenReturn(Optional.empty());
        when(ist_mitgliedService.saveIst_mitglied(any(ist_mitglied.class))).thenAnswer(invocation -> {
            ist_mitglied saved = invocation.getArgument(0);
            saved.setRolle("CreatedRole"); // Stelle sicher, dass das Feld gesetzt wird
            return saved;
        });

        String jsonPayload = objectMapper.writeValueAsString(updatePayload);

        mockMvc.perform(put("/api/istmitglied/{id}", id)
                .contentType(MediaType.APPLICATION_JSON)
                .content(jsonPayload))
            .andExpect(status().isCreated()) // Stellt sicher, dass das Objekt erstellt wird
            .andExpect(jsonPath("$.rolle").value("CreatedRole")); // Überprüft das Feld "rolle"
    }
    
    // I.IC.4
    @Test
    public void testGetAllIstMitglied() throws Exception {
        ist_mitglied im1 = new ist_mitglied();
        im1.setRolle("A");
        ist_mitglied im2 = new ist_mitglied();
        im2.setRolle("B");
        List<ist_mitglied> list = Arrays.asList(im1, im2);
        
        when(ist_mitgliedService.getAllIst_mitglied()).thenReturn(list);
        
        mockMvc.perform(get("/api/istmitglied"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.length()").value(2));
    }
    
    // I.IC.5
    @Test
    public void testGetIstMitgliedById() throws Exception {
        ist_mitglied im = new ist_mitglied();
        im.setRolle("TestRole");
        when(ist_mitgliedService.getIst_mitgliedById(1L)).thenReturn(Optional.of(im));
        
        mockMvc.perform(get("/api/istmitglied/{id}", 1L))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.rolle").value("TestRole"));
    }
    
    // I.IC.6
    @Test
    public void testDeleteIstMitgliedById() throws Exception {
        doNothing().when(ist_mitgliedService).deleteIst_mitgliedById(1L);
        
        mockMvc.perform(delete("/api/istmitglied/{id}", 1L))
            .andExpect(status().isOk());
        
        verify(ist_mitgliedService).deleteIst_mitgliedById(1L);
    }
}