package com.example.demo.Controller.Integration;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;

import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.security.authentication.TestingAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.example.demo.Model.Meetings.Meeting;
import com.example.demo.Model.Projekt.Projekt;
import com.example.demo.Model.Projekt.ProjektRepository;
import com.example.demo.Model.User.MyAppUser;
import com.example.demo.Model.User.MyAppUserRepository;

@SpringBootTest
@AutoConfigureMockMvc(addFilters = false)
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.ANY)
public class MeetingControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private ProjektRepository projectRepository;

    @Autowired
    private MyAppUserRepository userRepository;

    @BeforeEach
    void setUp() {
        // Mock-Authentifizierung setzen
        SecurityContextHolder.getContext().setAuthentication(
            new TestingAuthenticationToken("testuser", null)
        );
    }

    // I.MC.1
    @Test
    void testCreateAndRetrieveMeeting() throws Exception {
        // Projekt in die Testdatenbank speichern
        Projekt projekt = new Projekt();
        projekt.setName("Projekt A");
        projectRepository.save(projekt);

        // User speichern
        MyAppUser user = new MyAppUser();
        user.setUsername("testuser");
        userRepository.save(user);

        // Meeting-Objekt erstellen
        Meeting meeting = new Meeting();
        meeting.setDescription("Sprint Planung");
        meeting.setProject(projekt);
        meeting.getUsers().add(user);

        // Meeting per API speichern
        mockMvc.perform(post("/createmeeting?projectid=" + projekt.getId())
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(List.of(meeting))))
                .andExpect(status().isOk());

        // API-Request zum Abrufen der Meetings
        mockMvc.perform(get("/getmeetings?projectid=" + projekt.getId()))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(1))
                .andExpect(jsonPath("$[0].description").value("Sprint Planung"));
    }
}
