package com.example.demo.Controller.Integration;

import com.example.demo.Model.Nutzer.Nutzer;
import com.example.demo.Model.Nutzer.NutzerRepository;
import com.example.demo.Model.Nutzer.NutzerService;
import com.example.demo.Model.Ist_mitglied.ist_mitgliedRepository;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import static org.hamcrest.Matchers.*;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc(addFilters = false)
public class NutzerControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private NutzerRepository nutzerRepository;

    @Autowired
    private NutzerService nutzerService;

    @Autowired
    private ist_mitgliedRepository istMitgliedRepository;

    @BeforeEach
    void setUp() {
        istMitgliedRepository.deleteAll();
        nutzerRepository.deleteAll();
    }

    // I.NC.1
    @Test
    void testCreateNutzer() throws Exception {
        mockMvc.perform(post("/api/nutzer/create")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"vorname\":\"John\", \"nachname\":\"Doe\"}"))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.vorname", is("John")))
                .andExpect(jsonPath("$.nachname", is("Doe")));
    }

    // I.NC.2
    @Test
    void testGetAllNutzer() throws Exception {
        Nutzer nutzer = new Nutzer();
        nutzer.setVorname("John");
        nutzer.setNachname("Doe");
        nutzerService.saveNutzer(nutzer);

        mockMvc.perform(get("/api/nutzer"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(1)))
                .andExpect(jsonPath("$[0].vorname", is("John")))
                .andExpect(jsonPath("$[0].nachname", is("Doe")));
    }

    // I.NC.3
    @Test
    void testUpdateNutzer() throws Exception {
        Nutzer nutzer = new Nutzer();
        nutzer.setVorname("John");
        nutzer.setNachname("Doe");
        nutzer = nutzerService.saveNutzer(nutzer);

        mockMvc.perform(put("/api/nutzer/" + nutzer.getNutzer_id())
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"vorname\":\"Jane\", \"nachname\":\"Doe\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.vorname", is("Jane")))
                .andExpect(jsonPath("$.nachname", is("Doe")));
    }

    // I.NC.4
    @Test
    void testDeleteNutzer() throws Exception {
        Nutzer nutzer = new Nutzer();
        nutzer.setVorname("John");
        nutzer.setNachname("Doe");

        Nutzer gespeicherterNutzer = nutzerService.saveNutzer(nutzer);
        Long nutzerId = gespeicherterNutzer.getNutzer_id();
        assertNotNull(nutzerId, "Die Nutzer-ID sollte nach dem Speichern gesetzt sein.");

        // Falls Referenzen in ist_mitglied existieren, diese zuerst entfernen
        istMitgliedRepository.deleteById(nutzerId);

        mockMvc.perform(delete("/api/nutzer/{id}", nutzerId))
            .andExpect(status().isOk());

        mockMvc.perform(get("/api/nutzer/{id}", nutzerId))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.nutzer_id").doesNotExist());
    }
}
