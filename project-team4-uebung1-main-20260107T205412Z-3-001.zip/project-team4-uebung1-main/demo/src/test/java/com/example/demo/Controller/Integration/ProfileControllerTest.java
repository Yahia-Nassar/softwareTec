package com.example.demo.Controller.Integration;

import com.example.demo.Model.Projekt.Projekt;
import com.example.demo.Model.Projekt.ProjektRepository;
import com.example.demo.Model.Role.Role;
import com.example.demo.Model.Role.RoleEnum;
import com.example.demo.Model.Role.RoleId;
import com.example.demo.Model.Role.RoleRepository;
import com.example.demo.Model.User.MyAppUser;
import com.example.demo.Model.User.MyAppUserRepository;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.ANY)
public class ProfileControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private MyAppUserRepository userRepository;

    @Autowired
    private ProjektRepository projektRepository;

    @Autowired
    private RoleRepository roleRepository;

    private MyAppUser user;
    private Projekt projekt;

    @BeforeEach
    void setUp() {
        roleRepository.deleteAll();
        projektRepository.deleteAll();
        userRepository.deleteAll();

        user = new MyAppUser();
        user.setUsername("tester");
        user.setPassword("{noop}pass");
        user = userRepository.save(user);

        projekt = new Projekt();
        projekt.setName("Testprojekt");
        projekt = projektRepository.save(projekt);

        RoleId roleId = new RoleId(user.getId(), projekt.getId());
        Role role = new Role();
        role.setId(roleId);
        role.setRole(RoleEnum.PRODUCT_OWNER);
        roleRepository.save(role);
    }

    // I.POC.1
    @Test
    @WithMockUser(username = "tester")
    public void editRole_shouldUpdateRoleSuccessfully() throws Exception {
        mockMvc.perform(post("/editrole")
                        .param("projectid", projekt.getId().toString())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                            {
                                "role": "DEVELOPER"
                            }
                        """))
                .andExpect(status().isOk());

        RoleId roleId = new RoleId(user.getId(), projekt.getId());
        Role updatedRole = roleRepository.findById(roleId).orElseThrow();
        assertEquals(RoleEnum.DEVELOPER, updatedRole.getRole());
    }
}
