package com.example.demo.Controller.Integration;

import com.example.demo.Model.Projekt.Projekt;
import com.example.demo.Model.Projekt.ProjektRepository;
import com.example.demo.Model.Sprints.Sprint;
import com.example.demo.Model.Sprints.SprintRepository;
import com.example.demo.Model.Tasks.Task;
import com.example.demo.Model.Tasks.TaskRepository;
import com.example.demo.Model.Tasks.priorityEnum;
import com.example.demo.Model.Tasks.statustask;
import com.example.demo.Model.User.MyAppUser;
import com.example.demo.Model.User.MyAppUserRepository;
import com.example.demo.Model.UserStories.UserStory;
import com.example.demo.Model.UserStories.UserStoryRepository;
import com.example.demo.Model.UserStories.statususerstory;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.ANY)
public class ProjektControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private ProjektRepository projektRepository;

    @MockBean
    private TaskRepository taskRepository;

    @MockBean
    private MyAppUserRepository userRepository;

    @MockBean
    private SprintRepository sprintRepository;

    @MockBean
    private UserStoryRepository userStoryRepository;

    // I.PC.1
    @Test
    @WithMockUser(username = "testuser")
    public void testGetAllProjects() throws Exception {
        MyAppUser user = new MyAppUser();
        user.setUsername("testuser");

        Projekt projekt = new Projekt();
        projekt.setId(1L);
        projekt.setName("Test Projekt");
        projekt.getUsers().add(user);

        user.getProjekt().add(projekt);

        when(userRepository.findByUsername("testuser")).thenReturn(Optional.of(user));

        mockMvc.perform(get("/getprojects"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.size()").value(1))
                .andExpect(jsonPath("$[0].name").value("Test Projekt"));
    }

    // I.PC.2
    @Test
    @WithMockUser(username = "testuser")
    public void testGetTasks() throws Exception {
        Projekt projekt = new Projekt();
        projekt.setId(1L);
        projekt.setName("Test Projekt");

        Task task1 = new Task();
        task1.setTitle("Test Task 1");

        Task task2 = new Task();
        task2.setTitle("Test Task 2");

        projekt.setTasks(Arrays.asList(task1, task2));
        
        when(projektRepository.findById(1L)).thenReturn(Optional.of(projekt));

        mockMvc.perform(get("/gettasks").param("projectid", "1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.size()").value(2))
                .andExpect(jsonPath("$[0].title").value("Test Task 1"))
                .andExpect(jsonPath("$[1].title").value("Test Task 2"));
    }

    // I.PC.3
    @Test
    @WithMockUser(username = "testuser")
    public void testGetAllTasks_ReturnsTaskDtos() throws Exception {
        Projekt projekt = new Projekt();
        projekt.setId(1L);
        projekt.setName("Demo Projekt");

        Task task1 = new Task();
        task1.setTitle("Task A");
        task1.setDescription("Beschreibung A");
        task1.setUsers(List.of());

        Task task2 = new Task();
        task2.setTitle("Task B");
        task2.setDescription("Beschreibung B");
        task2.setUsers(List.of());

        projekt.setTasks(List.of(task1, task2));

        when(projektRepository.findById(1L)).thenReturn(Optional.of(projekt));

        mockMvc.perform(get("/gettasks").param("projectid", "1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.size()").value(2))
                .andExpect(jsonPath("$[0].title").value("Task A"))
                .andExpect(jsonPath("$[1].title").value("Task B"));
    }

    // I.PC.4
    @Test
    @WithMockUser(username = "test")
    public void testGetAllUserTasks_ReturnsUserTaskDtos() throws Exception {
        MyAppUser user = new MyAppUser();
        user.setUsername("test");

        Task task = new Task();
        task.setTitle("Login-Feature");
        task.setDescription("Login-Seite mit Spring Security umsetzen");
        task.setUsers(List.of(user));

        user.setTasks(List.of(task));

        when(userRepository.findByUsername("test")).thenReturn(Optional.of(user));

        mockMvc.perform(get("/getusertasks").param("projectid", "123"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.size()").value(1))
                .andExpect(jsonPath("$[0].title").value("Login-Feature"))
                .andExpect(jsonPath("$[0].userInfos[0].username").value("test"));
    }

    // I.PC.5
    @Test
    @WithMockUser(username = "test")
    public void testGetTasksByProjectAndSprint_ReturnsSprintTasks() throws Exception {
        // Projekt und Sprint vorbereiten
        Projekt projekt = new Projekt();
        projekt.setId(1L);
        projekt.setName("Roadmap 2025");

        Sprint sprint = new Sprint();
        sprint.setSprintid(10L);
        sprint.setName("Sprint Alpha");

        // Beispielhafte Tasks
        Task task = new Task();
        task.setTitle("Dashboard verbessern");
        task.setDescription("Neue Widgets hinzufügen");
        task.setSprint(sprint);
        task.setUsers(List.of());

        List<Task> tasks = List.of(task);

        // Repository-Mocks setzen
        when(projektRepository.findById(1L)).thenReturn(Optional.of(projekt));
        when(sprintRepository.findById(10L)).thenReturn(Optional.of(sprint));
        when(taskRepository.findByProjektAndSprint(projekt, sprint)).thenReturn(tasks);

        // Endpoint aufrufen und prüfen
        mockMvc.perform(get("/getsprinttasks")
                .param("projectid", "1")
                .param("sprintid", "10"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.size()").value(1))
                .andExpect(jsonPath("$[0].title").value("Dashboard verbessern"));
    }

    // I.PC.6
    @Test
    @WithMockUser(username = "test")
    public void testGetAllUserStories_ReturnsUserStoryDtos() throws Exception {
        // Vorbereitung des Projekts
        Projekt projekt = new Projekt();
        projekt.setId(42L);
        projekt.setName("Neues Produkt");

        // Vorbereitung einer User Story
        UserStory userStory = new UserStory();
        userStory.setId(101L);
        userStory.setTitle("Als Nutzer möchte ich mich anmelden können");
        userStory.setDescription("Login-Funktion mit Passwort und Sicherheit");
        userStory.setPriority(priorityEnum.HIGH);
        userStory.setTemp(true);
        userStory.setAcceptanceCriteria("Validierung, sichere Speicherung");
        userStory.setSprint(null);  // kein Sprint gesetzt

        projekt.setUserStories(List.of(userStory));

        // Repository-Mock
        when(projektRepository.findById(42L)).thenReturn(Optional.of(projekt));

        // Testausführung
        mockMvc.perform(get("/getuserstories").param("projectid", "42"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.size()").value(1))
                .andExpect(jsonPath("$[0].id").value(101))
                .andExpect(jsonPath("$[0].title").value("Als Nutzer möchte ich mich anmelden können"))
                .andExpect(jsonPath("$[0].priority").value("HIGH"));
    }

    // I.PC.7
    @Test
    @WithMockUser(username = "test")
    public void testGetUSByProjectAndSprint_ReturnsMatchingUserStories() throws Exception {
        // Vorbereitung: Projekt und Sprint
        Projekt projekt = new Projekt();
        projekt.setId(100L);
        projekt.setName("Zukunftsprojekt");

        Sprint sprint = new Sprint();
        sprint.setSprintid(200L);
        sprint.setName("Sprint 1");

        // Beispielhafte User Story
        UserStory userStory = new UserStory();
        userStory.setId(301L);
        userStory.setTitle("Registrierung als Nutzer");
        userStory.setDescription("Als Besucher möchte ich mich registrieren können.");
        userStory.setPriority(priorityEnum.MEDIUM);
        userStory.setTemp(true);
        userStory.setAcceptanceCriteria("Eingabefelder validieren");
        userStory.setSprint(sprint);

        List<UserStory> stories = List.of(userStory);

        // Mocking
        when(projektRepository.findById(100L)).thenReturn(Optional.of(projekt));
        when(sprintRepository.findById(200L)).thenReturn(Optional.of(sprint));
        when(userStoryRepository.findByProjektAndSprint(projekt, sprint)).thenReturn(stories);

        // Testausführung
        mockMvc.perform(get("/getsprintUS")
                .param("projectid", "100")
                .param("sprintid", "200"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.size()").value(1))
                .andExpect(jsonPath("$[0].id").value(301))
                .andExpect(jsonPath("$[0].title").value("Registrierung als Nutzer"))
                .andExpect(jsonPath("$[0].priority").value("MEDIUM"))
                .andExpect(jsonPath("$[0].sprint").value(200));
    }

    // I.PC.8
    @Test
    @WithMockUser(username = "test")
    public void testGetUSByProjectAndSprint_ReturnsDtoList() throws Exception {
        // Vorbereitung
        Projekt projekt = new Projekt();
        projekt.setId(88L);
        projekt.setName("Projekt Phoenix");

        Sprint sprint = new Sprint();
        sprint.setSprintid(99L);
        sprint.setName("Sprint Frühling");

        UserStory userStory = new UserStory();
        userStory.setId(500L);
        userStory.setTitle("Benutzer-Avatar ändern");
        userStory.setDescription("Als Nutzer möchte ich mein Profilbild aktualisieren können.");
        userStory.setPriority(priorityEnum.MEDIUM);
        userStory.setTemp(false);
        userStory.setAcceptanceCriteria("Bild-Upload mit Formatprüfung");
        userStory.setSprint(sprint);

        List<UserStory> userStories = List.of(userStory);

        when(projektRepository.findById(88L)).thenReturn(Optional.of(projekt));
        when(sprintRepository.findById(99L)).thenReturn(Optional.of(sprint));
        when(userStoryRepository.findByProjektAndSprint(projekt, sprint)).thenReturn(userStories);

        // Test
        mockMvc.perform(get("/getsprintUS")
                .param("projectid", "88")
                .param("sprintid", "99"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.size()").value(1))
                .andExpect(jsonPath("$[0].id").value(500))
                .andExpect(jsonPath("$[0].title").value("Benutzer-Avatar ändern"))
                .andExpect(jsonPath("$[0].sprint").value(99))
                .andExpect(jsonPath("$[0].priority").value("MEDIUM"));
    }

    // I.PC.9
    @Test
    @WithMockUser(username = "test")
    public void testCreateTasks_SavesNewTasksSuccessfully() throws Exception {
        // Projekt vorbereiten
        Projekt projekt = new Projekt();
        projekt.setId(5L);
        projekt.setName("Release Sprint");

        // Sprint vorbereiten
        Sprint sprint = new Sprint();
        sprint.setSprintid(10L);
        sprint.setName("Sprint 3");

        // Benutzer vorbereiten
        MyAppUser user = new MyAppUser();
        user.setId(42L);
        user.setUsername("test");

        // Neue Task
        Task task = new Task();
        task.setid(null);
        task.setTitle("Neues Feature implementieren");
        task.setStatus(statustask.BURNBARREL);
        task.setSprint(sprint);
        task.setUsers(List.of(user));
        task.setTemp(true);

        // Repositories mocken
        when(projektRepository.findById(5L)).thenReturn(Optional.of(projekt));
        when(sprintRepository.findById(10L)).thenReturn(Optional.of(sprint));
        when(userRepository.findById(42L)).thenReturn(Optional.of(user));
        when(taskRepository.save(any(Task.class))).thenAnswer(invocation -> {
            Task t = invocation.getArgument(0);
            t.setid(999L);
            return t;
        });

        // JSON der neuen Task
        String jsonPayload = """
            [{
                "id": null,
                "title": "Neues Feature implementieren",
                "status": "BURNBARREL",
                "temp": true,
                "sprint": { "sprintid": 10 },
                "users": [{ "id": 42 }]
            }]
        """;

        // POST-Aufruf
        mockMvc.perform(post("/saveTasks")
                .param("projectid", "5")
                .contentType("application/json")
                .content(jsonPayload))
                .andExpect(status().isOk());
    }

    // I.PC.10
    @Test
    @WithMockUser(username = "test")
    public void testCreateUS_CreatesNewUserStory() throws Exception {
        // Projekt vorbereiten
        Projekt projekt = new Projekt();
        projekt.setId(123L);

        // Sprint vorbereiten
        Sprint sprint = new Sprint();
        sprint.setSprintid(321L);

        // User Story vorbereiten
        UserStory userStory = new UserStory();
        userStory.setId(null); // neue Story
        userStory.setTitle("Suchfunktion implementieren");
        userStory.setDescription("Als Nutzer möchte ich Inhalte durchsuchen können.");
        userStory.setAcceptanceCriteria("Suchleiste, Ranking");
        userStory.setPriority(priorityEnum.MEDIUM);
        userStory.setstatus(statususerstory.INCOMPLETE);
        userStory.setSprint(sprint);
        userStory.setTemp(true);

        // Repository-Mocking
        when(projektRepository.findById(123L)).thenReturn(Optional.of(projekt));
        when(sprintRepository.findById(321L)).thenReturn(Optional.of(sprint));
        when(userStoryRepository.save(any(UserStory.class))).thenAnswer(invocation -> {
            UserStory saved = invocation.getArgument(0);
            saved.setId(999L);
            return saved;
        });

        String jsonPayload = """
            [{
                "id": null,
                "title": "Suchfunktion implementieren",
                "description": "Als Nutzer möchte ich Inhalte durchsuchen können.",
                "acceptanceCriteria": "Suchleiste, Ranking",
                "priority": "MEDIUM",
                "status": "INCOMPLETE",
                "sprint": { "sprintid": 321 },
                "temp": true
            }]
        """;

        mockMvc.perform(post("/saveUSCards")
                .param("projectid", "123")
                .contentType("application/json")
                .content(jsonPayload))
                .andExpect(status().isOk());
    }

    // I.PC.11
    @Test
    @WithMockUser(username = "test")
    public void testGetAllProjects_ReturnsProjektDtos() throws Exception {
        // Benutzer & Projekt vorbereiten
        MyAppUser user = new MyAppUser();
        user.setId(7L);
        user.setUsername("test");

        Projekt projekt = new Projekt();
        projekt.setId(42L);
        projekt.setName("Mars-Mission");
        projekt.getUsers().add(user);

        user.setProjekt(List.of(projekt));

        // Mock-Verhalten
        when(userRepository.findByUsername("test")).thenReturn(Optional.of(user));

        // Test durchführen
        mockMvc.perform(get("/getprojects"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.size()").value(1))
                .andExpect(jsonPath("$[0].name").value("Mars-Mission"));
    }

    // I.PC.12
    @Test
    @WithMockUser(username = "test")
    public void testCreateProject_CreatesProjectAndBacklogSprint() throws Exception {
        // Benutzer vorbereiten
        MyAppUser user = new MyAppUser();
        user.setId(12L);
        user.setUsername("test");

        // Projekt-Vorlage
        Projekt newProjekt = new Projekt();
        newProjekt.setName("Galaxy Planner");
        newProjekt.setUsers(new ArrayList<>());

        // Rückgabe nach Speicherung
        Projekt savedProjekt = new Projekt();
        savedProjekt.setId(77L);
        savedProjekt.setName("Galaxy Planner");

        // Mocking
        when(userRepository.findByUsername("test")).thenReturn(Optional.of(user));
        when(projektRepository.save(any(Projekt.class))).thenReturn(savedProjekt);

        // JSON für neuen Projekt-Request
        String jsonPayload = """
            {
                "name": "Galaxy Planner"
            }
        """;

        // POST-Request
        mockMvc.perform(post("/createproject")
                .contentType("application/json")
                .content(jsonPayload))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name").value("Galaxy Planner"));
    }

    // I.PC.13
    @Test
    @WithMockUser(username = "test")
    public void testGetProjectUsers_ReturnsUserDtos() throws Exception {
        // Projekt-ID vorbereiten
        long projectId = 77L;

        // Zwei Benutzer im Projekt
        MyAppUser user1 = new MyAppUser();
        user1.setId(1L);
        user1.setUsername("emma");
        user1.setEmail("emma@example.com");
        user1.setEnabled(true);
        user1.setVerificationToken("abc123");
        user1.setResetToken("reset123");

        MyAppUser user2 = new MyAppUser();
        user2.setId(2L);
        user2.setUsername("luca");
        user2.setEmail("luca@example.com");
        user2.setEnabled(false);
        user2.setVerificationToken("def456");
        user2.setResetToken("reset456");

        List<MyAppUser> users = List.of(user1, user2);

        // Mocking des Repositories
        when(userRepository.findAllByProjektId(projectId)).thenReturn(users);

        // Test-Request durchführen
        mockMvc.perform(get("/getprojectusers").param("projectid", String.valueOf(projectId)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.size()").value(2))
                .andExpect(jsonPath("$[0].username").value("emma"))
                .andExpect(jsonPath("$[0].email").value("emma@example.com"))
                .andExpect(jsonPath("$[1].username").value("luca"))
                .andExpect(jsonPath("$[1].enabled").value(false));
    }

}   
