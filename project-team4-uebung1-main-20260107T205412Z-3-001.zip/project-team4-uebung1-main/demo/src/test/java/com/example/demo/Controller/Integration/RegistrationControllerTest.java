package com.example.demo.Controller.Integration;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import java.util.Optional;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.example.demo.Controller.RegistrationController;
import com.example.demo.Model.User.MyAppUser;
import com.example.demo.Model.User.MyAppUserRepository;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.ApplicationEventPublisher;

@SpringBootTest
@AutoConfigureMockMvc
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.ANY)
public class RegistrationControllerTest {

    private MockMvc mockMvc;

    @Mock
    private MyAppUserRepository myAppUserRepository;

    @Mock
    private PasswordEncoder passwordEncoder;

    @Mock
    private ApplicationEventPublisher applicationEventPublisher; // Mock für EventPublisher hinzugefügt

    @InjectMocks
    private RegistrationController registrationController;

    private ObjectMapper objectMapper = new ObjectMapper();

    @BeforeEach
    public void setup() {
        // Initialisiert die Mocks und öffnet sie für Tests
        MockitoAnnotations.openMocks(this);
        // Initialisiert MockMvc mit dem Controller
        mockMvc = MockMvcBuilders.standaloneSetup(registrationController).build();
    }

    // I.RC.1
    @Test
    public void testCreateUser_Success() throws Exception {
        MyAppUser myAppUser = new MyAppUser();
        myAppUser.setUsername("newuser");
        myAppUser.setPassword("password");
        myAppUser.setEmail("newuser@example.com");

        // JSON erzeugen
        String user = objectMapper.writeValueAsString(myAppUser);

        // Mocking
        when(passwordEncoder.encode("password")).thenReturn("encoded_password");
        when(myAppUserRepository.findByEmail("newuser@example.com")).thenReturn(Optional.empty());
        when(myAppUserRepository.save(any(MyAppUser.class))).thenAnswer(invocation -> {
            MyAppUser savedUser = invocation.getArgument(0);
            savedUser.setPassword("encoded_password");
            return savedUser;
        });

        doNothing().when(applicationEventPublisher).publishEvent(any());

        // Test-Request ausführen & prüfen
        mockMvc.perform(MockMvcRequestBuilders.post("/req/signup")
                .contentType(MediaType.APPLICATION_JSON)
                .content(user))
            .andExpect(status().isOk())
            .andExpect(content().string("redirect:/verify-email"));
    }


    // I.RC.2
    @Test
    public void testCreateUser_EmailAlreadyExists() throws Exception {
        // Simuliere einen existierenden Benutzer mit gleicher E-Mail
        MyAppUser existingUser = new MyAppUser();
        existingUser.setEmail("existing@example.com");

        when(myAppUserRepository.findByEmail("existing@example.com")).thenReturn(Optional.of(existingUser));

        // Neuer Benutzer mit derselben E-Mail
        MyAppUser newUser = new MyAppUser();
        newUser.setUsername("newuser");
        newUser.setEmail("existing@example.com");
        newUser.setPassword("password");

        String userJson = objectMapper.writeValueAsString(newUser);

        mockMvc.perform(MockMvcRequestBuilders.post("/req/signup")
                .contentType(MediaType.APPLICATION_JSON)
                .content(userJson))
            .andExpect(status().isConflict())
            .andExpect(content().string("Account with this e-mail already exists."));

        verify(myAppUserRepository, times(0)).save(any(MyAppUser.class));
        verify(myAppUserRepository, times(1)).findByEmail("existing@example.com");
    }


    // I.RC.3
    @Test
    public void testCreateUser_EmailExists() throws Exception {
        // Benutzer, der bereits existiert
        MyAppUser existingUser = new MyAppUser();
        existingUser.setEmail("existing@example.com");

        // Mock: E-Mail existiert bereits
        when(myAppUserRepository.findByEmail("existing@example.com")).thenReturn(Optional.of(existingUser));

        // Neuer Benutzer mit derselben E-Mail
        MyAppUser newUser = new MyAppUser();
        newUser.setUsername("newUser");
        newUser.setEmail("existing@example.com");
        newUser.setPassword("password");

        String userJson = objectMapper.writeValueAsString(newUser);

        mockMvc.perform(MockMvcRequestBuilders.post("/req/signup")
                .contentType(MediaType.APPLICATION_JSON)
                .content(userJson))
            .andExpect(status().isConflict())
            .andExpect(content().string("Account with this e-mail already exists."));

        verify(myAppUserRepository, times(0)).save(any(MyAppUser.class));
        verify(myAppUserRepository, times(1)).findByEmail("existing@example.com");
    }

    // I.RC.4
    @Test
    public void testValidateVerificationToken_ValidToken() {
        // Simuliere einen Benutzer mit einem gültigen Token
        MyAppUser user = new MyAppUser();
        user.setVerificationToken("validToken");
        user.setEnabled(false);

        // Mocking: Der Benutzer mit dem Token wird gefunden
        when(myAppUserRepository.findByVerificationToken("validToken")).thenReturn(Optional.of(user));

        // Aufruf der Methode
        String result = registrationController.validateVerificationToken("validToken");

        // Überprüfe das Ergebnis
        assertEquals("valid", result);
        assertTrue(user.getEnabled());

        // Verifiziere, dass der Benutzer gespeichert wurde
        verify(myAppUserRepository, times(1)).save(user);
    }

    // I.RC.5
    @Test
    public void testValidateVerificationToken_InvalidToken() {
        // Mocking: Kein Benutzer mit dem angegebenen Token wird gefunden
        when(myAppUserRepository.findByVerificationToken("invalidToken")).thenReturn(Optional.empty());

        // Aufruf der Methode
        String result = registrationController.validateVerificationToken("invalidToken");

        // Überprüfe das Ergebnis
        assertEquals("invalid", result);

        // Verifiziere, dass keine Speicherung durchgeführt wurde
        verify(myAppUserRepository, times(0)).save(any(MyAppUser.class));
    }
}