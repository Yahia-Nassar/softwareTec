package com.example.demo.Controller.Integration;

import com.example.demo.Model.User.MyAppUser;
import com.example.demo.Model.User.MyAppUserRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.http.MediaType;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.ANY)
public class ResetPasswordControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private MyAppUserRepository myAppUserRepository;

    // I.RPC.1
    @Test
    void testShowResetPasswordForm_ValidToken() throws Exception {
        try {
            // Dummy-Daten speichern
            MyAppUser user = new MyAppUser();
            user.setUsername("testUser");
            user.setEmail("test@example.com");
            user.setResetToken("validToken");
            myAppUserRepository.save(user);

            mockMvc.perform(get("/reset-password").param("token", "validToken"))
                    .andExpect(status().isOk())
                    .andExpect(view().name("resetPassword"))
                    .andExpect(model().attributeExists("token"));
        } catch (Exception e) {
            System.out.println("Fehler bei ValidToken-Test: " + e.getMessage());
        }
    }

    // I.RPC.2
    @Test
    void testShowResetPasswordForm_InvalidToken() throws Exception {
        try {
            mockMvc.perform(get("/reset-password").param("token", "invalidToken"))
                    .andExpect(status().is3xxRedirection())
                    .andExpect(redirectedUrl("/req/signup"));
        } catch (Exception e) {
            System.out.println("Fehler bei InvalidToken-Test: " + e.getMessage());
        }
    }

    // I.RPC.3
    @Test
    void testCreateUser_ResetPassword() throws Exception {
        try {
            // Benutzer mit Reset-Token speichern
            MyAppUser user = new MyAppUser();
            user.setUsername("testUser");
            user.setEmail("test@example.com");
            user.setResetToken("resetToken123");
            myAppUserRepository.save(user);

            String jsonPayload = """
                {
                    "username": "testUser",
                    "email": "test@example.com",
                    "password": "newSecurePassword",
                    "resetToken": "resetToken123"
                }
                """;

            mockMvc.perform(post("/reset-password")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(jsonPayload))
                    .andExpect(status().is3xxRedirection())
                    .andExpect(redirectedUrl("/login"));
        } catch (Exception e) {
            System.out.println("Fehler bei Passwort-Reset-Test: " + e.getMessage());
        }
    }
}