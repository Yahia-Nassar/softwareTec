package com.example.demo.Controller.Integration;

import static org.junit.jupiter.api.Assertions.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;

@SpringBootTest
@AutoConfigureMockMvc
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.ANY)
public class ResourceNotFoundExceptionTest {

    @Autowired
    private MockMvc mockMvc;

    // I.RNFE.1
    @Test
    public void testResourceRedirect() throws Exception {
        mockMvc.perform(get("/resource/999"))
            .andExpect(status().isFound()) // Erwartet 302 Found (Redirection)
            .andExpect(result -> 
                    assertEquals("http://localhost/req/login", result.getResponse().getRedirectedUrl())
            ); // Überprüft, ob die Weiterleitung zur richtigen URL erfolgt
    }
}