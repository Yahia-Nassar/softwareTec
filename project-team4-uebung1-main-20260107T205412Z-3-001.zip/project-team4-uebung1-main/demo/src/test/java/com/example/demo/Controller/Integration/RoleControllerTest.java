package com.example.demo.Controller.Integration;

import com.example.demo.Model.Projekt.Projekt;
import com.example.demo.Model.Projekt.ProjektRepository;
import com.example.demo.Model.Role.Role;
import com.example.demo.Model.Role.RoleEnum;
import com.example.demo.Model.Role.RoleRepository;
import com.example.demo.Model.User.MyAppUser;
import com.example.demo.Model.User.MyAppUserRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;

import java.util.Optional;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;

@SpringBootTest
@AutoConfigureMockMvc
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.ANY)
class RoleControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private MyAppUserRepository userRepository;

    @MockBean
    private ProjektRepository projektRepository;

    @MockBean
    private RoleRepository roleRepository;

    // I.ROC.1
    @Test
    @WithMockUser(username = "testUser")
    public void testGetRole_UserAndProjectExist_ReturnRole() throws Exception {
        MyAppUser user = new MyAppUser();
        user.setId(1L);
        user.setUsername("testUser");
        when(userRepository.findByUsername("testUser")).thenReturn(Optional.of(user));

        Projekt project = new Projekt();
        project.setId(1L);
        when(projektRepository.findById(1L)).thenReturn(Optional.of(project));

        Role role = new Role();
        role.setRole(RoleEnum.DEVELOPER);
        when(roleRepository.findByIdProjektIdAndIdUserId(1L, 1L)).thenReturn(role);

        mockMvc.perform(get("/getRole")
                        .param("projectid", "1"))
                .andExpect(status().isOk())
                .andExpect(content().string("\"DEVELOPER\"")); // Anführungszeichen für JSON-String beachten
    }

    // I.ROC.2
    @Test
    @WithMockUser(username = "testUser")
    public void testGetRole_NoRoleFound_ReturnsNull() throws Exception {
        MyAppUser user = new MyAppUser();
        user.setId(1L);
        when(userRepository.findByUsername("testUser")).thenReturn(Optional.of(user));

        Projekt project = new Projekt();
        project.setId(1L);
        when(projektRepository.findById(1L)).thenReturn(Optional.of(project));

        when(roleRepository.findByIdProjektIdAndIdUserId(1L, 1L)).thenReturn(null);

        mockMvc.perform(get("/getRole").param("projectid", "1"))
                .andExpect(status().isOk())
                .andExpect(content().string(""));
    }
}
