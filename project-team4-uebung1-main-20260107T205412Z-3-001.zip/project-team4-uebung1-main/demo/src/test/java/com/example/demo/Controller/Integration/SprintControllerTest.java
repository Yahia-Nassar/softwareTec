package com.example.demo.Controller.Integration;

import com.example.demo.Model.Projekt.Projekt;
import com.example.demo.Model.Sprints.Sprint;
import com.example.demo.Model.Sprints.SprintRepository;
import com.example.demo.Model.UserStories.UserStoryRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Optional;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.ANY)
public class SprintControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private SprintRepository sprintRepository;

    @MockBean
    private UserStoryRepository userStoryRepository;

    @MockBean
    private com.example.demo.Model.Projekt.ProjektRepository projektRepository;

    // I.SC.1
    @Test
    @WithMockUser
    void testGetSprints_ShouldReturnSprintList() throws Exception {
        Sprint sprint1 = new Sprint();
        sprint1.setSprintid(1L);
        sprint1.setName("Sprint 1");
        
        Sprint sprint2 = new Sprint();
        sprint2.setSprintid(2L);
        sprint2.setName("Sprint 2");

        when(sprintRepository.findByProjekt_Id(1L)).thenReturn(List.of(sprint1, sprint2));

        mockMvc.perform(get("/getsprints").param("projectId", "1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(2))
                .andExpect(jsonPath("$[0].name").value("Sprint 1"))
                .andExpect(jsonPath("$[1].name").value("Sprint 2"));
    }

    // I.SC.2
    @Test
    @WithMockUser
    void testCreateSprint_ShouldReturnCreatedSprint() throws Exception {
        Projekt project = new Projekt();
        project.setId(1L);

        Sprint sprint = new Sprint();
        sprint.setSprintid(2L);
        sprint.setName("Sprint 2");

        when(projektRepository.findById(1L)).thenReturn(Optional.of(project));
        when(sprintRepository.findMaxSprintid()).thenReturn(1L);
        when(sprintRepository.save(any(Sprint.class))).thenReturn(sprint);

        mockMvc.perform(post("/createSprint")
                .param("projectId", "1")
                .contentType("application/json")
                .content("{\"name\": \"Sprint 2\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name").value("Sprint 2"));
    }

    // I.SC.3
    @Test
    @WithMockUser
    void testDeleteSprint_ShouldMoveUserStoriesAndDeleteSprint() throws Exception {
        Sprint backlog = new Sprint();
        backlog.setSprintid(1L);

        Sprint sprintToDelete = new Sprint();
        sprintToDelete.setSprintid(2L);

        when(sprintRepository.findById(1L)).thenReturn(Optional.of(backlog));
        when(userStoryRepository.findBySprint_Sprintid(2L)).thenReturn(List.of());
        doNothing().when(sprintRepository).deleteById(2L);

        mockMvc.perform(post("/deleteSprint").param("sprintId", "2"))
                .andExpect(status().isOk())
                .andExpect(content().string("Sprint deleted and UserStories moved to backlog"));
    }

    // I.SC.4
    @Test
    @WithMockUser
    void testEditSprint_ShouldUpdateSprintDetails() throws Exception {
        Sprint existingSprint = new Sprint();
        existingSprint.setSprintid(2L);
        existingSprint.setName("Old Sprint");
        existingSprint.setStartDate("2024-06-01");

        Sprint updatedSprint = new Sprint();
        updatedSprint.setSprintid(2L);
        updatedSprint.setName("Updated Sprint");
        updatedSprint.setStartDate("2024-07-01");

        when(sprintRepository.findById(2L)).thenReturn(Optional.of(existingSprint));
        when(sprintRepository.save(any(Sprint.class))).thenReturn(updatedSprint);

        mockMvc.perform(put("/editSprint")
                .param("projectId", "1")
                .contentType("application/json")
                .content("{\"sprintid\": 2, \"name\": \"Updated Sprint\", \"startDate\": \"2024-07-01\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name").value("Updated Sprint"))
                .andExpect(jsonPath("$.startDate").value("2024-07-01"));
    }
}
