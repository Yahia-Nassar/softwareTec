package com.example.demo.Controller.Integration.TaskController.CommentController;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import java.util.Collections;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors;
import org.springframework.test.web.servlet.MockMvc;

import com.example.demo.Controller.CommentController.CommentController.CommentGetController;
import com.example.demo.Model.Tasks.Comment;
import com.example.demo.Model.Tasks.CommentRepository;

@AutoConfigureMockMvc(addFilters = false)
@WebMvcTest(CommentGetController.class)
public class CommentGetControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private CommentRepository commentRepository;

    private Comment comment;

    @BeforeEach
    void setUp() {
        comment = new Comment();
        comment.setId(1L);
        comment.setText("Sample Comment");
    }
    
    // I.CGC.1

    @Test
    void testGetComment() throws Exception {
        when(commentRepository.findById(1L)).thenReturn(Optional.of(comment));
    
        mockMvc.perform(get("/comments/1")
                .with(SecurityMockMvcRequestPostProcessors.httpBasic("user", "password")))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1L))
                .andExpect(jsonPath("$.text").value("Sample Comment"));
    
        verify(commentRepository, times(1)).findById(1L);
    }
    
    // I.CGC.2

    @Test
    void testGetAllComments() throws Exception {
        when(commentRepository.findAll()).thenReturn(Collections.singletonList(comment));
    
        mockMvc.perform(get("/comments")
                .with(SecurityMockMvcRequestPostProcessors.httpBasic("user", "password")))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].id").value(1L))
                .andExpect(jsonPath("$[0].text").value("Sample Comment"));
    
        verify(commentRepository, times(1)).findAll();
    }
}