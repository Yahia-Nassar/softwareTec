    /* package com.example.demo.Controller.Integration.TaskController.CommentController;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.example.demo.Controller.CommentController.CommentController.CommentSaveController;
import com.example.demo.Model.Tasks.Comment;
import com.example.demo.Model.Tasks.CommentRepository;

import com.fasterxml.jackson.databind.ObjectMapper;

import org.junit.jupiter.api.Test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;

import com.example.demo.Security.SecurityConfigUnitTest;


@WebMvcTest(CommentSaveController.class)
public class CommentSaveControllerTest {


    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private CommentRepository commentRepository;

    @Autowired
    private ObjectMapper objectMapper;
    
    // I.CSC.1

    @Test
    @WithMockUser(username = "user", password = "password")
    public void createCommentTest() throws Exception {
        Comment comment = new Comment();
        comment.setText("This is a test comment");

        when(commentRepository.save(any(Comment.class))).thenReturn(comment);

        mockMvc.perform(post("/comments")
                .with(SecurityConfigUnitTest.testUser())
                .with(csrf())
                .contentType("application/json")
                .content(objectMapper.writeValueAsString(comment)))
                .andExpect(status().isOk());
    }
}*/