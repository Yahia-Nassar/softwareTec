package com.example.demo.Controller.Integration;

import com.example.demo.Model.Projekt.Projekt;
import com.example.demo.Model.Projekt.ProjektRepository;
import com.example.demo.Model.User.MyAppUser;
import com.example.demo.Model.User.MyAppUserRepository;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.*;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc(addFilters = false)
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.ANY)
public class TeamControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private MyAppUserRepository userRepository;

    @MockBean
    private ProjektRepository projectRepository;

    private final ObjectMapper objectMapper = new ObjectMapper();

    // I.TC.1
    @Test
    public void testGetUsersInProject() throws Exception {
        Projekt projekt = new Projekt();
        projekt.setId(1L);

        MyAppUser user = new MyAppUser();
        user.setId(1L);
        user.setUsername("testuser");
        user.setEmail("user@example.com");

        Mockito.when(projectRepository.findById(1L)).thenReturn(Optional.of(projekt));
        Mockito.when(userRepository.findByProjectsContaining(projekt)).thenReturn(List.of(user));

        mockMvc.perform(get("/getusersinproject").param("projectid", "1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].username").value("testuser"));
    }

    // I.TC.2
    @Test
    public void testAddUserToProject() throws Exception {
        Projekt projekt = new Projekt();
        projekt.setId(2L);

        MyAppUser user = new MyAppUser();
        user.setUsername("newuser");
        user.setProjekt(new ArrayList<>());

        Map<String, String> requestBody = new HashMap<>();
        requestBody.put("username", "newuser");

        Mockito.when(projectRepository.findById(2L)).thenReturn(Optional.of(projekt));
        Mockito.when(userRepository.findByUsername("newuser")).thenReturn(Optional.of(user));
        Mockito.when(userRepository.save(Mockito.any(MyAppUser.class))).thenReturn(user);

        mockMvc.perform(post("/addusertoproject")
                        .param("projectid", "2")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(requestBody)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.message").value("User added successfully"));
    }
}
