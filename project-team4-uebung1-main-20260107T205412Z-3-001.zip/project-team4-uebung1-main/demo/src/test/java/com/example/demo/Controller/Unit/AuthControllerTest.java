package com.example.demo.Controller.Unit;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.lenient;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.example.demo.Controller.AuthController;
import com.example.demo.Model.Projekt.Projekt;
import com.example.demo.Model.User.MyAppUser;
import com.example.demo.Model.User.MyAppUserRepository;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.util.ReflectionTestUtils;

@ExtendWith(MockitoExtension.class)
public class AuthControllerTest {

    @InjectMocks
    private AuthController authController;

    @Mock
    private MyAppUserRepository userRepository;
    

    private AutoCloseable closeable;

    @BeforeEach
    public void setup() {
        // Initialisiere die Mocks
        closeable = MockitoAnnotations.openMocks(this);
        authController = new AuthController();
        // Setze das gemockte Repository in den Controller
        ReflectionTestUtils.setField(authController, "userRepository", userRepository);
    }

    @AfterEach
    public void tearDown() throws Exception {
        SecurityContextHolder.clearContext();
        closeable.close();
    }

    // U.AC.1
    @Test
    public void testGetAuthStatus_NoAuthentication() {
        SecurityContextHolder.clearContext();
        var response = authController.getAuthStatus(null);
        assertFalse((Boolean) response.get("isAuthenticated"));
    }

    // U.AC.2
    @Test
    public void testGetAuthStatus_WithoutAuthentication() {
        var response = authController.getAuthStatus(null);

        assertNotNull(response);
        assertTrue(response.containsKey("isAuthenticated"));
    }

    // U.AC.3
    @Test
    public void testGetAuthStatus_WithoutAuthenticationWithProjectId() {
        var response = authController.getAuthStatus("100");

        assertNotNull(response);
        assertTrue(response.containsKey("isAuthenticated"));
    }

    // U.AC.4
    @Test
    public void testGetAuthStatus_AuthenticatedWithInvalidProjectId() {
        SecurityContextHolder.getContext().setAuthentication(
            new UsernamePasswordAuthenticationToken("testuser", "password")
        );

        String username = "testuser";
        String invalidProjectId = "101";

        MyAppUser user = new MyAppUser();
        List<Projekt> projekte = new ArrayList<>();
        Projekt projekt = new Projekt();
        projekt.setId(100L); // Nicht passende Projekt-ID
        projekte.add(projekt);
        user.setProjekt(projekte);

        // Prüfe, ob die Authentifizierung korrekt gesetzt ist
        org.springframework.security.core.Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        assertNotNull(authentication, "Authentication sollte nicht null sein");
        assertNotNull(authentication.getName(), "Username sollte nicht null sein");

        lenient().when(userRepository.findByUsername(username)).thenReturn(Optional.of(user));


        var response = authController.getAuthStatus(invalidProjectId);

        assertNotNull(response, "Response sollte nicht null sein");
        assertFalse((Boolean) response.get("isAuthenticated"), "Benutzer sollte nicht authentifiziert sein");
    }

    // U.AC.5
    @Test
    public void testGetAuthStatus_AuthenticatedWithNonNumericProjectId() {
        String username = "testuser";
        String projectId = "abc"; // Nicht-numerische Projekt-ID
    
        // Setzen der Authentifizierung im SecurityContext
        SecurityContextHolder.getContext().setAuthentication(
            new UsernamePasswordAuthenticationToken(username, "password")
        );
    
        // Kein unnötiges Stubbing
        MyAppUser user = new MyAppUser();
        user.setProjekt(new ArrayList<>()); // Leere Projektliste
        lenient().when(userRepository.findByUsername(username)).thenReturn(Optional.of(user));

        // Methode aufrufen
        var response = authController.getAuthStatus(projectId);
    
        // Ergebnis überprüfen
        assertFalse((Boolean) response.get("isAuthenticated")); // Authentifizierung sollte fehlschlagen
    }
}