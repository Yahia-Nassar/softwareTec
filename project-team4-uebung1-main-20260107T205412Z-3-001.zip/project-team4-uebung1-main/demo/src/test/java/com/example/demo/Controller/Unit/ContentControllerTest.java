package com.example.demo.Controller.Unit;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import com.example.demo.Controller.ContentController;

@ExtendWith(MockitoExtension.class)
public class ContentControllerTest {

    private ContentController contentController;

    @BeforeEach
    public void setUp() {
        contentController = new ContentController();
    }

    // U.CC.1
    @Test
    public void testLogin() {
        String view = contentController.login();
        assertEquals("login", view, "Der Rückgabewert für /req/login muss 'login' sein.");
    }

    // U.CC.2
    @Test
    public void testSignup() {
        String view = contentController.signup();
        assertEquals("signup", view, "Der Rückgabewert für /req/signup muss 'signup' sein.");
    }

    // U.CC.3
    @Test
    public void testForgotPassword() {
        String view = contentController.forgotPassword();
        assertEquals("forgotPassword", view, "Der Rückgabewert für /forgot-password muss 'forgotPassword' sein.");
    }

    // U.CC.4
    @Test
    public void testProjects() {
        String view = contentController.projects();
        assertEquals("redirect:http://localhost:3000/projectselection", view,
                "Der Rückgabewert für /projects muss die Weiterleitung zur Projectselection sein.");
    }
}
