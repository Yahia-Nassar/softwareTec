package com.example.demo.Controller.Unit;

import com.example.demo.Model.User.MyAppUser;
import com.example.demo.Model.User.MyAppUserRepository;
import com.example.demo.Model.User.MyAppUserService;
import com.example.demo.Controller.ForgotPasswordController;
import com.example.demo.Model.User.EmailService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.BeforeEach;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
public class ForgotPasswordControllerTest {

    // Erstellt eine Instanz des Controllers und injiziert die gemockten Abhängigkeiten
    @InjectMocks
    private ForgotPasswordController forgotPasswordController;

    // Mocking der benötigten Abhängigkeiten
    @Mock
    private MyAppUserService userService;

    @Mock
    private EmailService emailService;

    @Mock
    private MyAppUserRepository userRepository;

    // Initialisiert die Mocks vor jedem Test
    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    // U.FPC.1
    @Test
    public void testProcessForgotPassword_UserExists() {

        // Erstellt ein Benutzerobjekt und setzt dessen E-Mail-Adresse
        MyAppUser user = new MyAppUser();
        user.setEmail("test@example.com");

        // Simuliert die Antwort des UserService, wenn nach der E-Mail gesucht wird
        when(userService.findByEmail("test@example.com")).thenReturn(user);

        // Führt die Methode aus und speichert die Rückgabe
        String response = forgotPasswordController.processForgotPassword("test@example.com");

        // Überprüft, ob der Benutzer gespeichert und eine E-Mail gesendet wurde
        verify(userRepository).save(user);
        verify(emailService).sendEmail(eq("test@example.com"), anyString(), anyString());

        // Stellt sicher, dass die Methode die richtige Redirect-URL zurückgibt
        assertEquals("redirect:/login?resetEmailSent", response);
    }

    // U.FPC.2
    @Test
    public void testProcessForgotPassword_UserNotFound() {

        // Simuliert, dass kein Benutzer mit der angegebenen E-Mail existiert
        when(userService.findByEmail("unknown@example.com")).thenReturn(null);

        // Führt die Methode aus und speichert die Rückgabe
        String response = forgotPasswordController.processForgotPassword("unknown@example.com");

        // Überprüft, dass der Benutzer nicht gespeichert und keine E-Mail gesendet wurde
        verify(userRepository, never()).save(any());
        verify(emailService, never()).sendEmail(anyString(), anyString(), anyString());

        // Stellt sicher, dass die Methode die richtige Redirect-URL zurückgibt
        assertEquals("redirect:/forgot-password?error", response);
    }
}
