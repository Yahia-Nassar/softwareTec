package com.example.demo.Controller.Unit;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import com.example.demo.Controller.Ist_mitgliedController;
import com.example.demo.Model.Ist_mitglied.ist_mitglied;
import com.example.demo.Model.Ist_mitglied.ist_mitgliedService;
import com.example.demo.Model.Nutzer.Nutzer;
import com.example.demo.Model.Nutzer.NutzerService;
import com.example.demo.Model.Team.Team;
import com.example.demo.Model.Team.TeamService;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

@ExtendWith(MockitoExtension.class)
public class Ist_mitgliedControllerTest {

    @InjectMocks
    private Ist_mitgliedController controller;

    @Mock
    private ist_mitgliedService ist_mitgliedService;

    @Mock
    private NutzerService nutzerService;

    @Mock
    private TeamService teamService;

    private AutoCloseable closeable;

    @BeforeEach
    public void setup() {
        closeable = MockitoAnnotations.openMocks(this);
    }
    
    @AfterEach
    public void tearDown() throws Exception {
        closeable.close();
    }

    // U.IC.1
    @SuppressWarnings("null")
    @Test
    public void testCreateIstMitgliedSuccess() {
        // -- Vorbereiten: Nutzer und Prev_Team müssen vorhanden sein
        Nutzer nutzer = new Nutzer();
        nutzer.setNutzer_id(1L);

        Team team = new Team();
        team.setId(10L);

        ist_mitglied inputIstMitglied = new ist_mitglied();
        inputIstMitglied.setRolle("Rolle1");
        inputIstMitglied.setNutzer(nutzer);
        inputIstMitglied.setTeam(team);

        // -- Mocks einrichten
        when(nutzerService.getNutzerById(1L)).thenReturn(Optional.of(nutzer));
        when(teamService.getTeamById(10L)).thenReturn(Optional.of(team));
        when(ist_mitgliedService.saveIst_mitglied(any(ist_mitglied.class))).thenReturn(inputIstMitglied);

        // -- Aufruf des Controllers
        ResponseEntity<ist_mitglied> response = controller.createIst_mitglied(inputIstMitglied);

        // -- Verifikationen
        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("Rolle1", response.getBody().getRolle());
    }

    // U.IC.2
    @Test
    public void testUpdateIstMitglied_Existing() {
        // -- Bestehendes Mitglied vorbereiten
        ist_mitglied ist_mitglied = new ist_mitglied();
        ist_mitglied.setRolle("Alt");
        ist_mitglied.setNutzer(new Nutzer());
        ist_mitglied.setTeam(new Team());
        
        // -- Neues Update-Payload
        ist_mitglied neues = new ist_mitglied();
        neues.setRolle("Neu");

        // -- Mocks: Ressource gefunden
        when(ist_mitgliedService.getIst_mitgliedById(1L)).thenReturn(Optional.of(ist_mitglied));
        when(ist_mitgliedService.saveIst_mitglied(any(ist_mitglied.class))).thenReturn(ist_mitglied);

        ResponseEntity<ist_mitglied> response = controller.updateIst_mitglied(neues, 1L);
        
        // -- Überprüfen: Es wird ein Update durchgeführt, Status OK
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("Neu", ist_mitglied.getRolle());
    }

    // U.IC.3
    @Test
    public void testUpdateIstMitglied_NotExisting() {
        // -- Neues Payload
        ist_mitglied ist_mitglied = new ist_mitglied();
        ist_mitglied.setRolle("Neu");

        // -- Mocks: Ressource nicht gefunden
        when(ist_mitgliedService.getIst_mitgliedById(1L)).thenReturn(Optional.empty());
        when(ist_mitgliedService.saveIst_mitglied(ist_mitglied)).thenReturn(ist_mitglied);

        ResponseEntity<ist_mitglied> response = controller.updateIst_mitglied(ist_mitglied, 1L);
        
        // -- Da nicht vorhanden, soll NEW erstellt werden, Status CREATED
        assertEquals(HttpStatus.CREATED, response.getStatusCode());
    }

    // U.IC.4
    @Test
    public void testGetAllIstMitglied() {
        ist_mitglied ist_mitglied1 = new ist_mitglied(); ist_mitglied1.setRolle("A");
        ist_mitglied ist_mitglied2 = new ist_mitglied(); ist_mitglied2.setRolle("B");
        List<ist_mitglied> list = new ArrayList<>(Arrays.asList(ist_mitglied1, ist_mitglied2));
        
        when(ist_mitgliedService.getAllIst_mitglied()).thenReturn(list);
        
        List<ist_mitglied> result = controller.getAllIst_mitglied();
        assertEquals(2, result.size());
    }

    // U.IC.5
    @Test
    public void testGetIstMitgliedById() {
        ist_mitglied ist_mitglied = new ist_mitglied();
        ist_mitglied.setRolle("Test");
        when(ist_mitgliedService.getIst_mitgliedById(1L)).thenReturn(Optional.of(ist_mitglied));
        
        Optional<ist_mitglied> result = controller.getIst_mitgliedById(1L);
        assertTrue(result.isPresent());
        assertEquals("Test", result.get().getRolle());
    }

    // U.IC.6
    @Test
    public void testDeleteIstMitgliedById() {
        controller.deleteIst_mitgliedById(1L);
        verify(ist_mitgliedService, times(1)).deleteIst_mitgliedById(1L);
    }
}