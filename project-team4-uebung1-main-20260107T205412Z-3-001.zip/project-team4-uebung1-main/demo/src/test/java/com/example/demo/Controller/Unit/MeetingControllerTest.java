package com.example.demo.Controller.Unit;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.authentication.TestingAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;

import com.example.demo.Controller.MeetingController;
import com.example.demo.Model.Meetings.Meeting;
import com.example.demo.Model.Meetings.MeetingRepository;
import com.example.demo.Model.Projekt.Projekt;
import com.example.demo.Model.Projekt.ProjektRepository;
import com.example.demo.Model.User.MyAppUser;
import com.example.demo.Model.User.MyAppUserRepository;

@ExtendWith(MockitoExtension.class)
public class MeetingControllerTest {

    @InjectMocks
    private MeetingController meetingController;

    @Mock
    private MyAppUserRepository userRepository;

    @Mock
    private ProjektRepository projectRepository;

    @Mock
    private MeetingRepository meetingRepository;


    @BeforeEach
    void setUp() {
        SecurityContextHolder.getContext().setAuthentication(
            new TestingAuthenticationToken("testuser", null)
        );
    }

    // U.MC.1
    @Test
    void testGetAllMeetings() {
        // Testdaten erstellen
        Projekt projekt = new Projekt();
        projekt.setId(1L);

        MyAppUser user = new MyAppUser();
        user.setId(2L);

        Meeting meeting = new Meeting();
        meeting.setDescription("Projekt Kickoff");
        meeting.setUsers(List.of(user));

        projekt.setMeetings(List.of(meeting));

        // Mock-Verhalten definieren
        when(projectRepository.findById(1L)).thenReturn(Optional.of(projekt));
        when(userRepository.findByUsername(anyString())).thenReturn(Optional.of(user));

        // Testmethode aufrufen
        List<Meeting> result = meetingController.getAllMeetings("1");

        // Überprüfen, ob die erwarteten Ergebnisse zurückgegeben werden
        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals("Projekt Kickoff", result.get(0).getDescription());
    }

    // U.MC.2
    @Test
    void testCreateMeetings() {
        Projekt projekt = new Projekt();
        projekt.setId(1L);

        MyAppUser user = new MyAppUser();
        user.setId(2L);

        Meeting meeting = new Meeting();
        meeting.setDescription("Team Meeting");

        // Mock-Verhalten definieren
        when(projectRepository.findById(1L)).thenReturn(Optional.of(projekt));
        when(userRepository.findByUsername(anyString())).thenReturn(Optional.of(user));
        when(meetingRepository.save(any(Meeting.class))).thenReturn(meeting);

        // Testmethode aufrufen
        List<Meeting> meetings = meetingController.createMeetings(List.of(meeting), "1");

        // Überprüfung
        assertNotNull(meetings);
        assertEquals(1, meetings.size());
        assertEquals("Team Meeting", meetings.get(0).getDescription());
    }
}