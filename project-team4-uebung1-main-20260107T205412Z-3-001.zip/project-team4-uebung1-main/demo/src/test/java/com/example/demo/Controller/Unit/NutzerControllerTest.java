package com.example.demo.Controller.Unit;

import com.example.demo.Controller.NutzerController;
import com.example.demo.Model.Nutzer.Nutzer;
import com.example.demo.Model.Nutzer.NutzerService;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class NutzerControllerTest {

    @Mock
    private NutzerService nutzerService;

    @InjectMocks
    private NutzerController nutzerController;

    // U.NC.1
    @Test
    public void testCreateNutzer() {
        Nutzer nutzer = new Nutzer();
        when(nutzerService.saveNutzer(any(Nutzer.class))).thenReturn(nutzer);

        ResponseEntity<Nutzer> response = nutzerController.createNutzer(nutzer);

        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        assertEquals(nutzer, response.getBody());
        verify(nutzerService, times(1)).saveNutzer(any(Nutzer.class));
    }

    // U.NC.2
    @Test
    public void testUpdateNutzer() {
        Nutzer neuerNutzer = new Nutzer();
        Nutzer existingNutzer = new Nutzer();
        when(nutzerService.getNutzerById(1L)).thenReturn(Optional.of(existingNutzer));
        when(nutzerService.saveNutzer(any(Nutzer.class))).thenReturn(existingNutzer);

        ResponseEntity<Nutzer> response = nutzerController.updateNutzer(neuerNutzer, 1L);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(existingNutzer, response.getBody());
        verify(nutzerService, times(1)).getNutzerById(1L);
        verify(nutzerService, times(1)).saveNutzer(any(Nutzer.class));
    }

    // U.NC.3
    @Test
    public void testGetAllNutzer() {
        List<Nutzer> nutzerList = Arrays.asList(new Nutzer(), new Nutzer());
        when(nutzerService.getAllNutzer()).thenReturn(nutzerList);

        List<Nutzer> result = nutzerController.getAllNutzer();

        assertEquals(2, result.size());
        verify(nutzerService, times(1)).getAllNutzer();
    }

    // U.NC.4
    @Test
    public void testDeleteNutzer() {
        doNothing().when(nutzerService).deleteNutzer(1L);

        nutzerController.deleteNutzer(1L);

        verify(nutzerService, times(1)).deleteNutzer(1L);
    }
}