package com.example.demo.Controller.Unit;

import com.example.demo.Controller.ProfileController;
import com.example.demo.Model.Projekt.Projekt;
import com.example.demo.Model.Projekt.ProjektRepository;
import com.example.demo.Model.Role.Role;
import com.example.demo.Model.Role.RoleEnum;
import com.example.demo.Model.Role.RoleId;
import com.example.demo.Model.Role.RoleRepository;
import com.example.demo.Model.User.MyAppUser;
import com.example.demo.Model.User.MyAppUserRepository;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class ProfileControllerTest {

    @InjectMocks
    private ProfileController profileController;

    @Mock
    private MyAppUserRepository userRepository;

    @Mock
    private RoleRepository roleRepository;

    @Mock
    private ProjektRepository projektRepository;

    @Mock
    private SecurityContext securityContext;

    @Mock
    private Authentication authentication;

    @BeforeEach
    void setupSecurityContext() {
        SecurityContextHolder.setContext(securityContext);
    }

    // U.POC.1
    @Test
    public void editRole_validInput_shouldUpdateRoleAndReturnOk() {
        // Arrange
        String projectId = "1";
        Long parsedId = 1L;

        Role newRole = new Role();
        newRole.setRole(RoleEnum.DEVELOPER);

        Projekt projekt = new Projekt();
        projekt.setId(parsedId);

        MyAppUser user = new MyAppUser();
        user.setId(42L);
        user.setUsername("tester");

        RoleId roleId = new RoleId(user.getId(), projekt.getId());
        Role existingRole = new Role();
        existingRole.setId(roleId);
        existingRole.setRole(RoleEnum.PRODUCT_OWNER);

        // Mock Security
        when(securityContext.getAuthentication()).thenReturn(authentication);
        when(authentication.isAuthenticated()).thenReturn(true);
        when(authentication.getName()).thenReturn("tester");

        // Repository mocks
        when(projektRepository.findById(parsedId)).thenReturn(Optional.of(projekt));
        when(userRepository.findByUsername("tester")).thenReturn(Optional.of(user));
        when(roleRepository.findById(any(RoleId.class))).thenReturn(Optional.of(existingRole)); // Wichtig!

        // Act
        ResponseEntity<Void> response = profileController.editRole(newRole, projectId);

        // Assert
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(RoleEnum.DEVELOPER, existingRole.getRole());
        verify(roleRepository).save(existingRole);
    }

    // U.POC.2
    @Test
    public void editRole_unauthenticated_shouldReturnUnauthorized() {
        when(securityContext.getAuthentication()).thenReturn(authentication);
        when(authentication.isAuthenticated()).thenReturn(false);

        ResponseEntity<Void> response = profileController.editRole(new Role(), "1");

        assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
    }

    // U.POC.3
    @Test
    public void editRole_projectNotFound_shouldReturnNotFound() {
        // Arrange
        String projectId = "1";
        Long parsedId = 1L;

        // Authentifizierung mocken – isAuthenticated reicht hier völlig
        when(securityContext.getAuthentication()).thenReturn(authentication);
        when(authentication.isAuthenticated()).thenReturn(true);

        // Projekt nicht vorhanden
        when(projektRepository.findById(parsedId)).thenReturn(Optional.empty());

        // Act
        ResponseEntity<Void> response = profileController.editRole(new Role(), projectId);

        // Assert
        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
    }

    // U.POC.4
    @Test
    public void editRole_userNotFound_shouldReturnUnauthorized() {
        Projekt projekt = new Projekt();
        projekt.setId(1L);

        when(securityContext.getAuthentication()).thenReturn(authentication);
        when(authentication.isAuthenticated()).thenReturn(true);
        when(authentication.getName()).thenReturn("tester");
        when(projektRepository.findById(1L)).thenReturn(Optional.of(projekt));
        when(userRepository.findByUsername("tester")).thenReturn(Optional.empty());

        ResponseEntity<Void> response = profileController.editRole(new Role(), "1");

        assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
    }
}
