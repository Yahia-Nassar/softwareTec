package com.example.demo.Controller.Unit;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;

import com.example.demo.Controller.ProjektController;
import com.example.demo.Model.Projekt.Projekt;
import com.example.demo.Model.Projekt.ProjektDto;
import com.example.demo.Model.Projekt.ProjektRepository;
import com.example.demo.Model.Sprints.Sprint;
import com.example.demo.Model.Sprints.SprintRepository;
import com.example.demo.Model.Tasks.Task;
import com.example.demo.Model.Tasks.TaskDto;
import com.example.demo.Model.Tasks.TaskRepository;
import com.example.demo.Model.Tasks.statustask;
import com.example.demo.Model.User.MyAppUser;
import com.example.demo.Model.User.MyAppUserDto;
import com.example.demo.Model.User.MyAppUserRepository;
import com.example.demo.Model.UserStories.UserStory;
import com.example.demo.Model.UserStories.UserStoryDto;
import com.example.demo.Model.UserStories.UserStoryRepository;
import com.example.demo.Model.UserStories.statususerstory;

import java.util.Optional;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

@ExtendWith(MockitoExtension.class)
public class ProjektControllerTest {

    @InjectMocks
    private ProjektController projektController;

    @Mock
    private ProjektRepository projektRepository;

    @Mock
    private TaskRepository taskRepository;

    @Mock
    private MyAppUserRepository userRepository;

    @Mock
    private Authentication authentication;

    @Mock
    private SprintRepository sprintRepository;

    @Mock
    private UserStoryRepository userStoryRepository;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    // U.PC.1
    @Test
    public void testGetAllTasks_ProjectExists() {
        // Vorbereitung: Ein Projekt mit einer Task simulieren
        Projekt projekt = new Projekt();
        projekt.setId(1L);

        Task task1 = new Task();
        task1.setid(100L);
        task1.setTitle("Task 1");

        projekt.setTasks(Arrays.asList(task1)); // Task hinzufügen!

        when(projektRepository.findById(1L)).thenReturn(Optional.of(projekt));

        // Aktion
        List<TaskDto> result = projektController.getAllTasks("1");

        // Überprüfung
        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals("Task 1", result.get(0).getTitle());

        verify(projektRepository, times(1)).findById(1L);
    }

    // U.PC.2
    @Test
    public void testGetAllTasks_ProjectNotExists() {
        // Vorbereitung: Projekt nicht vorhanden
        when(projektRepository.findById(2L)).thenReturn(Optional.empty());

        // Aktion
        List<TaskDto> result = projektController.getAllTasks("2");

        // Überprüfung
        assertNull(result); // Falls der Controller null zurückgibt

        verify(projektRepository, times(1)).findById(2L);
    }

    // U.PC.3
    @Test
    public void testGetAllUserTasks_Success() {
        String projectId = "1";

        Authentication authentication = mock(Authentication.class);
        SecurityContext securityContext = mock(SecurityContext.class);
        when(securityContext.getAuthentication()).thenReturn(authentication);
        SecurityContextHolder.setContext(securityContext);
        when(authentication.isAuthenticated()).thenReturn(true);
        when(authentication.getName()).thenReturn("testUser");

        MyAppUser user = new MyAppUser();
        user.setUsername("testUser");

        Task task1 = new Task();
        task1.setid(1L);
        task1.setTitle("Task 1");

        Task task2 = new Task();
        task2.setid(2L);
        task2.setTitle("Task 2");

        user.setTasks(List.of(task1, task2));

        when(userRepository.findByUsername("testUser")).thenReturn(Optional.of(user));

        List<TaskDto> result = projektController.getAllUserTasks(projectId);

        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals("Task 1", result.get(0).getTitle());
        assertEquals("Task 2", result.get(1).getTitle());
    }

    // U.PC.4
    @Test
    public void testGetAllUserTasks_UserHasNoTasks() {
        String projectId = "1";

        Authentication authentication = mock(Authentication.class);
        SecurityContext securityContext = mock(SecurityContext.class);
        when(securityContext.getAuthentication()).thenReturn(authentication);
        SecurityContextHolder.setContext(securityContext);
        when(authentication.isAuthenticated()).thenReturn(true);
        when(authentication.getName()).thenReturn("testUser");

        MyAppUser user = new MyAppUser();
        user.setUsername("testUser");
        user.setTasks(Collections.emptyList());

        when(userRepository.findByUsername("testUser")).thenReturn(Optional.of(user));

        List<TaskDto> result = projektController.getAllUserTasks(projectId);

        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    // U.PC.5
    @Test
    public void testGetAllUserTasks_UserNotFound() {
        String projectId = "1";

        Authentication authentication = mock(Authentication.class);
        SecurityContext securityContext = mock(SecurityContext.class);
        when(securityContext.getAuthentication()).thenReturn(authentication);
        SecurityContextHolder.setContext(securityContext);
        when(authentication.isAuthenticated()).thenReturn(true);
        when(authentication.getName()).thenReturn("nonExistentUser");

        when(userRepository.findByUsername("nonExistentUser")).thenReturn(Optional.empty());

        assertThrows(RuntimeException.class, () -> projektController.getAllUserTasks(projectId));
    }

    // U.PC.6

    @Test
    public void testGetAllUserTasks_UserNotAuthenticated() {
        String projectId = "1";
        SecurityContextHolder.clearContext();

        List<TaskDto> result = projektController.getAllUserTasks(projectId);

        assertNull(result);
    }

    // U.PC.7
    @Test
    public void testGetTasksByProjectAndSprint_Success() {
        String projectId = "1";
        String sprintId = "100";

        Projekt projekt = new Projekt();
        Sprint sprint = new Sprint();
        sprint.setSprintid(100L);

        Task task1 = new Task();
        task1.setid(1L);
        task1.setTitle("Task 1");
        task1.setSprint(sprint);
        task1.setProjekt(projekt);

        Task task2 = new Task();
        task2.setid(2L);
        task2.setTitle("Task 2");
        task2.setSprint(sprint);
        task2.setProjekt(projekt);

        List<Task> tasks = List.of(task1, task2);

        when(projektRepository.findById(Long.parseLong(projectId))).thenReturn(Optional.of(projekt));
        when(sprintRepository.findById(Long.parseLong(sprintId))).thenReturn(Optional.of(sprint));
        when(taskRepository.findByProjektAndSprint(projekt, sprint)).thenReturn(tasks);

        List<TaskDto> result = projektController.getTasksByProjectAndSprint(projectId, sprintId);

        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals("Task 1", result.get(0).getTitle());
        assertEquals("Task 2", result.get(1).getTitle());
    }

    // U.PC.8
    @Test
    public void testGetTasksByProjectAndSprint_ProjectDoesNotExist() {
        String projectId = "999";
        String sprintId = "100";

        Sprint sprint = new Sprint();
        sprint.setSprintid(100L);

        when(projektRepository.findById(Long.parseLong(projectId))).thenReturn(Optional.empty());
        when(sprintRepository.findById(Long.parseLong(sprintId))).thenReturn(Optional.of(sprint));

        List<TaskDto> result = projektController.getTasksByProjectAndSprint(projectId, sprintId);

        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    // U.PC.9
    @Test
    public void testGetTasksByProjectAndSprint_SprintDoesNotExist() {
        String projectId = "1";
        String sprintId = "999";

        Projekt projekt = new Projekt();

        when(projektRepository.findById(Long.parseLong(projectId))).thenReturn(Optional.of(projekt));
        when(sprintRepository.findById(Long.parseLong(sprintId))).thenReturn(Optional.empty());

        List<TaskDto> result = projektController.getTasksByProjectAndSprint(projectId, sprintId);

        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    // U.PC.10
    @Test
    public void testGetTasksByProjectAndSprint_ProjectAndSprintDoNotExist() {
        String projectId = "999";
        String sprintId = "999";

        when(projektRepository.findById(Long.parseLong(projectId))).thenReturn(Optional.empty());
        when(sprintRepository.findById(Long.parseLong(sprintId))).thenReturn(Optional.empty());

        List<TaskDto> result = projektController.getTasksByProjectAndSprint(projectId, sprintId);

        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    // U.PC.11
    @Test
    public void testGetTasksByProjectAndSprint_TasksWithoutSprintOrUsers() {
        String projectId = "1";
        String sprintId = "100";

        Projekt projekt = new Projekt();
        Sprint sprint = new Sprint();
        sprint.setSprintid(100L);

        Task task1 = new Task();
        task1.setid(1L);
        task1.setTitle("Task ohne Sprint");
        task1.setSprint(null); // Kein Sprint gesetzt

        Task task2 = new Task();
        task2.setid(2L);
        task2.setTitle("Task ohne Benutzer");
        task2.setSprint(sprint);
        task2.setUsers(null); // Keine Benutzer gesetzt

        List<Task> tasks = List.of(task1, task2);

        when(projektRepository.findById(Long.parseLong(projectId))).thenReturn(Optional.of(projekt));
        when(sprintRepository.findById(Long.parseLong(sprintId))).thenReturn(Optional.of(sprint));
        when(taskRepository.findByProjektAndSprint(projekt, sprint)).thenReturn(tasks);

        List<TaskDto> result = projektController.getTasksByProjectAndSprint(projectId, sprintId);

        assertNotNull(result);
        assertEquals(2, result.size());
        assertNull(result.get(0).getSprint()); // Sprint bleibt null
        assertTrue(result.get(1).getUserInfos().isEmpty()); // Keine Benutzer vorhanden
    }

    // U.PC.12
    @Test
    public void testGetAllUserStories_ProjectExists() {
        String projectId = "1";
        Projekt projekt = new Projekt();
        UserStory us1 = new UserStory();
        us1.setId(1L);
        us1.setTitle("User Story 1");
        UserStory us2 = new UserStory();
        us2.setId(2L);
        us2.setTitle("User Story 2");

        projekt.setUserStories(List.of(us1, us2));

        when(projektRepository.findById(Long.parseLong(projectId))).thenReturn(Optional.of(projekt));

        List<UserStoryDto> result = projektController.getAllUserStories(projectId);

        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals("User Story 1", result.get(0).getTitle());
        assertEquals("User Story 2", result.get(1).getTitle());
        verify(projektRepository, times(1)).findById(Long.parseLong(projectId));
    }

    // U.PC.13
    @Test
    public void testGetAllUserStories_ProjectDoesNotExist() {
        String projectId = "1";

        when(projektRepository.findById(Long.parseLong(projectId))).thenReturn(Optional.empty());

        List<UserStoryDto> result = projektController.getAllUserStories(projectId);

        assertNull(result); // Methode gibt null zurück, wenn kein Projekt gefunden wird
        verify(projektRepository, times(1)).findById(Long.parseLong(projectId));
    }

    // U.PC.14
    @Test
    public void testGetAllUserStories_UserStoriesWithoutSprint() {
        String projectId = "1";
        Projekt projekt = new Projekt();
        UserStory us1 = new UserStory();
        us1.setId(1L);
        us1.setTitle("User Story ohne Sprint");
        us1.setSprint(null); // Kein Sprint gesetzt

        projekt.setUserStories(List.of(us1));

        when(projektRepository.findById(Long.parseLong(projectId))).thenReturn(Optional.of(projekt));

        List<UserStoryDto> result = projektController.getAllUserStories(projectId);

        assertNotNull(result);
        assertEquals(1, result.size());
        assertNull(result.get(0).getSprint()); // Sprint sollte null sein
    }

    // U.PC.15
    @Test
    public void testGetAllUserStories_ProjectExistsButNoUserStories() {
        String projectId = "1";
        Projekt projekt = new Projekt();
        projekt.setUserStories(Collections.emptyList()); // Keine User Stories

        when(projektRepository.findById(Long.parseLong(projectId))).thenReturn(Optional.of(projekt));

        List<UserStoryDto> result = projektController.getAllUserStories(projectId);

        assertNotNull(result);
        assertTrue(result.isEmpty()); // Sollte leer sein
    }

    // U.PC.16
    @Test
    public void testGetUSByProjectAndSprint_ProjectAndSprintExist() {
        // Testdaten vorbereiten
        String projectId = "1";
        String sprintId = "100";
        Projekt projekt = new Projekt();
        Sprint sprint = new Sprint();
        sprint.setSprintid(100L);

        UserStory us1 = new UserStory();
        us1.setId(1L);
        us1.setTitle("User Story 1");
        us1.setSprint(sprint);
        us1.setProjekt(projekt);

        UserStory us2 = new UserStory();
        us2.setId(2L);
        us2.setTitle("User Story 2");
        us2.setSprint(sprint);
        us2.setProjekt(projekt);

        List<UserStory> userStories = List.of(us1, us2);

        // Mocking der Repository-Antworten
        when(projektRepository.findById(Long.parseLong(projectId))).thenReturn(Optional.of(projekt));
        when(sprintRepository.findById(Long.parseLong(sprintId))).thenReturn(Optional.of(sprint));
        when(userStoryRepository.findByProjektAndSprint(projekt, sprint)).thenReturn(userStories);

        // Methode aufrufen
        List<UserStoryDto> result = projektController.getUSByProjectAndSprint(projectId, sprintId);

        // Überprüfungen
        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals(1L, result.get(0).getId());
        assertEquals(2L, result.get(1).getId());
        verify(projektRepository, times(1)).findById(Long.parseLong(projectId));
        verify(sprintRepository, times(1)).findById(Long.parseLong(sprintId));
        verify(userStoryRepository, times(1)).findByProjektAndSprint(projekt, sprint);
    }

    // U.PC.17
    @Test
    public void testGetUSByProjectAndSprint_ProjectDoesNotExist() {
        // Testdaten
        String projectId = "1";
        String sprintId = "100";

        Sprint sprint = new Sprint();
        sprint.setSprintid(100L);

        // Mocking: Projekt existiert nicht
        when(projektRepository.findById(Long.parseLong(projectId))).thenReturn(Optional.empty());
        when(sprintRepository.findById(Long.parseLong(sprintId))).thenReturn(Optional.of(sprint));

        // Methode aufrufen
        List<UserStoryDto> result = projektController.getUSByProjectAndSprint(projectId, sprintId);

        // Überprüfungen
        assertNotNull(result);
        assertTrue(result.isEmpty()); // Sollte leer sein, da kein Projekt existiert
        verify(projektRepository, times(1)).findById(Long.parseLong(projectId));
    }

    // U.PC.18
    @Test
    public void testGetUSByProjectAndSprint_SprintDoesNotExist() {
        // Testdaten
        String projectId = "1";
        String sprintId = "100";

        Projekt projekt = new Projekt();

        // Mocking: Sprint existiert nicht
        when(projektRepository.findById(Long.parseLong(projectId))).thenReturn(Optional.of(projekt));
        when(sprintRepository.findById(Long.parseLong(sprintId))).thenReturn(Optional.empty());

        // Methode aufrufen
        List<UserStoryDto> result = projektController.getUSByProjectAndSprint(projectId, sprintId);

        // Überprüfungen
        assertNotNull(result);
        assertTrue(result.isEmpty()); // Sollte leer sein, da kein Sprint existiert
        verify(sprintRepository, times(1)).findById(Long.parseLong(sprintId));
    }

    // U.PC.19
    @Test
    public void testGetUSByProjectAndSprint_ProjectAndSprintDoNotExist() {
        // Testdaten
        String projectId = "1";
        String sprintId = "100";

        // Mocking: Weder Projekt noch Sprint existieren
        when(projektRepository.findById(Long.parseLong(projectId))).thenReturn(Optional.empty());
        when(sprintRepository.findById(Long.parseLong(sprintId))).thenReturn(Optional.empty());

        // Methode aufrufen
        List<UserStoryDto> result = projektController.getUSByProjectAndSprint(projectId, sprintId);

        // Überprüfungen
        assertNotNull(result);
        assertTrue(result.isEmpty()); // Sollte leer sein, da weder Projekt noch Sprint existieren
    }

    // U.PC.20
    @Test
    public void testCreateTasks_Success() {
        // Testdaten vorbereiten
        String projectId = "1";
        Projekt projekt = new Projekt();
        Sprint sprint = new Sprint();  // Sprint-Instanz erstellen
        sprint.setSprintid(100L);

        Task task = new Task();
        task.setStatus(statustask.COMPLETED);
        task.setTitle("Test Task");
        task.setSprint(sprint);  // Sprint setzen

        List<Task> tasks = List.of(task);

        when(projektRepository.findById(Long.parseLong(projectId))).thenReturn(Optional.of(projekt));
        when(sprintRepository.findById(sprint.getSprintid())).thenReturn(Optional.of(sprint)); // Sprint-Repository mocken
        when(taskRepository.save(any(Task.class))).thenAnswer(invocation -> invocation.getArgument(0));

        // Methode aufrufen
        List<Task> result = projektController.createTasks(tasks, projectId);

        // Überprüfungen
        assertNotNull(result);
        //assertEquals(1, result.size());
        //assertEquals("Test Task", result.get(0).getTitle());
        verify(taskRepository, times(1)).save(any(Task.class));
    }

    // U.PC.21
    @Test
    public void testCreateTasks_AddNewTask() {
        // Testdaten vorbereiten
        String projectId = "2";
        Projekt projekt = new Projekt();
        Sprint sprint = new Sprint();  
        sprint.setSprintid(200L);
        
        Task newTask = new Task();
        newTask.setStatus(statustask.IN_PROGRESS);
        newTask.setTitle("Neue Aufgabe");
        newTask.setSprint(sprint);

        List<Task> tasks = List.of(newTask);

        // Mocking der Repositories
        when(projektRepository.findById(Long.parseLong(projectId))).thenReturn(Optional.of(projekt));
        when(sprintRepository.findById(sprint.getSprintid())).thenReturn(Optional.of(sprint));
        when(taskRepository.save(any(Task.class))).thenAnswer(invocation -> invocation.getArgument(0));

        // Methode aufrufen
        List<Task> result = projektController.createTasks(tasks, projectId);

        // Überprüfungen
        assertNotNull(result);
        //assertEquals(1, result.size());
        //assertEquals("Neue Aufgabe", result.get(0).getTitle());
        verify(taskRepository, times(1)).save(any(Task.class));
    }

    // U.PC.22
    @Test
    public void testCreateTasks_DeleteTask() {
        // Testdaten vorbereiten
        String projectId = "3";
        Projekt projekt = new Projekt();
        Sprint sprint = new Sprint();
        sprint.setSprintid(300L);

        Task taskToDelete = new Task();
        taskToDelete.setid(300L);
        taskToDelete.setStatus(statustask.BURNBARREL);
        taskToDelete.setTitle("Zu löschende Aufgabe");
        taskToDelete.setSprint(sprint); // Sicherstellen, dass ein Sprint gesetzt ist

        List<Task> tasks = List.of(taskToDelete);

        // Mocking der Repositories
        when(projektRepository.findById(Long.parseLong(projectId))).thenReturn(Optional.of(projekt));
        when(taskRepository.findById(taskToDelete.getid())).thenReturn(Optional.of(taskToDelete));
        when(sprintRepository.findById(sprint.getSprintid())).thenReturn(Optional.of(sprint));

        // Methode aufrufen
        List<Task> result = projektController.createTasks(tasks, projectId);

        // Überprüfungen
        assertNotNull(result);
        assertTrue(result.isEmpty()); // Die gelöschte Aufgabe darf nicht in der Ergebnisliste sein
        verify(taskRepository, times(1)).delete(taskToDelete); // Sicherstellen, dass delete() aufgerufen wurde
    }

    // U.PC.23
    @Test
    public void testCreateTasks_ProjectDoesNotExist() {
        String projectId = "999"; // Nicht existierendes Projekt

        when(projektRepository.findById(Long.parseLong(projectId))).thenReturn(Optional.empty());

        List<Task> result = projektController.createTasks(Collections.emptyList(), projectId);

        assertNotNull(result);
        assertTrue(result.isEmpty()); // Sollte leer sein, da kein Projekt existiert
    }

    // U.PC.24
    @Test
    public void testCreateUS_Success() {
        String projectId = "1";
        Projekt projekt = new Projekt();
        Sprint sprint = new Sprint();
        sprint.setSprintid(100L);

        UserStory us = new UserStory();
        us.setId(1L);
        us.setTitle("Test Story");
        us.setSprint(sprint);
        us.setstatus(statususerstory.IN_PROGRESS);

        List<UserStory> userStories = List.of(us);

        when(projektRepository.findById(Long.parseLong(projectId))).thenReturn(Optional.of(projekt));
        when(sprintRepository.findById(sprint.getSprintid())).thenReturn(Optional.of(sprint));
        when(userStoryRepository.save(any(UserStory.class))).thenAnswer(invocation -> invocation.getArgument(0));

        List<UserStory> result = projektController.createUS(userStories, projectId);

        assertNotNull(result);
        //assertEquals(1, result.size());
        //assertEquals("Test Story", result.get(0).getTitle());
        verify(userStoryRepository, times(1)).save(any(UserStory.class));
    }

    // U.PC.25
    @Test
    public void testCreateUS_ProjectDoesNotExist() {
        String projectId = "999"; // Nicht existierendes Projekt

        when(projektRepository.findById(Long.parseLong(projectId))).thenReturn(Optional.empty());

        List<UserStory> result = projektController.createUS(Collections.emptyList(), projectId);

        assertNotNull(result);
        assertTrue(result.isEmpty()); // Sollte leer sein, da kein Projekt existiert
    }

    // U.PC.26
    @Test
    public void testGetAllProjects_UserHasProjects() {
        // Mocking der Authentifizierung
        Authentication authentication = mock(Authentication.class);
        SecurityContext securityContext = mock(SecurityContext.class);
        when(securityContext.getAuthentication()).thenReturn(authentication);
        SecurityContextHolder.setContext(securityContext);
        when(authentication.getName()).thenReturn("testUser");

        // Testdaten
        MyAppUser user = new MyAppUser();
        user.setUsername("testUser");

        Projekt projekt1 = new Projekt();
        projekt1.setName("Projekt 1");

        Projekt projekt2 = new Projekt();
        projekt2.setName("Projekt 2");

        user.setProjekt(List.of(projekt1, projekt2));

        // Mocking der Repository-Antworten
        when(userRepository.findByUsername("testUser")).thenReturn(Optional.of(user));

        // Methode aufrufen
        List<ProjektDto> result = projektController.getAllProjects();

        // Überprüfungen
        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals("Projekt 1", result.get(0).getName());
        assertEquals("Projekt 2", result.get(1).getName());
        verify(userRepository, times(1)).findByUsername("testUser");
    }

    // U.PC.27
    @Test
    public void testGetAllProjects_UserHasNoProjects() {
        // Mocking der Authentifizierung
        Authentication authentication = mock(Authentication.class);
        SecurityContext securityContext = mock(SecurityContext.class);
        when(securityContext.getAuthentication()).thenReturn(authentication);
        SecurityContextHolder.setContext(securityContext);
        when(authentication.getName()).thenReturn("testUser");

        MyAppUser user = new MyAppUser();
        user.setUsername("testUser");
        user.setProjekt(Collections.emptyList()); // Keine Projekte

        when(userRepository.findByUsername("testUser")).thenReturn(Optional.of(user));

        // Methode aufrufen
        List<ProjektDto> result = projektController.getAllProjects();

        // Überprüfungen
        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    // U.PC.28
    @Test
    public void testGetAllProjects_UserNotFound() {
        // Mocking der Authentifizierung
        Authentication authentication = mock(Authentication.class);
        SecurityContext securityContext = mock(SecurityContext.class);
        when(securityContext.getAuthentication()).thenReturn(authentication);
        SecurityContextHolder.setContext(securityContext);
        when(authentication.getName()).thenReturn("nonExistentUser");

        // Mocking: Benutzer nicht gefunden → Erwartete Ausnahme
        when(userRepository.findByUsername("nonExistentUser")).thenReturn(Optional.empty());

        // Überprüfung, ob eine RuntimeException geworfen wird
        assertThrows(RuntimeException.class, () -> projektController.getAllProjects());
    }

    // U.PC.29
    @Test
    public void testGetAllProjects_UserNotAuthenticated() {
        // Keine Authentifizierung gesetzt
        SecurityContextHolder.clearContext();

        // Überprüfung, ob eine RuntimeException geworfen wird
        assertThrows(RuntimeException.class, () -> projektController.getAllProjects());
    }

    // U.PC.30
    @Test
    public void testCreateProject_Success() {
        // Vorbereitung: Ein Benutzer mit Projektrechten
        MyAppUser user = new MyAppUser();
        user.setId(1L);
        user.setUsername("testuser");

        Projekt projekt = new Projekt();
        projekt.setName("Neues Projekt");
        projekt.setDescription("Testbeschreibung");

        Projekt savedProjekt = new Projekt();
        savedProjekt.setId(1L);
        savedProjekt.setName("Neues Projekt");
        savedProjekt.setDescription("Testbeschreibung");

        Sprint sprint = new Sprint();
        sprint.setName("Backlog");
        sprint.setSprintid(1L);
        sprint.setProjekt(savedProjekt);

        // Mock für die Authentifizierung
        Authentication authentication = mock(Authentication.class);
        SecurityContext securityContext = mock(SecurityContext.class);

        when(authentication.getName()).thenReturn("testuser");
        when(authentication.isAuthenticated()).thenReturn(true);
        when(securityContext.getAuthentication()).thenReturn(authentication);
        SecurityContextHolder.setContext(securityContext);

        when(userRepository.findByUsername("testuser")).thenReturn(Optional.of(user));
        when(projektRepository.save(any(Projekt.class))).thenReturn(savedProjekt);
        when(sprintRepository.save(any(Sprint.class))).thenReturn(sprint);

        // Aktion: Die `createProject()`-Methode aufrufen
        Projekt result = projektController.createProject(projekt);

        // Überprüfung
        assertNotNull(result, "Das zurückgegebene Projekt darf nicht null sein!");
        assertEquals(1L, result.getId(), "Die ID sollte 1 sein!");
        assertEquals("Neues Projekt", result.getName(), "Der Name sollte 'Neues Projekt' sein!");
        assertEquals("Testbeschreibung", result.getDescription(), "Die Beschreibung sollte übereinstimmen!");

        // Sicherstellen, dass die Repositories korrekt aufgerufen wurden
        verify(userRepository, times(1)).findByUsername("testuser");
        verify(projektRepository, times(1)).save(any(Projekt.class));
        verify(userRepository, times(1)).save(user);
        verify(sprintRepository, times(1)).save(any(Sprint.class));
    }

    // U.PC.31
    @Test
    public void testCreateProject_UserNotFound() {
        // Mocking der Authentifizierung
        Authentication authentication = mock(Authentication.class);
        SecurityContext securityContext = mock(SecurityContext.class);
        when(securityContext.getAuthentication()).thenReturn(authentication);
        SecurityContextHolder.setContext(securityContext);
        when(authentication.isAuthenticated()).thenReturn(true);
        when(authentication.getName()).thenReturn("nonExistentUser");

        Projekt projekt = new Projekt();
        projekt.setName("Test Projekt");

        // Mocking: Benutzer nicht gefunden
        when(userRepository.findByUsername("nonExistentUser")).thenReturn(Optional.empty());

        // Methode aufrufen
        Projekt result = projektController.createProject(projekt);

        // Überprüfung
        assertNull(result); // Sollte null sein, weil der Benutzer nicht existiert
    }

    // U.PC.32
    @Test
    public void testCreateProject_UserNotAuthenticated() {
        // Mocking der Authentifizierung
        SecurityContextHolder.clearContext(); // Kein authentifizierter Benutzer

        Projekt projekt = new Projekt();
        projekt.setName("Test Projekt");

        // Methode aufrufen
        Projekt result = projektController.createProject(projekt);

        // Überprüfung
        assertNull(result); // Sollte null sein, weil kein Benutzer angemeldet ist
    }

    // U.PC.33
    @Test
    public void testCreateProject_AuthenticationFailed() {
        // Mocking der Authentifizierung mit einem anonymen Benutzer (nicht eingeloggt)
        Authentication authentication = mock(AnonymousAuthenticationToken.class);
        SecurityContext securityContext = mock(SecurityContext.class);

        when(authentication.isAuthenticated()).thenReturn(false); // Nicht authentifiziert
        when(securityContext.getAuthentication()).thenReturn(authentication);
        SecurityContextHolder.setContext(securityContext);

        // Ein Projekt als Eingabe vorbereiten
        Projekt projekt = new Projekt();
        projekt.setName("Testprojekt ohne Authentifizierung");
        projekt.setDescription("Sollte nicht gespeichert werden");

        // Aktion: `createProject()` aufrufen
        Projekt result = projektController.createProject(projekt);

        // Überprüfung: Sollte `null` zurückgeben, weil Authentifizierung fehlt
        assertNull(result, "Projekt sollte nicht erstellt werden, da der Benutzer nicht authentifiziert ist!");

        // Sicherstellen, dass `save()` nicht aufgerufen wurde
        verify(projektRepository, times(0)).save(any(Projekt.class));
        verify(userRepository, times(0)).save(any(MyAppUser.class));
        verify(sprintRepository, times(0)).save(any(Sprint.class));
    }

    // U.PC.34
    @Test
    public void testGetProjectUsers_ProjectHasUsers() {
        String projectId = "1";

        MyAppUser user1 = new MyAppUser();
        user1.setId(1L);
        user1.setUsername("User1");
        user1.setEmail("user1@example.com");
        user1.setEnabled(true);
        user1.setVerificationToken("token1");
        user1.setResetToken("reset1");

        MyAppUser user2 = new MyAppUser();
        user2.setId(2L);
        user2.setUsername("User2");
        user2.setEmail("user2@example.com");
        user2.setEnabled(false);
        user2.setVerificationToken("token2");
        user2.setResetToken("reset2");

        List<MyAppUser> users = List.of(user1, user2);
        when(userRepository.findAllByProjektId(Long.parseLong(projectId))).thenReturn(users);

        List<MyAppUserDto> result = projektController.getProjectUsers(projectId);

        assertNotNull(result);
        assertEquals(2, result.size());

        MyAppUserDto dto1 = result.get(0);
        assertEquals("User1", dto1.getUsername());
        assertEquals("user1@example.com", dto1.getEmail());

        MyAppUserDto dto2 = result.get(1);
        assertEquals("User2", dto2.getUsername());
        assertEquals("user2@example.com", dto2.getEmail());

        verify(userRepository, times(1)).findAllByProjektId(Long.parseLong(projectId));
    }

    // U.PC.35
    @Test
    public void testGetProjectUsers_ProjectHasNoUsers() {
        String projectId = "1";
        when(userRepository.findAllByProjektId(Long.parseLong(projectId))).thenReturn(Collections.emptyList());

        List<MyAppUserDto> result = projektController.getProjectUsers(projectId);

        assertNotNull(result);
        assertTrue(result.isEmpty());

        verify(userRepository, times(1)).findAllByProjektId(Long.parseLong(projectId));
    }
}