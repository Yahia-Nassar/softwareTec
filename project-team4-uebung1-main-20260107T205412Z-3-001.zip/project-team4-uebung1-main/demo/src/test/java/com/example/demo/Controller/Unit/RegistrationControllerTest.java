package com.example.demo.Controller.Unit;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import com.example.demo.Controller.RegistrationController;
import com.example.demo.Model.User.MyAppUser;
import com.example.demo.Model.User.MyAppUserRepository;
import com.example.demo.util.event.OnRegistrationCompleteEvent;

import org.springframework.context.ApplicationEventPublisher;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;

@ExtendWith(MockitoExtension.class)
public class RegistrationControllerTest {

    @InjectMocks
    private RegistrationController registrationController; // Controller unter Test

    @Mock
    private MyAppUserRepository myAppUserRepository; // Gemocktes Repository

    @Mock
    private PasswordEncoder passwordEncoder; // Gemockter Passwort-Encoder

    @Mock
    private ApplicationEventPublisher eventPublisher; // Gemockter Event-Publisher

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this); // Initialisiere Mocks
    }

    // U.RC.1
    @Test
    public void testCreateUser_Success() {
        // Testbenutzer vorbereiten
        MyAppUser user = new MyAppUser();
        user.setEmail("test@example.com");
        user.setPassword("plainPassword");

        // Passwort-Verschlüsselung simulieren
        when(passwordEncoder.encode("plainPassword")).thenReturn("encodedPassword");

        // Repository soll bei findByEmail() "leer" zurückgeben
        when(myAppUserRepository.findByEmail("test@example.com")).thenReturn(Optional.empty());

        // Aufruf der Methode
        ResponseEntity<String> response = registrationController.createUser(user);

        // Response prüfen
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("redirect:/verify-email", response.getBody());

        // Verifizieren, dass der Benutzer gespeichert wurde (2x)
        verify(myAppUserRepository, times(2)).save(user);

        // Event muss veröffentlicht worden sein
        verify(eventPublisher).publishEvent(any(OnRegistrationCompleteEvent.class));

        // Zusätzliche Prüfungen
        assertEquals("encodedPassword", user.getPassword());
        assertNotNull(user.getVerificationToken());
    }

    // U.RC.2
    @Test
    public void testCreateUser_AlreadyExists() {
        MyAppUser existingUser = new MyAppUser();
        existingUser.setEmail("test@example.com");

        // Benutzer "existiert bereits"
        when(myAppUserRepository.findByEmail("test@example.com"))
            .thenReturn(Optional.of(existingUser));

        ResponseEntity<String> response = registrationController.createUser(existingUser);

        // Statuscode prüfen
        assertEquals(HttpStatus.CONFLICT, response.getStatusCode());
        assertEquals("Account with this e-mail already exists.", response.getBody());

        // Es darf nichts gespeichert oder veröffentlicht worden sein
        verify(myAppUserRepository, never()).save(any());
        verify(eventPublisher, never()).publishEvent(any());
    }
}