package com.example.demo.Controller.Unit;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import com.example.demo.Controller.ResetPasswordController;
import com.example.demo.Model.User.MyAppUser;
import com.example.demo.Model.User.MyAppUserRepository;
import com.example.demo.Model.User.MyAppUserService;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.ui.Model;
import org.springframework.security.crypto.password.PasswordEncoder;

@ExtendWith(MockitoExtension.class)
public class ResetPasswordControllerTest {

    @Mock
    private MyAppUserService myAppUserService;

    @Mock
    private PasswordEncoder passwordEncoder;

    @Mock
    private MyAppUserRepository myAppUserRepository;

    @Mock
    private Model model;

    @InjectMocks
    private ResetPasswordController resetPasswordController;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
    }

    // U.RPC.1
    @Test
    public void testShowResetPasswordForm_ValidToken() {
        String token = "validToken";
        MyAppUser user = new MyAppUser();
        when(myAppUserService.findByResetToken(token)).thenReturn(user);

        String result = resetPasswordController.showResetPasswordForm(token, model);

        assertEquals("resetPassword", result);
        verify(model).addAttribute("token", token);
    }

    // U.RPC.2
    @Test
    public void testShowResetPasswordForm_InvalidToken() {
        String token = "invalidToken";
        when(myAppUserService.findByResetToken(token)).thenReturn(null);

        String result = resetPasswordController.showResetPasswordForm(token, model);

        assertEquals("redirect:/req/signup", result);
    }

    // U.RPC.3
    @Test
    public void testCreateUser() {
        MyAppUser user = new MyAppUser();
        user.setPassword("rawPassword");
        user.setResetToken("validToken");

        MyAppUser dbUser = new MyAppUser();
        dbUser.setId(1L);
        dbUser.setEmail("test@example.com");
        dbUser.setVerificationToken("verificationToken");
        dbUser.setUsername("username");
        dbUser.setEnabled(true);

        when(myAppUserService.findByResetToken(user.getResetToken())).thenReturn(dbUser);
        when(passwordEncoder.encode("rawPassword")).thenReturn("encodedPassword");

        String result = resetPasswordController.createUser(user);

        assertEquals("redirect:/login", result);
        assertEquals("encodedPassword", user.getPassword());
        assertEquals(dbUser.getId(), user.getId());
        assertEquals(dbUser.getEmail(), user.getEmail());
        assertEquals(dbUser.getVerificationToken(), user.getVerificationToken());
        assertEquals(dbUser.getUsername(), user.getUsername());
        assertEquals(dbUser.getEnabled(), user.getEnabled());
        verify(myAppUserRepository).save(user);
    }
}

