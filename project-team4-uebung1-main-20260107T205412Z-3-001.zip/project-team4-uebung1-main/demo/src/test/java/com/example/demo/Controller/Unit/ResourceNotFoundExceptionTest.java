package com.example.demo.Controller.Unit;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import com.example.demo.Controller.ResourceNotFoundException;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
public class ResourceNotFoundExceptionTest {

    // U.RNFC.1
    @Test
    void testExceptionMessage() {

        String expectedMessage = "Resource not found";

        ResourceNotFoundException exception = new ResourceNotFoundException(expectedMessage);

        assertEquals(expectedMessage, exception.getMessage(), 
            "The exception message should match the expected message.");
    }
}
