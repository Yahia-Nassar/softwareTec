package com.example.demo.Controller.Unit;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.Optional;

import com.example.demo.Controller.RoleController;
import com.example.demo.Model.Projekt.Projekt;
import com.example.demo.Model.Projekt.ProjektRepository;
import com.example.demo.Model.Role.Role;
import com.example.demo.Model.Role.RoleEnum;
import com.example.demo.Model.Role.RoleRepository;
import com.example.demo.Model.User.MyAppUser;
import com.example.demo.Model.User.MyAppUserRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;

@ExtendWith(MockitoExtension.class)
class RoleControllerTest {

    @Mock
    private MyAppUserRepository userRepository;

    @Mock
    private ProjektRepository projektRepository;

    @Mock
    private RoleRepository roleRepository;

    @Mock
    private Authentication authentication;

    @Mock
    private SecurityContext securityContext;

    @InjectMocks
    private RoleController roleController;

    @BeforeEach
    void setUp() {
        SecurityContextHolder.setContext(securityContext);
        when(securityContext.getAuthentication()).thenReturn(authentication);
    }

    // U.ROC.1
    @Test
    public void testGetRole_UserAndProjectExist_ReturnRole() {
        String projectid = "1";
        String username = "testUser";

        when(authentication.getName()).thenReturn(username);

        MyAppUser user = new MyAppUser();
        user.setId(1L);
        user.setUsername(username);
        when(userRepository.findByUsername(username)).thenReturn(Optional.of(user));

        Projekt project = new Projekt();
        project.setId(1L);
        when(projektRepository.findById(1L)).thenReturn(Optional.of(project));

        Role role = new Role();
        role.setRole(RoleEnum.DEVELOPER);
        when(roleRepository.findByIdProjektIdAndIdUserId(project.getId(), user.getId())).thenReturn(role);

        RoleEnum result = roleController.getRole(projectid);

        assertEquals(RoleEnum.DEVELOPER, result);
    }

    // U.ROC.2
    @Test
    public void testGetRole_UserNotFound_ThrowsException() {
        when(authentication.getName()).thenReturn("unknownUser");
        when(userRepository.findByUsername("unknownUser")).thenReturn(Optional.empty());

        RuntimeException exception = assertThrows(RuntimeException.class, () -> roleController.getRole("1"));

        assertEquals("User not found", exception.getMessage());
    }

    // U.ROC.3
    @Test
    public void testGetRole_ProjectNotFound_ThrowsException() {
        String username = "testUser";
        when(authentication.getName()).thenReturn(username);

        MyAppUser user = new MyAppUser();
        user.setId(1L);
        when(userRepository.findByUsername(username)).thenReturn(Optional.of(user));

        when(projektRepository.findById(1L)).thenReturn(Optional.empty());

        RuntimeException exception = assertThrows(RuntimeException.class, () -> roleController.getRole("1"));

        assertEquals("Project not found", exception.getMessage());
    }

    // U.ROC.4
    @Test
    public void testGetRole_NoRoleFound_ReturnsNull() {
        String username = "testUser";
        when(authentication.getName()).thenReturn(username);

        MyAppUser user = new MyAppUser();
        user.setId(1L);
        when(userRepository.findByUsername(username)).thenReturn(Optional.of(user));

        Projekt project = new Projekt();
        project.setId(1L);
        when(projektRepository.findById(1L)).thenReturn(Optional.of(project));

        when(roleRepository.findByIdProjektIdAndIdUserId(project.getId(), user.getId())).thenReturn(null);

        RoleEnum result = roleController.getRole("1");

        assertNull(result);
    }
}
