package com.example.demo.Controller.Unit;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.List;
import java.util.Optional;

import com.example.demo.Controller.SprintController;
import com.example.demo.Model.Projekt.Projekt;
import com.example.demo.Model.Projekt.ProjektRepository;
import com.example.demo.Model.Sprints.Sprint;
import com.example.demo.Model.Sprints.SprintRepository;
import com.example.demo.Model.UserStories.UserStory;
import com.example.demo.Model.UserStories.UserStoryRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;

@ExtendWith(MockitoExtension.class)
class SprintControllerTest {

    @Mock
    private SprintRepository sprintRepository;

    @Mock
    private UserStoryRepository userStoryRepository;

    @Mock
    private ProjektRepository projektRepository;

    @InjectMocks
    private SprintController sprintController;

    @BeforeEach
    public void setUp() {
        // Falls eine besondere Vorabkonfiguration nötig ist, kannst du sie hier ergänzen.
    }

    // U.SC.1
    @Test
    public void testGetSprints_ShouldReturnSprintList() {
        Long projectId = 1L;
        Sprint sprint1 = new Sprint();
        sprint1.setSprintid(1L);
        Sprint sprint2 = new Sprint();
        sprint2.setSprintid(2L);

        when(sprintRepository.findByProjekt_Id(projectId)).thenReturn(List.of(sprint1, sprint2));

        List<Sprint> result = sprintController.getSprints(String.valueOf(projectId));

        assertEquals(2, result.size());
        verify(sprintRepository, times(1)).findByProjekt_Id(projectId);
    }

    // U.SC.2
    @Test
    public void testCreateSprint_ShouldSaveAndReturnSprint() {
        Sprint sprint = new Sprint();
        sprint.setSprintid(2L);
        sprint.setName("Sprint 2");
        Long projectId = 1L;

        Projekt project = new Projekt();
        project.setId(projectId);

        when(projektRepository.findById(projectId)).thenReturn(Optional.of(project));
        when(sprintRepository.findMaxSprintid()).thenReturn(1L);
        when(sprintRepository.save(sprint)).thenReturn(sprint);

        Sprint result = sprintController.createSprint(sprint, String.valueOf(projectId));

        assertNotNull(result);
        assertEquals(2L, result.getSprintid());
        verify(sprintRepository, times(1)).save(sprint);
    }

    // U.SC.3
    @Test
    public void testDeleteSprint_ShouldMoveUserStoriesAndDeleteSprint() {
        Long sprintId = 2L;

        Sprint backlog = new Sprint();
        backlog.setSprintid(1L);

        Sprint sprintToDelete = new Sprint();
        sprintToDelete.setSprintid(sprintId);

        UserStory userStory = new UserStory();
        userStory.setSprint(sprintToDelete);

        when(sprintRepository.findById(1L)).thenReturn(Optional.of(backlog));
        when(userStoryRepository.findBySprint_Sprintid(sprintId)).thenReturn(List.of(userStory));

        ResponseEntity<?> response = sprintController.deleteSprint(String.valueOf(sprintId));

        assertEquals(200, response.getStatusCode().value());
        verify(userStoryRepository, times(1)).saveAll(any());
        verify(sprintRepository, times(1)).deleteById(sprintId);
    }

    // U.SC.4
    @Test
    public void testEditSprint_ShouldUpdateSprintDetails() {
        Long sprintId = 2L;
        Sprint existingSprint = new Sprint();
        existingSprint.setSprintid(sprintId);
        existingSprint.setName("Old Sprint");

        Sprint updatedSprint = new Sprint();
        updatedSprint.setSprintid(sprintId);
        updatedSprint.setName("Updated Sprint");

        when(sprintRepository.findById(sprintId)).thenReturn(Optional.of(existingSprint));
        when(sprintRepository.save(existingSprint)).thenReturn(existingSprint);

        Sprint result = sprintController.editSprint("1", updatedSprint);

        assertNotNull(result);
        assertEquals("Updated Sprint", result.getName());
        verify(sprintRepository, times(1)).save(existingSprint);
    }
}
