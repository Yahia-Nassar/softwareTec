package com.example.demo.Controller.Unit.TaskController.CommentController;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import com.example.demo.Controller.CommentController.CommentController.CommentGetController;
import com.example.demo.Model.Tasks.Comment;
import com.example.demo.Model.Tasks.CommentRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Optional;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
public class CommentGetControllerTest {

    @Mock
    private CommentRepository commentRepository;

    @InjectMocks
    private CommentGetController commentGetController;

    @BeforeEach
    void setUp() {
        Comment comment1 = new Comment();
        comment1.setId(1L);
        comment1.setText("Test Comment 1");
        comment1.setVerfasser("User1");
        comment1.setTimestamp(LocalDateTime.now());

        Comment comment2 = new Comment();
        comment2.setId(2L);
        comment2.setText("Test Comment 2");
        comment2.setVerfasser("User2");
        comment2.setTimestamp(LocalDateTime.now());

        when(commentRepository.findById(1L)).thenReturn(Optional.of(comment1));
        when(commentRepository.findAll()).thenReturn(Arrays.asList(comment1, comment2));
    }
    
    // U.CGC.1

    @Test
    void testGetCommentById() {
        Optional<Comment> result = commentGetController.getComment(1L);

        assertTrue(result.isPresent());
        assertEquals("Test Comment 1", result.get().getText());
        assertEquals("User1", result.get().getVerfasser());
    }
    
    // U.CGC.2
    
    @Test
    void testGetAllComments() {
        Iterable<Comment> result = commentGetController.getAllComments();

        assertNotNull(result);
        assertEquals(2, ((java.util.List<Comment>) result).size());
        assertEquals("Test Comment 1", ((java.util.List<Comment>) result).get(0).getText());
        assertEquals("User1", ((java.util.List<Comment>) result).get(0).getVerfasser());
        assertEquals("Test Comment 2", ((java.util.List<Comment>) result).get(1).getText());
        assertEquals("User2", ((java.util.List<Comment>) result).get(1).getVerfasser());
    }
}
