package com.example.demo.Controller.Unit.TaskController.CommentController;

import static org.mockito.Mockito.when;
import static org.mockito.Mockito.verify;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import com.example.demo.Controller.CommentController.CommentController.CommentSaveController;
import com.example.demo.Model.Tasks.Comment;
import com.example.demo.Model.Tasks.CommentRepository;

@ExtendWith(MockitoExtension.class)
public class CommentSaveControllerTest {

    @Mock
    private CommentRepository commentRepository;

    @InjectMocks
    private CommentSaveController commentSaveController;

    @SuppressWarnings("deprecation")
    @BeforeEach
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }
    
    // U.CSC.1

    @Test
    public void testCreateComment() {
        Comment comment = new Comment();
        comment.setText("Test Comment");

        when(commentRepository.save(comment)).thenReturn(comment);

        Comment createdComment = commentSaveController.createComment(comment);

        assertEquals("Test Comment", createdComment.getText());
        verify(commentRepository).save(comment);
    }
}
