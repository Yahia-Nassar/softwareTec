package com.example.demo.Controller.Unit;

import com.example.demo.Controller.TeamController;
import com.example.demo.Model.Projekt.Projekt;
import com.example.demo.Model.Projekt.ProjektRepository;
import com.example.demo.Model.User.MyAppUser;
import com.example.demo.Model.User.MyAppUserDto;
import com.example.demo.Model.User.MyAppUserRepository;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class TeamControllerTest {

    @Mock
    private MyAppUserRepository userRepository;

    @Mock
    private ProjektRepository projectRepository;

    @InjectMocks
    private TeamController teamController;

    // U.TC.1
    @Test
    public void testGetUsersInProject_shouldReturnUserList() {
        Long projectId = 1L;
        Projekt projekt = new Projekt();
        MyAppUser user1 = new MyAppUser();
        MyAppUser user2 = new MyAppUser();
        List<MyAppUser> users = List.of(user1, user2);

        when(projectRepository.findById(projectId)).thenReturn(Optional.of(projekt));
        when(userRepository.findByProjectsContaining(projekt)).thenReturn(users);

        List<MyAppUserDto> result = teamController.getUsersInProject(projectId);

        assertEquals(2, result.size());
        verify(userRepository).findByProjectsContaining(projekt);
    }

    // U.TC.2
    @Test
    public void testGetUsersInProject_shouldThrowWhenProjectNotFound() {
        Long invalidProjectId = 99L;
        when(projectRepository.findById(invalidProjectId)).thenReturn(Optional.empty());

        RuntimeException exception = assertThrows(RuntimeException.class,
            () -> teamController.getUsersInProject(invalidProjectId)
        );

        assertEquals("Project not found", exception.getMessage());
    }

    // U.TC.3
    @Test
    public void testAddUserToProject_shouldAddAndReturnSuccessMessage() {
        Long projectId = 1L;
        String username = "testuser";
        MyAppUser user = new MyAppUser();
        user.setProjekt(new ArrayList<>());
        Projekt projekt = new Projekt();

        when(userRepository.findByUsername(username)).thenReturn(Optional.of(user));
        when(projectRepository.findById(projectId)).thenReturn(Optional.of(projekt));

        Map<String, String> result = teamController.addUserToProject(projectId, Map.of("username", username));

        assertEquals("User added successfully", result.get("message"));
        verify(userRepository).save(user);
    }

    // U.TC.4
    @Test
    public void testAddUserToProject_shouldReturnAlreadyExistsMessage() {
        Long projectId = 1L;
        String username = "testuser";
        Projekt projekt = new Projekt();
        MyAppUser user = new MyAppUser();
        user.setProjekt(new ArrayList<>(List.of(projekt)));

        when(userRepository.findByUsername(username)).thenReturn(Optional.of(user));
        when(projectRepository.findById(projectId)).thenReturn(Optional.of(projekt));

        Map<String, String> result = teamController.addUserToProject(projectId, Map.of("username", username));

        assertEquals("User is already in this project", result.get("message"));
        verify(userRepository, never()).save(any());
    }

    // U.TC.5
    @Test
    public void testAddUserToProject_shouldReturnErrorIfUsernameEmpty() {
        Long projectId = 1L;
        Map<String, String> requestBody = Map.of("username", "");

        Map<String, String> response = teamController.addUserToProject(projectId, requestBody);

        assertEquals("Username cannot be empty", response.get("message"));
    }

    // U.TC.6
    @Test
    public void testAddUserToProject_shouldThrowIfUserNotFound() {
        Long projectId = 1L;
        String username = "nonexistent";
        Map<String, String> requestBody = Map.of("username", username);

        when(userRepository.findByUsername(username)).thenReturn(Optional.empty());

        RuntimeException exception = assertThrows(RuntimeException.class,
            () -> teamController.addUserToProject(projectId, requestBody)
        );

        assertEquals("No user found with username: nonexistent", exception.getMessage());
    }

    // U.TC.7
    @Test
    public void testAddUserToProject_shouldThrowIfProjectNotFound() {
        Long projectId = 1L;
        String username = "validuser";
        MyAppUser user = new MyAppUser();

        when(userRepository.findByUsername(username)).thenReturn(Optional.of(user));
        when(projectRepository.findById(projectId)).thenReturn(Optional.empty());

        Map<String, String> requestBody = Map.of("username", username);

        RuntimeException exception = assertThrows(RuntimeException.class,
            () -> teamController.addUserToProject(projectId, requestBody)
        );

        assertEquals("Project not found", exception.getMessage());
    }

    // U.TC.8
    @Test
    public void testGetUsersInProject_shouldReturnEmptyListIfNoUsers() {
        Long projectId = 1L;
        Projekt projekt = new Projekt();

        when(projectRepository.findById(projectId)).thenReturn(Optional.of(projekt));
        when(userRepository.findByProjectsContaining(projekt)).thenReturn(Collections.emptyList());

        List<MyAppUserDto> result = teamController.getUsersInProject(projectId);

        assertEquals(0, result.size());
    }

    // U.TC.9
    @Test
    public void testUserDtoMapping_shouldMapCorrectly() {
        Long projectId = 1L;
        Projekt projekt = new Projekt();

        MyAppUser user = new MyAppUser();
        user.setId(42L);
        user.setUsername("bob");
        user.setEmail("bob@example.com");
        user.setEnabled(true);
        user.setVerificationToken("verif123");
        user.setResetToken("reset456");

        when(projectRepository.findById(projectId)).thenReturn(Optional.of(projekt));
        when(userRepository.findByProjectsContaining(projekt)).thenReturn(List.of(user));

        List<MyAppUserDto> dtos = teamController.getUsersInProject(projectId);

        assertEquals(1, dtos.size());
        MyAppUserDto dto = dtos.get(0);
        assertEquals("bob", dto.getUsername());
        assertEquals("bob@example.com", dto.getEmail());
        assertEquals("verif123", dto.getVerificationToken());
        assertEquals("reset456", dto.getResetToken());
    }
}