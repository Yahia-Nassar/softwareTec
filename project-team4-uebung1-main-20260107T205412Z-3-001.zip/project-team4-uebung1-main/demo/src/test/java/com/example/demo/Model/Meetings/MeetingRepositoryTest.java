package com.example.demo.Model.Meetings;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

@DataJpaTest
class MeetingRepositoryTest {

    @Autowired
    private MeetingRepository meetingRepository;

    // M.MR.1
    @Test
    void testSaveAndFindByDescription() {
        // Meeting-Objekt erstellen
        Meeting meeting = new Meeting();
        meeting.setDescription("Projekt Kickoff");
        meeting.setDate(LocalDate.of(2025, 5, 26));
        meeting.setTime(LocalTime.of(14, 30));
        
        // Meeting speichern
        meetingRepository.save(meeting);

        // Meeting aus der Datenbank suchen
        Optional<Meeting> foundMeeting = meetingRepository.findByDescription("Projekt Kickoff");

        // Überprüfen, ob das Meeting korrekt gespeichert und gefunden wurde
        assertTrue(foundMeeting.isPresent());
        assertEquals("Projekt Kickoff", foundMeeting.get().getDescription());
    }
    
    // M.MR.2
    @Test
    void testSaveAndFindById() {
        Meeting meeting = new Meeting();
        meeting.setDescription("Team-Meeting");
        meeting.setDate(LocalDate.of(2025, 6, 1));
        meeting.setTime(LocalTime.of(10, 00));

        // Meeting speichern
        Meeting savedMeeting = meetingRepository.save(meeting);

        // Meeting aus der Datenbank suchen
        Optional<Meeting> foundMeeting = meetingRepository.findById(savedMeeting.getMeetingId());

        // Überprüfen, ob das Meeting korrekt gefunden wurde
        assertTrue(foundMeeting.isPresent());
        assertEquals("Team-Meeting", foundMeeting.get().getDescription());
    }
}