package com.example.demo.Model.Meetings;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

import org.junit.jupiter.api.Test;

import com.example.demo.Model.Projekt.Projekt;
import com.example.demo.Model.User.MyAppUser;

class MeetingTest {

    // M.M.1
    @Test
    void testMeetingCreation() {
        Meeting meeting = new Meeting();
        meeting.setMeetingId(1L);
        meeting.setDescription("Projekt Kickoff");
        meeting.setDate(LocalDate.of(2025, 5, 26));
        meeting.setTime(LocalTime.of(14, 30));

        assertEquals(1L, meeting.getMeetingId());
        assertEquals("Projekt Kickoff", meeting.getDescription());
        assertEquals(LocalDate.of(2025, 5, 26), meeting.getDate());
        assertEquals(LocalTime.of(14, 30), meeting.getTime());
    }

    // M.M.2
    @Test
    void testUserAssignment() {
        Meeting meeting = new Meeting();
        MyAppUser user = new MyAppUser();
        meeting.setUsers(List.of(user));

        assertNotNull(meeting.getUsers());
        assertEquals(1, meeting.getUsers().size());
    }

    // M.M.3
    @Test
    void testProjectAssignment() {
        Meeting meeting = new Meeting();
        Projekt project = new Projekt();
        meeting.setProject(project);

        assertNotNull(meeting.getProject());
        assertEquals(project, meeting.getProject());
    }
}