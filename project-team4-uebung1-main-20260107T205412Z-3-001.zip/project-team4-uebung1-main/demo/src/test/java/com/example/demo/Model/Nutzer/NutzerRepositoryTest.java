/*package com.example.demo.Model.Nutzer;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Optional;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.context.SpringBootTest;

@DataJpaTest
public class NutzerRepositoryTest {

    @Autowired
    private NutzerRepository nutzerRepository;

    // M.NR.1
    @Test
    void testSave() {
        Nutzer nutzer = new Nutzer();
        nutzer.setVorname("Max");
        nutzer.setNachname("Mustermann");

        Nutzer savedNutzer = nutzerRepository.save(nutzer);
        assertEquals("Max", savedNutzer.getVorname());
        assertEquals("Mustermann", savedNutzer.getNachname());
    }

    // M.NR.2
    @Test
    void testFindAll() {

        nutzerRepository.deleteAll();
        
        Nutzer nutzer1 = new Nutzer();
        nutzer1.setVorname("Max");
        nutzer1.setNachname("Mustermann");

        Nutzer nutzer2 = new Nutzer();
        nutzer2.setVorname("John");
        nutzer2.setNachname("Doe");

        nutzerRepository.save(nutzer1);
        nutzerRepository.save(nutzer2);

        List<Nutzer> nutzerList = nutzerRepository.findAll();
        assertEquals(2, nutzerList.size());
    }

    // M.NR.3
    @Test
    void testFindById() {
        Nutzer nutzer = new Nutzer();
        nutzer.setVorname("Max");
        nutzer.setNachname("Mustermann");

        Nutzer savedNutzer = nutzerRepository.save(nutzer);
        Optional<Nutzer> foundNutzer = nutzerRepository.findById(savedNutzer.getNutzer_id());

        assertTrue(foundNutzer.isPresent());
        assertEquals("Max", foundNutzer.get().getVorname());
        assertEquals("Mustermann", foundNutzer.get().getNachname());
    }

    // M.NR.4
    @Test
    void testDeleteById() {
        Nutzer nutzer = new Nutzer();
        nutzer.setVorname("Max");
        nutzer.setNachname("Mustermann");

        Nutzer savedNutzer = nutzerRepository.save(nutzer);
        nutzerRepository.deleteById(savedNutzer.getNutzer_id());

        Optional<Nutzer> foundNutzer = nutzerRepository.findById(savedNutzer.getNutzer_id());
        assertTrue(foundNutzer.isEmpty());
    }
} */
