package com.example.demo.Model.Nutzer;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class NutzerServiceTest {

    @InjectMocks
    private NutzerService nutzerService;

    @Mock
    private NutzerRepository nutzerRepository;

    private Nutzer nutzer;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        nutzer = new Nutzer();
        nutzer.setNutzer_id(1L);
        nutzer.setVorname("Max");
        nutzer.setNachname("Mustermann");
    }

    // M.NS.1
    @Test
    void testSaveNutzer() {
        when(nutzerRepository.save(nutzer)).thenReturn(nutzer);
        Nutzer savedNutzer = nutzerService.saveNutzer(nutzer);
        assertNotNull(savedNutzer);
        assertEquals(nutzer.getNutzer_id(), savedNutzer.getNutzer_id());
    }

    // M.NS.1
    @Test
    void testGetAllNutzer() {
        List<Nutzer> nutzerList = Arrays.asList(nutzer);
        when(nutzerRepository.findAll()).thenReturn(nutzerList);
        List<Nutzer> result = nutzerService.getAllNutzer();
        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals(nutzer.getNutzer_id(), result.get(0).getNutzer_id());
    }

    // M.NS.1
    @Test
    void testGetNutzerById() {
        when(nutzerRepository.findById(1L)).thenReturn(Optional.of(nutzer));
        Optional<Nutzer> result = nutzerService.getNutzerById(1L);
        assertNotNull(result);
        assertEquals(true, result.isPresent());
        assertEquals(nutzer.getNutzer_id(), result.get().getNutzer_id());
    }

    // M.NS.1
    @Test
    void testDeleteNutzer() {
        nutzerService.deleteNutzer(1L);
        // Verify that the method was called
        when(nutzerRepository.findById(1L)).thenReturn(Optional.empty());
        Optional<Nutzer> result = nutzerService.getNutzerById(1L);
        assertEquals(false, result.isPresent());
    }
}
