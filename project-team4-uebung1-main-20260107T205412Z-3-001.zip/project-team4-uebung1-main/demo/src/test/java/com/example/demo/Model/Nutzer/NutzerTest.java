package com.example.demo.Model.Nutzer;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class NutzerTest {

    private Nutzer nutzer;

    @BeforeEach
    void setUp() {
        nutzer = new Nutzer();
        nutzer.setNutzer_id(1L);
        nutzer.setVorname("Max");
        nutzer.setNachname("Mustermann");
    }

    // M.N.1
    @Test
    void testNutzer() {
        // Test Nutzer_id
        assertNotNull(nutzer.getNutzer_id());
        assertEquals(1L, nutzer.getNutzer_id());
        nutzer.setNutzer_id(2L);
        assertEquals(2L, nutzer.getNutzer_id());
        
        // Test Vorname
        assertNotNull(nutzer.getVorname());
        assertEquals("Max", nutzer.getVorname());
        nutzer.setVorname("John");
        assertEquals("John", nutzer.getVorname());
        
        // Test Nachname
        assertNotNull(nutzer.getNachname());
        assertEquals("Mustermann", nutzer.getNachname());
        nutzer.setNachname("Doe");
        assertEquals("Doe", nutzer.getNachname());
    }
}
