package com.example.demo.Model.Projekt;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.util.List;
//import java.util.ArrayList;

import com.example.demo.Model.Tasks.Task;
import com.example.demo.Model.User.MyAppUser;
import com.example.demo.Model.UserStories.UserStory;

class ProjektDtoTest {

    // M.PD.1
    @Test
    void testFromEntity() {
        Projekt projekt = new Projekt();
        projekt.setId(1L);
        projekt.setName("Testprojekt");
        projekt.setDescription("Dies ist ein Testprojekt");

        MyAppUser user1 = new MyAppUser();
        user1.setId(10L);
        MyAppUser user2 = new MyAppUser();
        user2.setId(20L);

        Task task1 = new Task();
        task1.setid(100L);
        Task task2 = new Task();
        task2.setid(200L);

        UserStory story1 = new UserStory();
        story1.setId(1000L);
        UserStory story2 = new UserStory();
        story2.setId(2000L);

        projekt.setUsers(List.of(user1, user2));
        //projekt. setTasks(List.of(task1, task2));
        projekt.setUserStories(List.of(story1, story2));

        ProjektDto dto = ProjektDto.fromEntity(projekt);

        assertEquals(1L, dto.getId());
        assertEquals("Testprojekt", dto.getName());
        assertEquals("Dies ist ein Testprojekt", dto.getDescription());
        assertEquals(List.of(10L, 20L), dto.getUserIds());
        //assertEquals(List.of(100L, 200L), dto.getTaskIds());
        assertEquals(List.of(1000L, 2000L), dto.getUserStoryIds());
    }
}