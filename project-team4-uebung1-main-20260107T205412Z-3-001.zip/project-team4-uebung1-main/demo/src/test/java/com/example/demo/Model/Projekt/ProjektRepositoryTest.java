package com.example.demo.Model.Projekt;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

@DataJpaTest
class ProjektRepositoryTest {

    @Autowired
    private ProjektRepository projektRepository;

    // M.PR.1
    @Test
    public void testSaveProjekt() {
        // Arrange
        Projekt projekt = new Projekt();
        projekt.setName("Test Project");
        projekt.setDescription("This is a test project.");

        // Act
        Projekt savedProjekt = projektRepository.save(projekt);

        // Assert
        assertNotNull(savedProjekt.getId());
        assertEquals("Test Project", savedProjekt.getName());
        assertEquals("This is a test project.", savedProjekt.getDescription());
    }

    // M.PR.2
    @Test
    public void testFindProjektById() {
        // Arrange
        Projekt projekt = new Projekt();
        projekt.setName("Find Me");
        projekt.setDescription("Find Me Project Description");
        Projekt savedProjekt = projektRepository.save(projekt);

        // Act
        Optional<Projekt> foundProjekt = projektRepository.findById(savedProjekt.getId());

        // Assert
        assertTrue(foundProjekt.isPresent());
        assertEquals("Find Me", foundProjekt.get().getName());
    }

    // M.PR.3
    @Test
    public void testDeleteProjekt() {
        // Arrange
        Projekt projekt = new Projekt();
        projekt.setName("Delete Me");
        Projekt savedProjekt = projektRepository.save(projekt);

        // Act
        projektRepository.deleteById(savedProjekt.getId());
        Optional<Projekt> deletedProjekt = projektRepository.findById(savedProjekt.getId());

        // Assert
        assertFalse(deletedProjekt.isPresent());
    }
}