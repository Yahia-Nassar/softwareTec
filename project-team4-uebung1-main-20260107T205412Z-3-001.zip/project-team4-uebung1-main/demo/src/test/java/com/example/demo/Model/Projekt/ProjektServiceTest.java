package com.example.demo.Model.Projekt;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class ProjektServiceTest {

    @Mock
    private ProjektRepository projektRepository;

    @Mock
    private ProjektService projektService;

    @BeforeEach
    public void setup() {
        projektRepository = mock(ProjektRepository.class);
        projektService = new ProjektService(projektRepository);
    }

    // M.PS.1
    @Test
    public void testSaveProjekt() {

        Projekt projekt = new Projekt();
        projekt.setName("Test Project");

        projektService.saveProjekt(projekt);

        verify(projektRepository, times(1)).save(projekt);
    }

    // M.PS.2
    @Test
    public void testDeleteProjekt() {

        Long id = 1L;

        projektService.deleteProjekt(id);

        verify(projektRepository, times(1)).deleteById(id);
    }

    // M.PS.3
    @Test
    public void testGetProjektById_Found() {

        Long id = 1L;
        Projekt projekt = new Projekt();
        projekt.setId(id);
        projekt.setName("Test Project");
        when(projektRepository.findById(id)).thenReturn(Optional.of(projekt));

        Projekt result = projektService.getProjektById(id);

        assertNotNull(result, "The project should not be null when found.");
        assertEquals(id, result.getId(), "The project ID should match.");
        assertEquals("Test Project", result.getName(), "The project name should match.");
    }

    // M.PS.4
    @Test
    public void testGetProjektById_NotFound() {

        Long id = 1L;
        when(projektRepository.findById(id)).thenReturn(Optional.empty());

        Projekt result = projektService.getProjektById(id);

        assertNull(result, "The project should be null when not found.");
    }
}