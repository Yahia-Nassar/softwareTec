package com.example.demo.Model.Projekt;

import com.example.demo.Model.Tasks.Task;
import com.example.demo.Model.User.MyAppUser;
import com.example.demo.Model.UserStories.UserStory;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class ProjektTest {
    

    // M.P.1
    @Test
    public void testGettersAndSetters() {

        Projekt projekt = new Projekt();
        Long id = 1L;
        String name = "Test";
        String description = "Test";
        List<MyAppUser> users = new ArrayList<>();
        List<Task> tasks = new ArrayList<>();
        List<UserStory> userStories = new ArrayList<>();

        MyAppUser user = new MyAppUser();
        Task task = new Task();
        UserStory userStory = new UserStory();

        users.add(user);
        tasks.add(task);
        userStories.add(userStory);

        projekt.setId(id);
        projekt.setName(name);
        projekt.setDescription(description);
        projekt.setUsers(users);
        projekt.setTasks(tasks);
        projekt.setUserStories(userStories);

        assertEquals(id, projekt.getId());
        assertEquals(name, projekt.getName());
        assertEquals(description, projekt.getDescription());
        assertEquals(users, projekt.getUsers());
        assertEquals(tasks, projekt.getTasks());
        assertEquals(userStories, projekt.getUserStories());
    }
}
