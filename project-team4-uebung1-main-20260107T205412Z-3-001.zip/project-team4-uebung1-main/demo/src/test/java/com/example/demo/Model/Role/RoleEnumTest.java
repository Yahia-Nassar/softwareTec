package com.example.demo.Model.Role;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class RoleEnumTest {

    // M.RE.1
    @Test
    public void testEnumValues() {
        assertEquals(RoleEnum.PRODUCT_OWNER, RoleEnum.valueOf("PRODUCT_OWNER"));
        assertEquals(RoleEnum.DEVELOPER, RoleEnum.valueOf("DEVELOPER"));
    }
}
