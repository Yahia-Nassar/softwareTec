package com.example.demo.Model.Role;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class RoleIdTest {

    // M.RI.1
    @Test
    void testSettersAndGetters() {
        RoleId roleId = new RoleId(1L, 2L);

        assertEquals(1L, roleId.getUserId());
        assertEquals(2L, roleId.getProjektId());

        roleId.setUserId(10L);
        roleId.setProjektId(20L);

        assertEquals(10L, roleId.getUserId());
        assertEquals(20L, roleId.getProjektId());
    }
}