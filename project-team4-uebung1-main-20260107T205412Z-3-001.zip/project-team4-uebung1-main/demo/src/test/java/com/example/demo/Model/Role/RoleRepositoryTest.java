package com.example.demo.Model.Role;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

@DataJpaTest
public class RoleRepositoryTest {

    @Autowired
    private RoleRepository roleRepository;

    // M.RR.1
    @Test
    public void testFindByIdProjektIdAndIdUserId() {
        // Erstelle eine RoleId mit gesetzten Werten
        RoleId roleId = new RoleId();
        roleId.setUserId(1L);
        roleId.setProjektId(2L);

        // Erstelle eine Role-Entität und setze die ID
        Role role = new Role();
        role.setId(roleId); // 👉 Diese Zeile ist entscheidend!
        role.setRole(RoleEnum.DEVELOPER);

        // Speichere die Entität
        roleRepository.save(role);

        // Finde die gespeicherte Entität über die benutzerdefinierte Methode
        Role foundRole = roleRepository.findByIdProjektIdAndIdUserId(2L, 1L);

        // Überprüfe das Ergebnis
        assertNotNull(foundRole);
        assertEquals(RoleEnum.DEVELOPER, foundRole.getRole());
    }
}