package com.example.demo.Model.Role;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class RoleTest {

    // M.R.1
    @Test
    void testSettersAndGetters() {
        Role role = new Role();

        role.setRole(RoleEnum.PRODUCT_OWNER);

        assertEquals(RoleEnum.PRODUCT_OWNER, role.getRole());
    }
}