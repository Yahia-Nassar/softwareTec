package com.example.demo.Model.Sprints;

import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

@DataJpaTest
class SprintRepositoryTest {

    @Autowired
    private SprintRepository sprintRepository;

    // M.SR.1
    @Test
    public void testFindByName() {
        // Set up test data
        Sprint sprint = new Sprint();
        sprint.setSprintid(123L);
        sprint.setName("Sprint 1");
        sprint.setStartDate("2025-03-01");
        sprint.setEndDate("2025-03-15");

        // Speichern des Test-Datensatzes in der eingebetteten Test-Datenbank
        sprintRepository.save(sprint);

        // Test der Repository-Methode
        Optional<Sprint> found = sprintRepository.findByName("Sprint 1");
        assertTrue(found.isPresent());
        assertTrue(found.get().getName().equals("Sprint 1"));
    }
}