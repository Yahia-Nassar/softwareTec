package com.example.demo.Model.Sprints;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class SprintTest {
    
    // M.S.1

    @Test
    public void testSprintGettersAndSetters() {
        // Create a new Sprint object
        Sprint sprint = new Sprint();

        // Set the properties
        sprint.setSprintid(123L);
        sprint.setName("Sprint 1");
        sprint.setStartDate("2025-03-01");
        sprint.setEndDate("2025-03-15");

        // Test the getters
        assertEquals(123L, sprint.getSprintid());
        assertEquals("Sprint 1", sprint.getName());
        assertEquals("2025-03-01", sprint.getStartDate());
        assertEquals("2025-03-15", sprint.getEndDate());
    }
}
