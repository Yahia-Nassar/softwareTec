/*package com.example.demo.Model.Tasks;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

@DataJpaTest
class CommentRepositoryTest {

    @Autowired
    private CommentRepository commentRepository;

    @BeforeEach
    void setUp() {
        Comment comment1 = new Comment();
        comment1.setVerfasser("Alice");
        comment1.setText("Das ist ein Testkommentar");

        Comment comment2 = new Comment();
        comment2.setVerfasser("Bob");
        comment2.setText("Ein weiterer Kommentar mit Inhalt");

        commentRepository.save(comment1);
        commentRepository.save(comment2);
    }

    @Test
    void testFindByVerfasser() {
        List<Comment> result = commentRepository.findByVerfasser("Alice");
        assertEquals(1, result.size());
        assertEquals("Das ist ein Testkommentar", result.get(0).getText());
    }

    @Test
    void testFindByTextContaining() {
        List<Comment> result = commentRepository.findByTextContaining("Kommentar");
        assertEquals(2, result.size());
    }

}*/