package com.example.demo.Model.Tasks;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

class CommentTest {

    // M.C.1

    @Test
    public void testCommentGettersAndSetters() {
        Long id = 1L;
        String text = "test";
        String verfasser = "Test";
        LocalDateTime timestamp = LocalDateTime.now();
        List<Comment> replies = new ArrayList<>();
        Comment reply = new Comment();
        reply.setText("reply");
        replies.add(reply);

        Comment comment = new Comment();
        comment.setId(id);
        comment.setText(text);
        comment.setVerfasser(verfasser);
        comment.setTimestamp(timestamp);
        comment.setReplies(replies);

        assertAll("comment",
            () -> assertEquals(id, comment.getId()),
            () -> assertEquals(text, comment.getText()),
            () -> assertEquals(verfasser, comment.getVerfasser()),
            () -> assertEquals(timestamp, comment.getTimestamp()),
            () -> assertEquals(replies, comment.getReplies())
        );
    }
}
