package com.example.demo.Model.Tasks;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDate;
import org.junit.jupiter.api.Test;

public class TaskDtoTest {

    // M.TD.1
    @Test
    public void testSettersAndGetters() {
        TaskDto task = new TaskDto();
        task.setId(1L);
        task.setTitle("Test Task");
        task.setDescription("Dies ist eine Testbeschreibung.");
        task.setStatus(statustask.IN_PROGRESS);
        task.setPriority(priorityEnum.HIGH);
        task.setActTime(10);
        task.setEstTime(10);

        LocalDate now = LocalDate.now();
        task.setCompletedAt(now);
        task.setInProgressAt(now);

        assertEquals(1L, task.getId());
        assertEquals("Test Task", task.getTitle());
        assertEquals("Dies ist eine Testbeschreibung.", task.getDescription());
        assertEquals(statustask.IN_PROGRESS, task.getStatus());
        assertEquals(priorityEnum.HIGH, task.getPriority());
        assertEquals(10, task.getActTime());
        assertEquals(10, task.getEstTime());
        assertEquals(now, task.getCompletedAt());
        assertEquals(now, task.getInProgressAt());
    }
}
