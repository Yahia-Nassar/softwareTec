package com.example.demo.Model.Tasks;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

@DataJpaTest
class TaskRepositoryTest {

    @Autowired
    private TaskRepository taskRepository;

    @BeforeEach
    void setUp() {
        assertNotNull(taskRepository, "taskRepository should not be null");

        // Löschen der Tasks mit dem selben Namen
        String title = "Test Task";
        taskRepository.findByTitle(title).ifPresent(taskRepository::delete);
    }

    // M.TR.1
    @Test
    void testFindByTitle() {
        String title = "Test Task";
        Task task = new Task();
        task.setTitle(title);
        
        taskRepository.save(task);

        Optional<Task> result = taskRepository.findByTitle(title);
    
        assertTrue(result.isPresent());
        assertEquals(title, result.get().getTitle());
    
        taskRepository.delete(task);
    }    
}