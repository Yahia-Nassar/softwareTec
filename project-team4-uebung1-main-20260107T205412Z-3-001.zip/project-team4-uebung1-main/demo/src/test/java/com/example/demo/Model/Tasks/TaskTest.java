package com.example.demo.Model.Tasks;

import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.example.demo.Model.User.MyAppUser;
import com.example.demo.Model.UserStories.UserStory;


import static org.junit.jupiter.api.Assertions.*;

class TaskTest {

    // M.T.1

    @Test
    public void testTaskGettersAndSetters() {

        Task task = new Task();

        task.setTitle("Test Title");
        task.setStatus(statustask.IN_PROGRESS);
        task.setPriority(priorityEnum.HIGH);
        task.setActTime(10);
        task.setEstTime(10);

        LocalDate now = LocalDate.now();
        task.setCompletedAt(now);
        task.setInProgressAt(now);

        List<Comment> comments = new ArrayList<>();
        task.updateComments(comments);

        List<MyAppUser> users = new ArrayList<>();
        task.setUsers(users);

        UserStory userStory = new UserStory();
        task.setUserStory(userStory);

        assertEquals("Test Title", task.getTitle());
        assertEquals(statustask.IN_PROGRESS, task.getStatus());
        assertEquals(priorityEnum.HIGH, task.getPriority());
        assertEquals(10, task.getActTime());
        assertEquals(10, task.getEstTime());
        assertEquals(now, task.getCompletedAt());
        assertEquals(now, task.getInProgressAt());
        assertEquals(comments, task.getComments());
        assertEquals(users, task.getUsers());
        assertEquals(userStory, task.getUserStory());
    }
}