package com.example.demo.Model.Tasks;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

class priorityEnumTest {

    // M.PE.1
    @Test
    public void testEnumValues() {
        // Prüfe, ob die Enum-Werte korrekt definiert sind
        priorityEnum low = priorityEnum.LOW;
        priorityEnum medium = priorityEnum.MEDIUM;
        priorityEnum high = priorityEnum.HIGH;

        assertEquals("LOW", low.name());
        assertEquals("MEDIUM", medium.name());
        assertEquals("HIGH", high.name());

        assertNotNull(low);
        assertNotNull(medium);
        assertNotNull(high);
    }

    // M.PE.2
    @Test
    public void testEnumOrdinals() {
        // Ordinals prüfen (Reihenfolge der Enum-Werte)
        assertEquals(0, priorityEnum.LOW.ordinal());
        assertEquals(1, priorityEnum.MEDIUM.ordinal());
        assertEquals(2, priorityEnum.HIGH.ordinal());
    }
}

