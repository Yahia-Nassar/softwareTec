package com.example.demo.Model.Tasks;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

class statustaskTest {

    // M.ST.1

    @Test
    public void testStatustaskValues() {
        // Ensure all enum values are present
        assertNotNull(statustask.valueOf("NOT_STARTED"));
        assertNotNull(statustask.valueOf("IN_PROGRESS"));
        assertNotNull(statustask.valueOf("IN_TESTING"));
        assertNotNull(statustask.valueOf("COMPLETED"));
        assertNotNull(statustask.valueOf("BLOCKED"));
        assertNotNull(statustask.valueOf("BURNBARREL"));
    }

    // M.ST.2

    @Test
    public void testStatustaskCount() {
        // Ensure the number of enum values is as expected
        assertEquals(6, statustask.values().length);
    }
}
