package com.example.demo.Model.Team;

import com.example.demo.Model.Ist_mitglied.ist_mitgliedRepository;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
public class TeamRepositoryTest {

    @Autowired
    private TeamRepository teamRepository;

    @Autowired
    private ist_mitgliedRepository istMitgliedRepository;

    @BeforeEach
    public void setup() {
        // Reihenfolge ist wichtig: erst ist_mitglied, dann Team
        istMitgliedRepository.deleteAll();
        teamRepository.deleteAll();
    }

    // M.TER.1
    @Test
    public void testSave() {
        Team newTeam = new Team();
        newTeam.setName("Prev_Team C");
        Team savedTeam = teamRepository.saveAndFlush(newTeam);

        assertNotNull(savedTeam.getTeam_id());
        assertEquals("Prev_Team C", savedTeam.getName());
    }

    // M.TER.2
    @Test
    public void testFindAll() {
        Team team1 = new Team();
        team1.setName("Prev_Team A");

        Team team2 = new Team();
        team2.setName("Prev_Team B");

        teamRepository.saveAndFlush(team1);
        teamRepository.saveAndFlush(team2);

        List<Team> teams = teamRepository.findAll();

        assertEquals(2, teams.size());
    }

    // M.TER.3
    @Test
    public void testFindById() {
        Team team = new Team();
        team.setName("Prev_Team C");
        Team savedTeam = teamRepository.saveAndFlush(team);

        Optional<Team> foundTeam = teamRepository.findById(savedTeam.getTeam_id());

        assertTrue(foundTeam.isPresent());
        assertEquals("Prev_Team C", foundTeam.get().getName());
    }

    // M.TER.4
    @Test
    public void testDeleteById() {
        Team team = new Team();
        team.setName("Prev_Team C");
        Team savedTeam = teamRepository.saveAndFlush(team);

        // Ggf. abhängige ist_mitglied Einträge löschen
        istMitgliedRepository.deleteById(savedTeam.getTeam_id());

        teamRepository.deleteById(savedTeam.getTeam_id());

        Optional<Team> deletedTeam = teamRepository.findById(savedTeam.getTeam_id());
        assertFalse(deletedTeam.isPresent());
    }
}
