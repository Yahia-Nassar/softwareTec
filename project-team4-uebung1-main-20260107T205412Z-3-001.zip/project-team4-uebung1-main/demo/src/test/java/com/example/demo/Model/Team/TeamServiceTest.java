package com.example.demo.Model.Team;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class TeamServiceTest {

    @Mock
    private TeamRepository teamRepository;

    @InjectMocks
    private TeamService teamService;

        @BeforeEach
        public void setup() {
            MockitoAnnotations.openMocks(this);

            Team team1 = new Team();
            team1.setId(1L);
            team1.setName("Prev_Team A");

            Team team2 = new Team();
            team2.setId(2L);
            team2.setName("Prev_Team B");

            when(teamRepository.findAll()).thenReturn(Arrays.asList(team1, team2));
            when(teamRepository.findById(1L)).thenReturn(Optional.of(team1));

            // Diese Stubbing könnte unnötig sein, wenn `save()` nicht direkt getestet wird
            when(teamRepository.save(any(Team.class))).thenAnswer(invocation -> invocation.getArgument(0));
        }


    // M.TES.1
    @Test
    public void testSaveTeam() {
        Team newTeam = new Team();
        newTeam.setName("Prev_Team C");

        Team savedTeam = teamService.saveTeam(newTeam);

        assertEquals("Prev_Team C", savedTeam.getName());
        verify(teamRepository, times(1)).save(newTeam);
    }

    // M.TES.2
    @Test
    public void testGetAllTeams() {
        List<Team> teams = teamService.getAllTeams();

        assertEquals(2, teams.size());
        assertEquals("Prev_Team A", teams.get(0).getName());
        assertEquals("Prev_Team B", teams.get(1).getName());
        verify(teamRepository, times(1)).findAll();
    }

    // M.TES.3
    @Test
    public void testGetTeamById() {
        Optional<Team> team = teamService.getTeamById(1L);

        assertTrue(team.isPresent());
        assertEquals("Prev_Team A", team.get().getName());
        verify(teamRepository, times(1)).findById(1L);
    }

    // M.TES.4
    @Test
    public void testDeleteTeam() {
        teamService.deleteTeam(1L);

        verify(teamRepository, times(1)).deleteById(1L);
    }
}