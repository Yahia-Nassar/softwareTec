package com.example.demo.Model.Team;

import com.example.demo.Model.Ist_mitglied.ist_mitglied;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import org.mockito.Mockito;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

class TeamTest {

    private Team team;

    @BeforeEach
    public void setUp() {
        team = new Team();
        team.setId(1L);
        team.setName("Prev_Team A");

        ist_mitglied mitglied1 = Mockito.mock(ist_mitglied.class);
        ist_mitglied mitglied2 = Mockito.mock(ist_mitglied.class);

        List<ist_mitglied> mitglieder = new ArrayList<>();
        mitglieder.add(mitglied1);
        mitglieder.add(mitglied2);

        team.setIst_mitglieder(mitglieder);
    }

    // M.TE.1
    @Test
    public void testGetterandSetter() {
        // Test für getTeam_id
        assertEquals(1L, team.getTeam_id());

        // Test für getName
        assertEquals("Prev_Team A", team.getName());

        // Test für getIstMitglieder
        List<ist_mitglied> mitglieder = team.getIst_mitglieder();
        assertNotNull(mitglieder);
        assertEquals(2, mitglieder.size());
    }
}