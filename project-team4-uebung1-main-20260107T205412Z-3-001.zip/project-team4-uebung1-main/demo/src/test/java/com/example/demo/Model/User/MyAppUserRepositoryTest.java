package com.example.demo.Model.User;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import java.util.Optional;

@DataJpaTest
class MyAppUserRepositoryTest {

    @Autowired
    private MyAppUserRepository myAppUserRepository; // Repository für Tests

    @BeforeEach
    public void setUp() {
        // Datenbank leeren vor jedem Test
        myAppUserRepository.deleteAll();
    }

    // M.MAUR.1
    @Test
    public void testFindByUsername_UserExists() {
        String username = "test";
        MyAppUser myAppUser = new MyAppUser();
        myAppUser.setUsername(username);
        myAppUser.setPassword("password");

        // Speichern in der Test-Datenbank
        myAppUserRepository.save(myAppUser);

        // Abruf des gespeicherten Benutzers
        Optional<MyAppUser> user = myAppUserRepository.findByUsername(username);

        // Überprüfung, ob der Benutzer gefunden wurde
        assertTrue(user.isPresent());
        assertEquals("test", user.get().getUsername());
    }

    // M.MAUR.2
    @Test
    public void testFindByUsername_UserNotExists() {
        String username = "non";

        // Abruf eines nicht vorhandenen Benutzers
        Optional<MyAppUser> user = myAppUserRepository.findByUsername(username);

        // Überprüfung, ob kein Benutzer gefunden wurde
        assertTrue(user.isEmpty());
    }
}