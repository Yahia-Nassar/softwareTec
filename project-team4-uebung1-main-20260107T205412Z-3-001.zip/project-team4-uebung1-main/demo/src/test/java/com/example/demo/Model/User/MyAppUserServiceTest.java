package com.example.demo.Model.User;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.Mockito.when;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

@ExtendWith(MockitoExtension.class)
class MyAppUserServiceTest {

    @Mock
    private MyAppUserRepository myAppUserRepository;
    // Mock-Objekt für das MyAppUserRepository, um Abhängigkeiten während der Tests zu simulieren

    @InjectMocks
    private MyAppUserService myAppUserService;
    // MyAppUserService-Instanz, in die die Mock-Abhängigkeiten injiziert werden
    
    // M.MAUS.1

    @Test
    public void testLoadUserByUsername_UserFoundAndEnabled() {

        String username = "test";
        MyAppUser myAppUser = new MyAppUser();
        myAppUser.setUsername(username);
        myAppUser.setPassword("password");
        myAppUser.setEnabled(true); 


        when(myAppUserRepository.findByUsername(username))
            .thenReturn(Optional.of(myAppUser));


        UserDetails userDetails = myAppUserService.loadUserByUsername(username);

        assertEquals(username, userDetails.getUsername());
        assertEquals("password", userDetails.getPassword());
    }
    
    // M.MAUS.2
    @Test
    public void testLoadUserByUsername_UserDisabled() {

        String username = "test";
        MyAppUser myAppUser = new MyAppUser();
        myAppUser.setUsername(username);
        myAppUser.setPassword("password");
        myAppUser.setEnabled(false); 


        when(myAppUserRepository.findByUsername(username))
            .thenReturn(Optional.of(myAppUser));


        assertThrows(UsernameNotFoundException.class, () -> {
            myAppUserService.loadUserByUsername(username);
        });
    }
    
    // M.MAUS.3

    @Test
    public void testLoadUserByUsername_UserNotFound() {
        // Vorbereitung des Tests
        String username = "non";
        
        when(myAppUserRepository.findByUsername(username)).thenReturn(Optional.empty());

        // Durchführung der zu testenden Methode und Überprüfung der Ergebnisse
        assertThrows(UsernameNotFoundException.class, () -> {
            myAppUserService.loadUserByUsername(username);
        });
    }
    
    // M.MAUS.4

    @Test
    public void testEmptyFields() {
        // Erstellen eines MyAppUser-Objekts mit Testdaten
        MyAppUser myAppUser = new MyAppUser();
        myAppUser.setUsername("test");
        myAppUser.setEmail("test@example.com");
        myAppUser.setPassword("user");

        // Überprüfung, ob die Felder nicht leer sind
        if (myAppUser.getUsername().isEmpty()) {
            fail("Das Feld 'username' sollte nicht leer sein.");
        }

        if (myAppUser.getEmail().isEmpty()) {
            fail("Das Feld 'email' sollte nicht leer sein.");
        }

        if (myAppUser.getPassword().isEmpty()) {
            fail("Das Feld 'password' sollte nicht leer sein.");
        }
    }
    
    // M.MAUS.5

    @Test
    public void testDuplicateEmail() {
    }
}