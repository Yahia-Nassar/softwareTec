package com.example.demo.Model.User;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;

class MyAppUserTest {
    
    // M.MAU.1

    @Test
    public void testMyAppUserGettersAndSetters() {

        MyAppUser myAppUser = new MyAppUser();

        myAppUser.setId(1L);
        myAppUser.setUsername("test");
        myAppUser.setEmail("Test@test.com");
        myAppUser.setPassword("password");

        assertEquals(1L, myAppUser.getId());
        assertEquals("test", myAppUser.getUsername());
        assertEquals("Test@test.com", myAppUser.getEmail());
        assertEquals("password", myAppUser.getPassword());
    }
}