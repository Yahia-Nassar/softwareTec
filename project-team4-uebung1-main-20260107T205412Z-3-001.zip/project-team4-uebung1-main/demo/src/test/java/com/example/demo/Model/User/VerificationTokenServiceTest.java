package com.example.demo.Model.User;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class VerificationTokenServiceTest {

    @Mock
    private MyAppUserRepository userRepository;

    @InjectMocks
    private VerificationTokenService verificationTokenService;
    
    // M.VTS.1
    @Test
    void testCreateVerificationToken() {

        MyAppUser user = new MyAppUser();
        String token = "test-token";

        verificationTokenService.createVerificationToken(user, token);

        assertEquals(token, user.getVerificationToken());
        verify(userRepository).save(user);
    }
    
    // M.VTS.2
    @Test
    void testValidateVerificationTokenValid() {

        String token = "valid-token";
        MyAppUser user = new MyAppUser();
        user.setVerificationToken(token);
        when(userRepository.findByVerificationToken(token)).thenReturn(Optional.of(user));

        String result = verificationTokenService.validateVerificationToken(token);

        assertEquals("valid", result);
        assertEquals(true, user.getEnabled());
        verify(userRepository).save(user);
    }
    
    // M.VTS.3
    @Test
    void testValidateVerificationTokenInvalid() {

        String token = "invalid-token";
        when(userRepository.findByVerificationToken(token)).thenReturn(Optional.empty());

        String result = verificationTokenService.validateVerificationToken(token);

        assertEquals("invalid", result);
    }
}