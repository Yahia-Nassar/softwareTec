package com.example.demo.Model.UserStories;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;
import org.junit.jupiter.api.Test;

import com.example.demo.Model.Tasks.priorityEnum;

public class UserStoryDtoTest {

    // M.USD.1
    @Test
    public void testSettersAndGetters() {
        UserStoryDto userStory = new UserStoryDto();
        userStory.setId(1L);
        userStory.setTitle("Test User Story");
        userStory.setDescription("Dies ist eine Testbeschreibung.");
        userStory.setAcceptanceCriteria("Muss erfolgreich getestet werden.");
        userStory.setPriority(priorityEnum.HIGH);
        userStory.setSprint(2L);
        userStory.setTaskIds(List.of(101L, 102L));

        assertEquals(1L, userStory.getId());
        assertEquals("Test User Story", userStory.getTitle());
        assertEquals("Dies ist eine Testbeschreibung.", userStory.getDescription());
        assertEquals("Muss erfolgreich getestet werden.", userStory.getAcceptanceCriteria());
        assertEquals(priorityEnum.HIGH, userStory.getPriority());
        assertEquals(2L, userStory.getSprint());
        assertEquals(List.of(101L, 102L), userStory.getTaskIds());
    }
}
