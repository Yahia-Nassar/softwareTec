package com.example.demo.Model.UserStories;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import java.util.Optional;

@DataJpaTest
class UserStoryRepositoryTest {

    @Autowired
    private UserStoryRepository userStoryRepository;

    @BeforeEach
    public void setUp() {
        // Datenbank vor jedem Test leeren
        userStoryRepository.deleteAll();
    }
    
    // M.USR.1
    @Test
    public void testFindByTitle() {
        UserStory userStory = new UserStory();
        userStory.setTitle("testtitle");

        // Speichern in der Test-Datenbank
        userStoryRepository.save(userStory);

        // Abruf des gespeicherten UserStory-Objekts
        Optional<UserStory> foundUserStory = userStoryRepository.findByTitle("testtitle");

        // Überprüfung, ob der Titel korrekt ist
        assertTrue(foundUserStory.isPresent());
        assertEquals("testtitle", foundUserStory.get().getTitle());
    }
}