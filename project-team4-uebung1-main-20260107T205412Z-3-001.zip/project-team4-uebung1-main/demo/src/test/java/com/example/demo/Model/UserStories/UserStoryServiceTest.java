package com.example.demo.Model.UserStories;

import com.example.demo.Model.Tasks.Task;
import com.example.demo.Model.Tasks.TaskRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import jakarta.persistence.EntityNotFoundException;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class UserStoryServiceTest {

    @Mock
    private UserStoryRepository userStoryRepository;

    @Mock
    private TaskRepository taskRepository;

    @InjectMocks
    private UserStoryService userStoryService;

    // M.USS.1
    @Test
    void testDeleteUserStorySuccess() {

        Long Id = 123L;
        UserStory userStory = new UserStory();
        userStory.setTitle("userStoryTitle");

        Task task1 = new Task();
        Task task2 = new Task();
        List<Task> tasks = Arrays.asList(task1, task2);

        when(userStoryRepository.findById(Id)).thenReturn(Optional.of(userStory));
        when(taskRepository.findByUserStory(userStory)).thenReturn(tasks);

        userStoryService.deleteUserStory(Id);

        verify(taskRepository).deleteAll(tasks);
        verify(userStoryRepository).delete(userStory);
    }
    
    // M.USS.2
    @Test
    void testDeleteUserStoryNotFound() {

        Long Id = 123L;

        when(userStoryRepository.findById(Id)).thenReturn(Optional.empty());

        assertThrows(EntityNotFoundException.class, () -> userStoryService.deleteUserStory(Id));
        verify(taskRepository, never()).deleteAll(any());
        verify(userStoryRepository, never()).delete(any());
    }
}
