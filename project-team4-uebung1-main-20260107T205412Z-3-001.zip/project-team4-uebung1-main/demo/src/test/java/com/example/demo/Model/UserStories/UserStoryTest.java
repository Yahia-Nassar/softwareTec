package com.example.demo.Model.UserStories;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

import com.example.demo.Model.Tasks.priorityEnum;
import com.example.demo.Model.Sprints.Sprint;

class UserStoryTest {

    // M.US.1

    @Test
    public void testUserStoryGettersAndSetters() {
        UserStory userStory = new UserStory();

        userStory.setId(123L);
        userStory.setTitle("test");
        userStory.setstatus(statususerstory.INCOMPLETE);
        userStory.setDescription("Hier steht was");
        userStory.setAcceptanceCriteria("Ja");
        userStory.setPriority(priorityEnum.HIGH);
        Sprint sprint = new Sprint();
        userStory.setSprint(sprint);

        assertEquals(123L, userStory.getId());
        assertEquals("test", userStory.getTitle());
        assertEquals(statususerstory.INCOMPLETE, userStory.getstatus());
        assertEquals("Hier steht was", userStory.getDescription());
        assertEquals("Ja", userStory.getAcceptanceCriteria());
        assertEquals(priorityEnum.HIGH, userStory.getPriority());
        assertEquals(sprint, userStory.getSprint());
    }
}