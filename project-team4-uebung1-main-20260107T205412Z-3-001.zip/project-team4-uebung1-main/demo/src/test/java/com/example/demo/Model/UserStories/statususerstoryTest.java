package com.example.demo.Model.UserStories;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class statususerstoryTest {
    
    // M.SUS.1

    @Test
    public void testStatusUserStoryValues() {
        // Test if the enum contains the correct values
        assertEquals(statususerstory.BACKLOG, statususerstory.valueOf("BACKLOG"));
        assertEquals(statususerstory.IN_PROGRESS, statususerstory.valueOf("IN_PROGRESS"));
        assertEquals(statususerstory.COMPLETED, statususerstory.valueOf("COMPLETED"));
        assertEquals(statususerstory.INCOMPLETE, statususerstory.valueOf("INCOMPLETE"));
        assertEquals(statususerstory.BACKLOG, statususerstory.valueOf("BACKLOG"));
        assertEquals(statususerstory.BURNBARREL, statususerstory.valueOf("BURNBARREL"));
    }
    
    // M.SUS.2

    @Test
    public void testStatusUserStoryCount() {
        // Test if the enum contains the correct number of values
        statususerstory[] statuses = statususerstory.values();
        assertEquals(6, statuses.length);
    }
}
