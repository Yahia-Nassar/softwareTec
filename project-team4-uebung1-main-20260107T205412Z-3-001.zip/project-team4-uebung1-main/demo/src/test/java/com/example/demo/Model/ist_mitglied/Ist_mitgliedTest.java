package com.example.demo.Model.ist_mitglied;

import com.example.demo.Model.Team.Team;
import com.example.demo.Model.Ist_mitglied.ist_mitglied;
import com.example.demo.Model.Nutzer.Nutzer;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;


public class Ist_mitgliedTest {

    // M.I.1
    @Test
    void testRolle() {
        ist_mitglied mitglied = new ist_mitglied();
        mitglied.setRolle("Admin");
        assertEquals("Admin", mitglied.getRolle());
    }    

    // M.I.2
    @Test
    void testNutzer() {
        ist_mitglied mitglied = new ist_mitglied();
        Nutzer nutzer = new Nutzer();
        mitglied.setNutzer(nutzer);
        assertEquals(nutzer, mitglied.getNutzer());
    }

    // M.I.3
    @Test
    void testTeam() {
        ist_mitglied mitglied = new ist_mitglied();
        Team team = new Team();
        mitglied.setTeam(team);
        assertEquals(team, mitglied.getTeam());
    }
} 
