/* package com.example.demo.Model.ist_mitglied;

import com.example.demo.Model.Ist_mitglied.ist_mitglied;
import com.example.demo.Model.Ist_mitglied.ist_mitgliedRepository;
import com.example.demo.Model.Nutzer.Nutzer;
import com.example.demo.Model.Team.Team;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import static org.assertj.core.api.Assertions.assertThat;

@DataJpaTest
public class ist_mitgliedRepositoryTest {

    @Autowired
    private ist_mitgliedRepository repository;

    @Test
    void testSaveAndFindIstMitglied() {

        Nutzer nutzer = new Nutzer();
        nutzer.setVorname("Max");

        Team team = new Team();
        team.setName("Dev Team");

        ist_mitglied mitglied = new ist_mitglied();
        mitglied.setNutzer(nutzer);
        mitglied.setTeam(team);
        mitglied.setRolle("Teamleiter");

        ist_mitglied saved = repository.save(mitglied);

        assertThat(saved.getNutzer().getNutzer_id()).isNotNull();
        assertThat(saved.getRolle()).isEqualTo("Teamleiter");
    }
}
*/