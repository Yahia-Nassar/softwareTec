package com.example.demo.Model.ist_mitglied;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.example.demo.Model.Ist_mitglied.ist_mitglied;
import com.example.demo.Model.Ist_mitglied.ist_mitgliedRepository;
import com.example.demo.Model.Ist_mitglied.ist_mitgliedService;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
public class ist_mitgliedServiceTest {

    @Mock
    private ist_mitgliedRepository ist_mitgliedRepository;

    @InjectMocks
    private ist_mitgliedService ist_mitgliedService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    // M.IS.1
    @Test
    void testSaveIst_mitglied() {
        ist_mitglied member = new ist_mitglied();
        when(ist_mitgliedRepository.save(member)).thenReturn(member);

        ist_mitglied result = ist_mitgliedService.saveIst_mitglied(member);

        assertNotNull(result);
        verify(ist_mitgliedRepository, times(1)).save(member);
    }

    // M.IS.2
    @Test
    void testGetAllIst_mitglied() {
        List<ist_mitglied> members = new ArrayList<>();
        when(ist_mitgliedRepository.findAll()).thenReturn(members);

        List<ist_mitglied> result = ist_mitgliedService.getAllIst_mitglied();

        assertNotNull(result);
        assertEquals(members.size(), result.size());
        verify(ist_mitgliedRepository, times(1)).findAll();
    }

    // M.IS.3
    @Test
    void testGetIst_mitgliedById() {
        Long id = 1L;
        ist_mitglied member = new ist_mitglied();
        when(ist_mitgliedRepository.findById(id)).thenReturn(Optional.of(member));

        Optional<ist_mitglied> result = ist_mitgliedService.getIst_mitgliedById(id);

        assertTrue(result.isPresent());
        assertEquals(member, result.get());
        verify(ist_mitgliedRepository, times(1)).findById(id);
    }

    // M.IS.4
    @Test
    void testDeleteIst_mitgliedById() {
        Long id = 1L;

        doNothing().when(ist_mitgliedRepository).deleteById(id);

        ist_mitgliedService.deleteIst_mitgliedById(id);

        verify(ist_mitgliedRepository, times(1)).deleteById(id);
    }
}