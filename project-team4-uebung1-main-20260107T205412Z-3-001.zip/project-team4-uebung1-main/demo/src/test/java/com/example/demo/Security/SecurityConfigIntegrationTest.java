package com.example.demo.Security;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.beans.factory.annotation.Autowired;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.ANY)
class SecurityConfigIntegrationTest {

    @Autowired
    private MockMvc mockMvc;

    // S.SCI.1
    @Test
    public void testPublicEndpointsAreAccessible() throws Exception {
        mockMvc.perform(get("/req/signup"))
                .andExpect(status().isOk());

        mockMvc.perform(get("/auth/status"))
                .andExpect(status().isOk());
    }

    // S.SCI.2
    @Test
    public void testProtectedEndpointsRedirectToLogin() throws Exception {
        mockMvc.perform(get("/projects"))
                .andExpect(status().isFound()) // 302 Redirect erwarten
                .andExpect(header().string("Location", "http://localhost/req/login")); // Prüft die Umleitungs-URL
    }

    // S.SCI.3
    @Test
    @WithMockUser(username = "testUser", roles = "USER")
    public void testAuthenticatedUserIsRedirectedCorrectly() throws Exception {
        mockMvc.perform(get("/projects"))
                .andExpect(status().isFound()) // 302 Redirect erwarten
                .andExpect(header().string("Location", "http://localhost:3000/projectselection")); // Prüft die Ziel-URL nach der Authentifizierung
    }
}