package com.example.demo.Security;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;

import com.example.demo.Model.User.MyAppUserService;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.test.context.junit.jupiter.SpringJUnitConfig;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

@SpringJUnitConfig
public class SecurityConfigUnitTest {

    @Mock
    private MyAppUserService myAppUserService;

    @InjectMocks
    private SecurityConfig securityConfig;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    // S.SCU.1
    @Test
    public void testPasswordEncoder() {
        PasswordEncoder passwordEncoder = securityConfig.passwordEncoder();
        assertNotNull(passwordEncoder);
    }

    // S.SCU.2
    @Test
    public void testAuthenticationProvider() {
        AuthenticationProvider authenticationProvider = securityConfig.authenticationProvider();
        assertNotNull(authenticationProvider);
    }

    // S.SCU.3
    @Test
    public void testUserDetailsService() {
        UserDetailsService userDetailsService = securityConfig.userDetailsService();
        assertNotNull(userDetailsService);
    }

    // S.SCU.4
    @Test
    public void testCorsConfigurationSource() {
        CorsConfigurationSource source = securityConfig.corsConfigurationSource();
        assertNotNull(source);

        UrlBasedCorsConfigurationSource urlSource = (UrlBasedCorsConfigurationSource) source;
        CorsConfiguration corsConfig = urlSource.getCorsConfigurations().get("/**");

        assertNotNull(corsConfig);

        List<String> allowedOrigins = corsConfig.getAllowedOrigins();
        List<String> allowedMethods = corsConfig.getAllowedMethods();

        assertNotNull(allowedOrigins);
        assertTrue(allowedOrigins.contains("http://localhost:3000"));

        assertNotNull(allowedMethods);
        assertTrue(allowedMethods.containsAll(List.of("GET", "POST", "PUT", "DELETE")));

        Boolean allowCredentials = corsConfig.getAllowCredentials();
        assertNotNull(allowCredentials);
        assertTrue(allowCredentials);
    }
}
