package com.example.demo.util;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class RandomStringGeneratorTest {
    
    // U.RSG.1
    @Test
    public void testGenerateString_Length() {

        int length = 10;

        String string = RandomStringGenerator.generateString(length);

        assertNotNull(string);
        assertEquals(length, string.length());
    }
    
    // U.RSG.2
    @Test
    public void testGenerateString_Unique() {

        int length = 15;

        String string1 = RandomStringGenerator.generateString(length);
        String string2 = RandomStringGenerator.generateString(length);

        assertNotEquals(string1, string2);
    }
    
    // U.RSG.3
    @Test
    public void testGenerateString_EmptyCase() {

        int length = 0;

        String string = RandomStringGenerator.generateString(length);

        assertNotNull(string);
        assertEquals(0, string.length());
    }
}
