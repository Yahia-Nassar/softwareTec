package com.example.demo.util.event;

import com.example.demo.Model.User.MyAppUser;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class OnRegistrationCompleteEventTest {
    
    // U.E.ORCE.1
    @Test
    void testOnRegistrationCompleteEvent() {

        MyAppUser user = new MyAppUser();

        OnRegistrationCompleteEvent event = new OnRegistrationCompleteEvent(user);

        assertEquals(user, event.getUser());
        assertEquals(user, event.getSource());
    }
}