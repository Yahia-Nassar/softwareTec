package com.example.demo.util.event;

import com.example.demo.Model.User.MyAppUser;
import com.example.demo.Model.User.EmailService;
import com.example.demo.Model.User.VerificationTokenService;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.contains;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class RegistrationListenerTest {

    @Mock
    private VerificationTokenService tokenService;

    @Mock
    private EmailService emailService;

    @InjectMocks
    private RegistrationListener registrationListener;
    
    // U.E.RL.1
    @Test
    void testOnApplicationEvent() {

        MyAppUser user = new MyAppUser();
        user.setEmail("test@example.com");
        OnRegistrationCompleteEvent event = new OnRegistrationCompleteEvent(user);

        doNothing().when(tokenService).createVerificationToken(any(MyAppUser.class), anyString());
        doNothing().when(emailService).sendEmail(anyString(), anyString(), anyString());

        registrationListener.onApplicationEvent(event);

        verify(tokenService).createVerificationToken(eq(user), anyString());
        verify(emailService).sendEmail(eq(user.getEmail()), eq("Email Verification"), contains("http://localhost:8080/verify-email?token="));
    }
}
