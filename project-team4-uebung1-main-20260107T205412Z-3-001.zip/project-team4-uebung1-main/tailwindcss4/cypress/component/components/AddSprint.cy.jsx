import React from 'react';
import { mount } from 'cypress/react';
import AddSprint from '../../../src/components/AddSprint'; // Pfad ggf. anpassen!

describe('AddSprint Komponente', () => {
  // C.C.AS.1
  it('öffnet das Popup und fügt einen Sprint hinzu', () => {
    const onAddSprint = cy.stub().as('onAddSprintStub');

    mount(<AddSprint onAddSprint={onAddSprint} />);

    // Popup öffnen
    cy.contains('Add Sprint').click();

    // Felder ausfüllen
    cy.get('input[type="text"]').type('Sprint 1');
    cy.get('input[type="date"]').eq(0).type('2025-06-01');
    cy.get('input[type="date"]').eq(1).type('2025-06-15');

    // Formular direkt submitten
    cy.get('form').submit();

    // Prüfen, dass der Stub aufgerufen wurde
    cy.get('@onAddSprintStub').should('have.been.calledOnce');
    cy.get('@onAddSprintStub').its('firstCall.args.0').should('deep.equal', {
      name: 'Sprint 1',
      startDate: '2025-06-01',
      endDate: '2025-06-15'
    });
  });
});