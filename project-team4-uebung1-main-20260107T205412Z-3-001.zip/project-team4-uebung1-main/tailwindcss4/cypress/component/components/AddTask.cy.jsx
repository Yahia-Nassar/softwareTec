import React from 'react';
import { mount } from 'cypress/react';
import AddTask from '../../../src/components/AddTask';

describe('AddTask-Komponente', () => {
    // C.C.AT.1
  it('öffnet das Popup und fügt eine neue Aufgabe hinzu', () => {
    const setCards = cy.stub().as('setCardsStub');

    // Dummy-Daten übergeben
    const dummyUserStories = [
      { id: 1, title: 'Story 1' },
      { id: 2, title: 'Story 2' }
    ];

    const dummyTasks = [
      { id: 1, title: 'Task 1' },
      { id: 2, title: 'Task 2' }
    ];

    const dummyCards = [];

    mount(
      <AddTask
        setCards={setCards}
        userStories={dummyUserStories}
        tasks={dummyTasks}
        cards={dummyCards}
      />
    );

    // Popup öffnen
    cy.contains('Add Task').click();

    // Formular ausfüllen
    cy.get('input[type="text"]').type('Testaufgabe');
    cy.get('textarea').type('Beschreibung der Testaufgabe');
    cy.get('select').eq(0).select('IN_PROGRESS');
    cy.get('select').eq(1).select('HIGH');
    cy.get('input[type="number"]').clear().type('5');

    // Formular absenden
    cy.get('form').submit();

    // Prüfen, dass setCards aufgerufen wurde
    cy.get('@setCardsStub').should('have.been.called');
  });
});