import React from 'react';
import { mount } from 'cypress/react';
import AddUserStory from '../../../src/components/AddUserStory'; // Passe den Pfad an, falls nötig

describe('AddUserStory Komponente', () => {
  // C.C.AUS.1
  it('öffnet das Popup und fügt eine neue User Story hinzu', () => {
    const setCards = cy.stub().as('setCardsStub');

    mount(<AddUserStory columnName="BACKLOG" setCards={setCards} />);

    // Popup öffnen
    cy.contains('Add User Story').click();

    // Felder ausfüllen
    cy.get('input[type="text"]').type('Meine User Story');
    cy.get('textarea').eq(0).type('Beschreibung der User Story');
    cy.get('textarea').eq(1).type('Akzeptanzkriterien der User Story');
    cy.get('select').eq(0).select('IN_PROGRESS');
    cy.get('select').eq(1).select('HIGH');

    // Formular absenden
    cy.get('form').submit();

    // Prüfen, ob setCards aufgerufen wurde
    cy.get('@setCardsStub').should('have.been.calledOnce');

    // Optional: Prüfen, ob der neue Eintrag die korrekten Werte hat
    cy.get('@setCardsStub').its('firstCall.args.0').should('satisfy', (fn) => {
      const result = fn([]);
      return result.length === 1 &&
             result[0].title === 'Meine User Story' &&
             result[0].description === 'Beschreibung der User Story' &&
             result[0].acceptanceCriteria === 'Akzeptanzkriterien der User Story' &&
             result[0].status === 'IN_PROGRESS' &&
             result[0].priority === 'HIGH' &&
             result[0].columnName === 'BACKLOG';
    });
  });
});