import React from 'react';
import { mount } from 'cypress/react';
import AssignedUserSelector from '../../../src/components/AssignedUserSelection';

describe('AssignedUserSelection Komponente', () => {
  // C.C.ASUS.1
  it('sollte User hinzufÃ¼gen und entfernen', () => {
    const assignedUsers = [];
    const setAssignedUsers = cy.stub().as('setAssignedUsersStub');

    // Patch fetch im Fenster
    cy.window().then(win => {
      cy.stub(win, 'fetch').resolves({
        ok: true,
        json: async () => [
          { id: 1, username: 'Alice' },
          { id: 2, username: 'Bob' }
        ]
      });
    });

    // Mounten
    mount(
      <AssignedUserSelector
        assignedUsers={assignedUsers}
        setAssignedUsers={setAssignedUsers}
        projectId={1}
      />
    );

    // Jetzt die Auswahl abwarten
    cy.get('select').should('contain', 'Alice');
    cy.get('select').select('1');
    cy.get('@setAssignedUsersStub').should('have.been.called');

    cy.get('select').select('2');
    cy.get('@setAssignedUsersStub').should('have.been.calledTwice');
  });
});