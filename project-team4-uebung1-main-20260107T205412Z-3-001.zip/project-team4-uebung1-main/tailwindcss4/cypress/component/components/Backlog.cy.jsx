import React from 'react';
import { mount } from 'cypress/react';
import Backlog from '../../../src/components/Backlog';
import { MemoryRouter, Route, Routes } from 'react-router-dom';

describe('Backlog Komponente', () => {
  // C.C.B.1
  it('sollte User Stories laden und Save aufrufen', () => {
    cy.window().then((win) => {
      cy.stub(win, 'fetch').callsFake((url, options) => {
        if (url.includes('/getuserstories')) {
          return Promise.resolve({
            ok: true,
            json: () => Promise.resolve([
              {
                id: 1,
                title: 'Test Story',
                description: 'Beschreibung',
                acceptanceCriteria: 'Akzeptanzkriterien',
                priority: 'HIGH',
                sprint: 1
              }
            ])
          });
        }

        if (url.includes('/saveUSCards')) {
          return Promise.resolve({
            ok: true,
            json: () => Promise.resolve({ success: true })
          });
        }

        if (url.includes('/getRole')) {
          return Promise.resolve({
            ok: true,
            json: () => Promise.resolve({ role: 'Admin' })
          });
        }

        // Fallback: Immer ein leeres OK
        return Promise.resolve({
          ok: true,
          json: () => Promise.resolve({})
        });
      }).as('fetchStub');
    });

    mount(
      <MemoryRouter initialEntries={['/backlog/1']}>
        <Routes>
          <Route path="/backlog/:projectId" element={<Backlog />} />
        </Routes>
      </MemoryRouter>
    );

    cy.contains('Test Story').should('be.visible');

    cy.contains('Save').click();

    cy.get('@fetchStub').should('be.calledWithMatch', Cypress.sinon.match((url) =>
      url.includes('/saveUSCards')
    ));
  });
});