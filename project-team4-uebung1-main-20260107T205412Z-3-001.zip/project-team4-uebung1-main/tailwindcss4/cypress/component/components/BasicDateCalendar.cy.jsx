import React from 'react';
import { mount } from 'cypress/react';
import BasicDateCalendar from '../../../src/components/BasicDateCalendar'; // Pfad ggf. anpassen
import dayjs from 'dayjs';

describe('BasicDateCalendar Komponente', () => {
  // C.C.BDC.1
  it('sollte das aktuelle Datum markieren und Today-Button zurücksetzen', () => {
    mount(<BasicDateCalendar />);

    // Heute-Button klicken
    cy.contains('Today').click();

    const today = dayjs().date();

    // Aktuelles Datum sollte im Kalender markiert sein
    cy.get('[role="gridcell"]')
      .not('[aria-hidden="true"]')
      .not('[disabled]')
      .contains(today)
      .should('exist');
  });

  // C.C.BDC.2
  it('sollte Meeting-Modale öffnen, wenn auf leeres Datum geklickt wird', () => {
    const onOpenMeetingModal = cy.stub().as('onOpenMeetingModal');

    // Beispiel-Event auf dem 1. Tag im Monat – wir klicken später auf den 2.
    const testEvents = [
      {
        date: dayjs().startOf('month').toISOString(),
        type: 'Meeting',
        description: 'Nicht klicken',
      },
    ];

    mount(<BasicDateCalendar events={testEvents} onOpenMeetingModal={onOpenMeetingModal} />);

    // Klicke gezielt auf Tag 2 – dieser hat **kein** Event
    cy.get('[role="gridcell"]')
      .not('[aria-hidden="true"]')
      .not('[disabled]')
      .contains(/^2$/) // exakt "2"
      .click({ force: true });

    cy.get('@onOpenMeetingModal').should('have.been.called');
  });

  // C.C.BDC.3
  it('sollte Tooltip mit Event-Daten anzeigen, wenn Event vorhanden ist', () => {
    const eventDay = dayjs().add(1, 'day');
    const events = [
      {
        date: eventDay.toISOString(),
        type: 'Meeting',
        description: 'Test-Meeting',
      },
    ];

    mount(<BasicDateCalendar events={events} />);

    cy.get('[role="gridcell"]')
      .not('[aria-hidden="true"]')
      .not('[disabled]')
      .contains(eventDay.date())
      .click();

    cy.on('window:alert', (str) => {
      expect(str).to.include('Meeting');
      expect(str).to.include('Test-Meeting');
    });
  });
});