import React from 'react';
import { mount } from 'cypress/react';
import { Column } from '../../../src/components/Board';
import { MemoryRouter, Route, Routes } from 'react-router-dom';

describe('Column Komponente', () => {
  const sampleCard = {
    type: 'task',
    title: 'Test Task',
    id: 1,
    status: 'TODO',
    description: 'Beschreibung',
    acceptanceCriteria: 'Akzeptanz',
    priority: 'LOW',
    isTemp: false,
    frontendID: 'task-1',
    sprint: 1
  };

  // C.C.BD.1
  it('sollte Drag & Drop Stub triggern', () => {
    const setCards = cy.stub().as('setCardsStub');

    mount(
      <MemoryRouter initialEntries={['/project/1']}>
        <Routes>
          <Route
            path="/project/:projectId"
            element={
              <Column
                title="ToDo"
                headingColor="text-white"
                cards={[sampleCard]}
                status="TODO"
                setCards={setCards}
                boardType="sprint"
                sprint={1}
                sprintData={{}}
                setSprints={() => {}}
              />
            }
          />
        </Routes>
      </MemoryRouter>
    );

    // Stelle sicher, dass das Drag-Element existiert
    cy.get('.cursor-grab').should('exist');

    // Ziehen starten (DataTransfer Stub notwendig!)
    const dataTransfer = new DataTransfer();
    cy.get('.cursor-grab').trigger('dragstart', { dataTransfer });

    // Ziel finden – `.flex-1` (Drop-Zone) – und auf genau 1 Element beschränken
    cy.get('.flex-1').first().trigger('drop', { dataTransfer });

    // setCards wurde (indirekt) aufgerufen – hier nur Existenz prüfen
    cy.get('@setCardsStub').should('exist');
  });
});