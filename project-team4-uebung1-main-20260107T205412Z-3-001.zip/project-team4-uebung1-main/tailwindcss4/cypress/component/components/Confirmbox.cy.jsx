import { mount } from 'cypress/react';
import Confirmbox, { confirm3 } from '../../../src/components/Confirmbox';

describe('Confirmbox Komponente', () => {
  // C.C.CB.1
  it('sollte Confirm Dialog öffnen und bestätigen', () => {
    mount(<Confirmbox />);
    cy.contains('Confirm').click();
    cy.contains('Are you sure you want to proceed?').should('be.visible');
    cy.contains('Yes').click();
    cy.contains('Confirmed').should('be.visible');
  });

  // C.C.CB.2
  it('sollte Delete Dialog öffnen und abbrechen', () => {
    mount(<Confirmbox />);
    cy.contains('Delete').first().click();
    cy.contains('Do you want to delete the task?').should('be.visible');
    cy.contains('No').click();
    cy.contains('Rejected').should('be.visible');
  });

  // C.C.CB.3
  it('sollte confirm3 Promise auflösen', () => {
    mount(<Confirmbox />);
    confirm3().then((result) => {
      expect(result).to.be.true;
    });
    cy.contains('Confirm').click(); // Klick auf den Confirm-Button im Dialog
  });
});