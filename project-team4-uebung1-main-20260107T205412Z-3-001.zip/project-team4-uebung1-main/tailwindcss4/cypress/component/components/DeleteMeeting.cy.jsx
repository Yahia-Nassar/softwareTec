import { mount } from 'cypress/react';
import DeleteMeeting from '../../../src/components/DeleteMeeting'; // Passe den Pfad an!

describe('DeleteMeeting Komponente', () => {
  // C.C.DM.1
  it('sollte fetch aufrufen und setMeetings aktualisieren', () => {
    // Stub für setMeetings
    const setMeetings = cy.stub().as('setMeetingsStub');

    // Stub für fetch (API-Call simulieren)
    cy.window().then((win) => {
      cy.stub(win, 'fetch').resolves({
        ok: true,
        json: () => Promise.resolve([{ meetingId: 2, title: 'Neues Meeting' }])
      }).as('fetchStub');
    });

    // Mount der Komponente
    mount(
      <DeleteMeeting
        meeting={{ meetingId: 1 }}
        setMeetings={setMeetings}
        projectId={123}
      />
    );

    // Button klicken
    cy.contains('Delete').click();

    // Prüfen, ob fetch aufgerufen wurde
    cy.get('@fetchStub').should('have.been.calledWithMatch', /deletemeeting/);

    // Prüfen, ob setMeetings aufgerufen wurde
    cy.get('@setMeetingsStub').should('have.been.calledWithMatch', (meetings) =>
      Array.isArray(meetings) && meetings.some(m => m.meetingId === 2)
    );
  });
});
