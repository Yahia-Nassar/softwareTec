import { mount } from 'cypress/react';
import DeleteTask from '../../../src/components/DeleteTask'; 
import { MemoryRouter, Routes, Route } from 'react-router-dom';
import React, { useState } from 'react';

describe('DeleteTask Komponente', () => {
  // C.C.DT.1
  it('sollte fetch aufrufen und setCards aktualisieren', () => {
    const userStory = { id: 1, title: 'Test Story', status: 'TODO' };

    cy.window().then(win => {
      cy.stub(win, 'fetch').resolves({
        ok: true,
        json: () => Promise.resolve([]),
      }).as('fetchStub');
    }).then(() => {
      function WrapperComponent() {
        const [cards, setCards] = useState([userStory]);
        return (
          <MemoryRouter initialEntries={['/project/123']}>
            <Routes>
              <Route
                path="/project/:projectId"
                element={
                  <DeleteTask
                    columnName="TODO"
                    setCards={setCards}
                    UserStory={userStory}
                  />
                }
              />
            </Routes>
          </MemoryRouter>
        );
      }

      mount(<WrapperComponent />);
    });

    // Trigger-Button klicken
    cy.contains('button', 'Delete').click();

    // Modal sichtbar
    cy.get('.popup-overlay').should('be.visible');

    // Modal-Button klicken
    cy.get('.popup-overlay')
      .find('button')
      .contains('Delete')
      .click({ force: true });

    // fetch wurde aufgerufen
    cy.get('@fetchStub').should('have.been.calledWithMatch', /saveTasks\?projectid=123/);
  });
});