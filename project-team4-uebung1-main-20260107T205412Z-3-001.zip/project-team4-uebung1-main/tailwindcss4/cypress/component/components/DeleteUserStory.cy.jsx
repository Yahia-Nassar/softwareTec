import { mount } from 'cypress/react';
import DeleteUserStory from '../../../src/components/DeleteUserStory'; // Pfad ggf. anpassen
import { MemoryRouter, Routes, Route } from 'react-router-dom';
import React, { useState } from 'react';

describe('DeleteUserStory Komponente', () => {
  // C.C.DUS.1
  it('sollte fetch für Rolle und saveUSCards aufrufen und setCards aktualisieren', () => {
    const userStory = { id: 1, title: 'Test Story', status: 'TODO', sprint: 42 };

    // Stub für fetch
    cy.window().then(win => {
      cy.stub(win, 'fetch')
        .callsFake((url, options) => {
          if (url.includes('/getRole')) {
            return Promise.resolve({
              ok: true,
              json: () => Promise.resolve('PRODUCT_OWNER'),
            });
          }
          if (url.includes('/saveUSCards')) {
            return Promise.resolve({
              ok: true,
              json: () => Promise.resolve([]),
            });
          }
          return Promise.reject(new Error('Unexpected fetch URL'));
        }).as('fetchStub');
    }).then(() => {
      function WrapperComponent() {
        const [cards, setCards] = useState([userStory]);
        return (
          <MemoryRouter initialEntries={['/project/123']}>
            <Routes>
              <Route
                path="/project/:projectId"
                element={
                  <DeleteUserStory
                    columnName="TODO"
                    setCards={setCards}
                    UserStory={userStory}
                  />
                }
              />
            </Routes>
          </MemoryRouter>
        );
      }

      mount(<WrapperComponent />);
    });

    // Sicherstellen, dass die Rolle geladen wurde
    cy.get('@fetchStub').should('have.been.calledWithMatch', /getRole\?projectid=123/);

    // Trigger-Button klicken
    cy.contains('button', 'Delete').click();

    // Modal sichtbar
    cy.get('.popup-overlay').should('be.visible');

    // Modal-Delete klicken
    cy.get('.popup-overlay')
      .find('button')
      .contains('Delete')
      .click({ force: true });

    // saveUSCards wurde aufgerufen
    cy.get('@fetchStub').should('have.been.calledWithMatch', /saveUSCards\?projectid=123/);
  });
  // C.C.DUS.2
  it('sollte Error-Notification zeigen, wenn nicht PRODUCT_OWNER', () => {
    const userStory = { id: 1, title: 'Test Story', status: 'TODO', sprint: 42 };

    // Stub für fetch (gibt Rolle zurück, die kein Product Owner ist)
    cy.window().then(win => {
      cy.stub(win, 'fetch').callsFake((url, options) => {
        if (url.includes('/getRole')) {
          return Promise.resolve({
            ok: true,
            json: () => Promise.resolve('DEVELOPER'),
          });
        }
        return Promise.reject(new Error('Unexpected fetch URL'));
      }).as('fetchStub');
    }).then(() => {
      function WrapperComponent() {
        const [cards, setCards] = useState([userStory]);
        return (
          <MemoryRouter initialEntries={['/project/123']}>
            <Routes>
              <Route
                path="/project/:projectId"
                element={
                  <DeleteUserStory
                    columnName="TODO"
                    setCards={setCards}
                    UserStory={userStory}
                  />
                }
              />
            </Routes>
          </MemoryRouter>
        );
      }

      mount(<WrapperComponent />);
    });

    // Button klicken
    cy.contains('button', 'Delete').click();

  });
});
