import { mount } from 'cypress/react';
import EditMeeting from '../../../src/components/EditMeeting'; // Pfad ggf. anpassen
import React, { useState } from 'react';

describe('EditMeeting Komponente', () => {
  // C.C.EM.1
  it('sollte fetch aufrufen und setMeetings aktualisieren', () => {
    const initialMeeting = {
      meetingId: 1,
      description: 'Test Meeting',
      date: '2025-06-20',
      time: '10:00',
    };

    const setMeetings = cy.stub().as('setMeetingsStub');

    // Stub für fetch
    cy.window().then(win => {
      cy.stub(win, 'fetch').resolves({
        ok: true,
        json: () => Promise.resolve([{ meetingId: 1, description: 'Updated Meeting', date: '2025-06-21', time: '11:00' }]),
      }).as('fetchStub');
    }).then(() => {
      mount(
        <EditMeeting
          meeting={initialMeeting}
          setMeetings={setMeetings}
          projectId={123}
        />
      );
    });

    // Öffne das Modal
    cy.contains('button', 'Edit').click();

    // Ändere die Beschreibung
    cy.get('input[type="text"]').clear().type('Updated Meeting');

    // Ändere das Datum
    cy.get('input[type="date"]').clear().type('2025-06-21');

    // Ändere die Zeit
    cy.get('input[type="time"]').clear().type('11:00');

    // Klicke Save
    cy.contains('button', 'Save').click();

    // fetch wurde mit korrekter URL aufgerufen
    cy.get('@fetchStub').should('have.been.calledWithMatch', /editmeeting\?projectid=123/);

    // setMeetings wurde aufgerufen
    cy.get('@setMeetingsStub').should('have.been.calledWithMatch', (meetings) => {
      return Array.isArray(meetings) && meetings.some(m => m.description === 'Updated Meeting');
    });
  });
});