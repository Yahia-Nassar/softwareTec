import { mount } from 'cypress/react';
import EditSprint from '../../../src/components/EditSprint'; // Pfad ggf. anpassen
import React from 'react';

describe('EditSprint Komponente', () => {
  // C.C.ESP.1
  it('sollte fetch aufrufen und den Sprint aktualisieren', () => {
    const initialSprint = {
      sprintId: 1,
      name: 'Sprint 1',
      startDate: '2025-06-20',
      endDate: '2025-07-01'
    };

    // Stub für fetch
    cy.window().then(win => {
      cy.stub(win, 'fetch').resolves({
        ok: true,
        json: () => Promise.resolve({
          sprintId: 1,
          name: 'Updated Sprint',
          startDate: '2025-06-21',
          endDate: '2025-07-02'
        }),
      }).as('fetchStub');
    }).then(() => {
      mount(
        <EditSprint
          sprint={initialSprint}
          projectId={123}
        />
      );
    });

    // Öffne das Modal
    cy.get('button').click();

    // Name ändern
    cy.get('input[type="text"]').clear().type('Updated Sprint');

    // StartDate ändern
    cy.get('input[type="date"]').first().clear().type('2025-06-21');

    // EndDate ändern
    cy.get('input[type="date"]').last().clear().type('2025-07-02');

    // Save klicken
    cy.contains('button', 'Save').click();

    // fetch wurde aufgerufen
    cy.get('@fetchStub').should('have.been.calledWithMatch', /editSprint\?projectId=123/);
  });
});