import { mount } from 'cypress/react';
import EditUserStory from '../../../src/components/EditUserStory'; 
import { MemoryRouter, Routes, Route } from 'react-router-dom';
import React, { useState } from 'react';

describe('EditUserStory Komponente', () => {
  // C.C.EUS.1
  it('sollte fetch aufrufen und die User Story updaten', () => {
    const initialUserStory = {
      id: 1,
      title: 'Alte User Story',
      description: 'Alte Beschreibung',
      status: 'BACKLOG',
      acceptanceCriteria: 'Alte Kriterien',
      priority: 'LOW'
    };

    let fetchStub;

    cy.window().then((win) => {
      fetchStub = cy.stub(win, 'fetch').callsFake((url, options) => {
        if (url.includes('/getRole')) {
          return Promise.resolve({
            ok: true,
            json: () => Promise.resolve('PRODUCT_OWNER')
          });
        }
        if (url.includes('/editUserStory')) {
          return Promise.resolve({ ok: true });
        }
        return Promise.reject(new Error(`Unexpected fetch URL: ${url}`));
      }).as('fetchStub');
    });

    function Wrapper() {
      const [cards, setCards] = useState([initialUserStory]);
      Cypress.env('getCards', () => cards);
      return (
        <MemoryRouter initialEntries={['/project/123']}>
          <Routes>
            <Route
              path="/project/:projectId"
              element={
                <EditUserStory
                  columnName="BACKLOG"
                  setCards={setCards}
                  setFilteredCards={() => {}} // Dummy-Prop vermeiden Fehler
                  UserStory={initialUserStory}
                />
              }
            />
          </Routes>
        </MemoryRouter>
      );
    }

    cy.then(() => mount(<Wrapper />));

    // Sicherstellen, dass fetch mit getRole aufgerufen wurde
    cy.get('@fetchStub').should('have.been.calledWithMatch', /getRole\?projectid=123/);

    // Editieren starten
    cy.contains('button', 'Edit').click();

    // Felder ändern
    cy.get('input[type="text"]').clear().type('Neue User Story');
    cy.get('textarea').eq(0).clear().type('Neue Beschreibung');
    cy.get('textarea').eq(1).clear().type('Neue Kriterien');
    cy.get('select').eq(0).select('IN_PROGRESS');
    cy.get('select').eq(1).select('HIGH');

    // Absenden
    cy.get('button[type="submit"]').click();

    // Kartenstatus überprüfen
    cy.then(() => {
      const updatedCards = Cypress.env('getCards')();
      expect(updatedCards).to.have.length(1);
      const updated = updatedCards[0];
      expect(updated.title).to.eq('Neue User Story');
      expect(updated.description).to.eq('Neue Beschreibung');
      expect(updated.acceptanceCriteria).to.eq('Neue Kriterien');
      expect(updated.status).to.eq('IN_PROGRESS');
      expect(updated.priority).to.eq('HIGH');
    });
  });
});