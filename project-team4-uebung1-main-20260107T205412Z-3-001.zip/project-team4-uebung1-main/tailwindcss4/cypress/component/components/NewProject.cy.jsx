import { mount } from 'cypress/react';
import NewProject from '../../../src/components/NewProject'; // Pfad anpassen

describe('NewProject Komponente', () => {
  // C.C.NPR.1
  it('sollte onCreate mit dem eingegebenen Projektname aufrufen', () => {
    const onCreate = cy.stub().as('onCreateStub');
    const onCancel = cy.stub().as('onCancelStub');

    mount(
      <NewProject onCreate={onCreate} onCancel={onCancel} />
    );

    // Projektname eingeben
    cy.get('input[type="text"]').type('Mein Neues Projekt');

    // Formular absenden
    cy.get('button[type="submit"]').click();

    // Prüfen, ob onCreate mit dem richtigen Namen aufgerufen wurde
    cy.get('@onCreateStub').should('have.been.calledWith', 'Mein Neues Projekt');
  });

  // C.C.NPR.2
  it('sollte onCancel aufrufen, wenn Abbrechen geklickt wird', () => {
    const onCreate = cy.stub().as('onCreateStub');
    const onCancel = cy.stub().as('onCancelStub');

    mount(
      <NewProject onCreate={onCreate} onCancel={onCancel} />
    );

    // Abbrechen klicken
    cy.contains('button', 'Abbrechen').click();

    // Prüfen, ob onCancel aufgerufen wurde
    cy.get('@onCancelStub').should('have.been.called');
  });

  // C.C.NPR.3
  it('sollte onCreate nicht aufrufen, wenn kein Projektname eingegeben wurde', () => {
    const onCreate = cy.stub().as('onCreateStub');
    const onCancel = cy.stub().as('onCancelStub');

    mount(
      <NewProject onCreate={onCreate} onCancel={onCancel} />
    );

    // Ohne Eingabe submitten
    cy.get('button[type="submit"]').click();

    // onCreate darf nicht aufgerufen werden
    cy.get('@onCreateStub').should('not.have.been.called');
  });
});