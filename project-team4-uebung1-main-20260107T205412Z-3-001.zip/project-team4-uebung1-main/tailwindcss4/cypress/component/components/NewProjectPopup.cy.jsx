import { mount } from 'cypress/react';
import NewProjectPopup from '../../../src/components/NewProjectPopup'; // Pfad ggf. anpassen

describe('NewProjectPopup Komponente', () => {
  // C.C.NPRP.1
  it('sollte onCreate mit dem eingegebenen Projektnamen aufrufen', () => {
    const onCreate = cy.stub().as('onCreateStub');

    mount(<NewProjectPopup onCreate={onCreate} />);

    // Trigger-Button klicken
    cy.contains('+ Add project').click();

    // Eingabe machen
    cy.get('input[type="text"]').type('Mein Projekt');

    // Submit-Button klicken
    cy.contains('button', 'Projekt erstellen').click();

    // Prüfen, ob onCreate aufgerufen wurde
    cy.get('@onCreateStub').should('have.been.calledWith', 'Mein Projekt');
  });

  // C.C.NPRP.2
  it('sollte Popup schließen, wenn Abbrechen geklickt wird', () => {
    const onCreate = cy.stub();

    mount(<NewProjectPopup onCreate={onCreate} />);

    // Trigger-Button klicken
    cy.contains('+ Add project').click();

    // Abbrechen klicken
    cy.contains('button', 'Abbrechen').click();

    // Sicherstellen, dass das Modal nicht mehr sichtbar ist
    cy.get('.popup-overlay').should('not.exist');
  });

  // C.C.NPRP.3
  it('sollte onCreate nicht aufrufen, wenn kein Name eingegeben wurde', () => {
    const onCreate = cy.stub().as('onCreateStub');

    mount(<NewProjectPopup onCreate={onCreate} />);

    // Trigger-Button klicken
    cy.contains('+ Add project').click();

    // Ohne Eingabe Submit versuchen
    cy.contains('button', 'Projekt erstellen').click();

    // onCreate darf nicht aufgerufen werden (weil required im Input ist)
    cy.get('@onCreateStub').should('not.have.been.called');
  });
});
