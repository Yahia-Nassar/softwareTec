import { mount } from 'cypress/react';
import Notification, { notify } from '../../../src/components/Notification'; // Pfad anpassen

describe('Notification Komponente', () => {
  // C.C.N.1
  it('sollte success-Toast anzeigen', () => {
    mount(<Notification />);
    notify.success('Erfolgsmeldung');
    cy.contains('Erfolgsmeldung').should('be.visible');
  });

  // C.C.N.2
  it('sollte error-Toast anzeigen', () => {
    mount(<Notification />);
    notify.error('Fehlermeldung');
    cy.contains('Fehlermeldung').should('be.visible');
  });

  // C.C.N.3
  it('sollte reminder-Toast anzeigen und blau sein', () => {
    mount(<Notification />);
    notify.reminder('Erinnerung');
    cy.contains('Erinnerung')
      .should('be.visible')
      .and('have.css', 'color')
      .then((color) => {
        expect(color).to.eq('rgb(0, 0, 255)'); // direkt RGB prüfen
      });
  });
});
