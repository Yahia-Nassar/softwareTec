import { mount } from 'cypress/react';
import React from 'react';
import PageWrapper from '../../../src/components/PageWrapper'; 

describe('PageWrapper Komponente', () => {
  // C.C.PW.1
  it('rendert mit Kindern', () => {
    mount(
      <PageWrapper>
        <div>Testinhalt</div>
      </PageWrapper>
    );

    cy.contains('Testinhalt').should('be.visible');
  });
});