import { mount } from 'cypress/react';
import React from 'react';
import PopupComponent from '../../../src/components/Popup'; 

describe('Popup Komponente', () => {
  beforeEach(() => {
    cy.window().then(win => {
      cy.stub(win.console, 'log').as('consoleLog');
    });
  });

  it('öffnet Formular und verarbeitet Eingaben', () => {
    mount(<PopupComponent />);
  // C.C.P.1
    cy.contains('Öffne Formular').click();
    cy.get('input[type="text"]').type('Mein Titel');
    cy.get('textarea').type('Meine Beschreibung');
    cy.get('select').select('userStory');
    cy.contains('button', 'Hinzufügen').click();

    cy.get('@consoleLog').should('have.been.calledWithMatch', /Neuer userStory:/, 'Mein Titel', 'Meine Beschreibung');
  });
  // C.C.P.2
  it('schließt Popup beim Klick auf Schließen', () => {
    mount(<PopupComponent />);
    cy.contains('Öffne Formular').click();
    cy.contains('button', 'Schließen').click();
    cy.get('.popup-overlay').should('not.exist');
  });
});