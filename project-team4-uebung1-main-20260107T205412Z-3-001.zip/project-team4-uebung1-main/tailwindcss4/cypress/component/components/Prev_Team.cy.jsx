import { mount } from 'cypress/react';
import React from 'react';
import Prev_Team from '../../../src/components/Prev_Team'; 

describe('AT.1 – Prev_Team-Komponente', () => {
  // C.C.PT.1
  beforeEach(() => {
    mount(<Prev_Team />);
  });

  it('AT.1.1 – fügt ein gültiges Mitglied zur Liste hinzu', () => {
    cy.get('input[placeholder="Name of new Member"]').type('Alice');
    cy.contains('button', 'Add Member').click();
    cy.contains('li', 'Alice').should('exist');
  });

  it('AT.1.2 – verhindert Hinzufügen eines leeren Namens', () => {
    cy.contains('button', 'Add Member').click();
    cy.get('ol li').should('have.length', 0);
  });

  it('AT.1.3 – verhindert Hinzufügen eines zu langen Namens', () => {
    const longName = 'x'.repeat(61);
    cy.get('input[placeholder="Name of new Member"]').type(longName);
    cy.contains('button', 'Add Member').click();
    cy.contains('li', longName).should('not.exist');
  });

  it('AT.1.4 – löscht ein hinzugefügtes Mitglied wieder', () => {
    cy.get('input[placeholder="Name of new Member"]').type('Bob');
    cy.contains('button', 'Add Member').click();
    cy.contains('li', 'Bob').should('exist');
    cy.contains('li', 'Bob').within(() => {
      cy.contains('button', 'Delete Member').click();
    });
    cy.contains('li', 'Bob').should('not.exist');
  });
});
