import { mount } from 'cypress/react';
import React from 'react';
import ProfilView from '../../../src/components/ProfilView';
import { MemoryRouter, Route, Routes } from 'react-router-dom';

describe('C.C.PV – ProfilView Komponente', () => {
  const mountWithRouter = (projectId = '123') => {
    mount(
      <MemoryRouter initialEntries={[`/project/${projectId}`]}>
        <Routes>
          <Route path="/project/:projectId" element={<ProfilView />} />
        </Routes>
      </MemoryRouter>
    );
  };

  beforeEach(() => {
    cy.intercept('GET', 'http://localhost:8080/getUsername', {
      statusCode: 200,
      body: 'Max Mustermann',
    }).as('getUsername');

    cy.intercept('GET', 'http://localhost:8080/getUserEmail', {
      statusCode: 200,
      body: 'max@beispiel.de',
    }).as('getEmail');

    cy.intercept('GET', 'http://localhost:8080/gettasknotification?projectid=123', {
      statusCode: 200,
      body: 1,
    }).as('getTaskNotif');

    cy.intercept('GET', 'http://localhost:8080/getmeetingnotification?projectid=123', {
      statusCode: 200,
      body: 60,
    }).as('getMeetingNotif');

    cy.intercept('GET', 'http://localhost:8080/getRole?projectid=123', {
      statusCode: 200,
      body: 'PRODUCT_OWNER',
    }).as('getRole');
  });

  // C.C.PV.1
  it('zeigt initial die Benutzerdaten und Benachrichtigungen korrekt an', () => {
    mountWithRouter();

    cy.wait('@getUsername');
    cy.wait('@getEmail');
    cy.wait('@getTaskNotif');
    cy.wait('@getMeetingNotif');
    cy.wait('@getRole');

    // Name steht im <h2>
    cy.get('h2').should('contain.text', 'Max Mustermann');

    // Die beiden <p> unterhalb zeigen E-Mail und Rolle
    cy.get('p').eq(0).should('contain.text', 'max@beispiel.de');
    cy.get('p').eq(1).should(($p) => {
  expect(['PRODUCT_OWNER', 'DEVELOPER']).to.include($p.text());
});

    // Die beiden weiteren <p> zeigen Benachrichtigungen
    cy.get('p').eq(2).should('contain.text', '1 hour');
    cy.get('p').eq(3).should('contain.text', '1 day');
  });

  // C.C.PV.2
  it('wechselt in den Editiermodus und speichert Änderungen', () => {
    mountWithRouter();

    cy.wait('@getUsername');
    cy.wait('@getEmail');
    cy.wait('@getTaskNotif');
    cy.wait('@getMeetingNotif');
    cy.wait('@getRole');

    cy.get('button').last().click();

    cy.get('select').eq(0).select('DEVELOPER');
    cy.get('select').eq(1).select('3 hours');
    cy.get('select').eq(2).select('2 days');
    cy.get('div[title="#ff4d4d"]').click();

    cy.intercept('POST', 'http://localhost:8080/editrole?projectid=123', { statusCode: 200 }).as('saveRole');
    cy.intercept('POST', 'http://localhost:8080/editmeetingnotification?projectid=123', { statusCode: 200 }).as('saveMeeting');
    cy.intercept('POST', 'http://localhost:8080/edittasknotification?projectid=123', { statusCode: 200 }).as('saveTask');

    cy.contains('button', 'Save').click();

    cy.wait('@saveRole');
    cy.wait('@saveMeeting');
    cy.wait('@saveTask');

    // Neue Werte prüfen
    cy.get('p').eq(1).should('contain.text', 'DEVELOPER');
    cy.get('p').eq(2).should('contain.text', '3 hours');
    cy.get('p').eq(3).should('contain.text', '2 days');
  });

  // C.C.PV.3
  it('zeigt Fehlermeldung bei Fehler im Laden der Benutzerdaten', () => {
    cy.intercept('GET', 'http://localhost:8080/getUsername', {
      statusCode: 500,
    }).as('getUsernameFail');

    mountWithRouter();

    cy.wait('@getUsernameFail');
    cy.contains('Error fetching name').should('exist');
  });
});
