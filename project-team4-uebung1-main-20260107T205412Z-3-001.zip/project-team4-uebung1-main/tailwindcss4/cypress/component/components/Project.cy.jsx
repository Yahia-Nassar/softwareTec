import { mount } from 'cypress/react';
import React from 'react';
import Project from '../../../src/components/Project'; // Pfad anpassen

describe('Project Komponente', () => {
  // C.C.PR.1
  it('zeigt den Projektnamen an und reagiert auf Klick', () => {
    const project = { name: 'Mein Projekt' };
    const onClick = cy.stub().as('onClickStub');

    mount(<Project project={project} onClick={onClick} />);

    // Prüfe, ob der Projektname angezeigt wird
    cy.contains('Mein Projekt').should('exist');

    // Klick auf das Rechteck
    cy.get('.project-rectangle').click();

    // Prüfe, ob der Klick-Handler aufgerufen wurde
    cy.get('@onClickStub').should('have.been.calledOnce');
  });
});
