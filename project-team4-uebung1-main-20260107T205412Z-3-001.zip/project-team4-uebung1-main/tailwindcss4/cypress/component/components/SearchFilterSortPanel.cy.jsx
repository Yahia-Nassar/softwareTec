import { mount } from 'cypress/react';
import SearchFilterSortPanel from '../../../src/components/SearchFilterSortPanel';
import React from 'react';

describe('C.C.SFSP – SearchFilterSortPanel Komponente', () => {
  const dummyItems = [
    { title: 'Login', status: 'open', priority: 'high', userInfos: [{ name: 'Alice' }] },
    { title: 'Register', status: 'closed', priority: 'low', userInfos: [{ name: 'Bob' }] },
  ];

  const fields = [
    { name: 'status', type: 'select', options: ['open', 'closed'] },
    { name: 'priority', type: 'select', options: ['high', 'low'] },
    { name: 'assignedUsers', type: 'text', label: 'Assigned User' },
  ];

  it('filtert korrekt nach Text', () => {
    const filteredSpy = cy.spy().as('filteredSpy');

    mount(
      <SearchFilterSortPanel
        fields={fields}
        getItems={() => dummyItems}
        onFilteredItems={filteredSpy}
      />
    );

    cy.get('input[placeholder="Search..."]').type('Login');

    cy.get('@filteredSpy').should((spy) => {
      const calls = spy
        .getCalls()
        .map((c) => c.args[0])
        .filter((items) => Array.isArray(items) && items.some(i => i.title === 'Login'));
      expect(calls.length).to.be.greaterThan(0);
    });
  });

  it('filtert korrekt nach Status = closed', () => {
    const filteredSpy = cy.spy().as('filteredSpy');

    mount(
      <SearchFilterSortPanel
        fields={fields}
        getItems={() => dummyItems}
        onFilteredItems={filteredSpy}
      />
    );

    cy.get('select').eq(0).select('closed');

    cy.get('@filteredSpy').should((spy) => {
      const calls = spy
        .getCalls()
        .map((c) => c.args[0])
        .filter((items) => Array.isArray(items) && items.some(i => i.status === 'closed'));
      expect(calls.length).to.be.greaterThan(0);
    });
  });
});
