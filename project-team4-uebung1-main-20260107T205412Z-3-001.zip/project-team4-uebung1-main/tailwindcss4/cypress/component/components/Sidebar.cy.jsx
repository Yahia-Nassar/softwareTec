import React from "react";
import { mount } from "cypress/react";
import Sidebar from "../../../src/components/Sidebar";
import { MemoryRouter, Routes, Route } from "react-router-dom";

// Wrapper zur Simulation von Routing
const Wrapper = ({ children }) => (
  <MemoryRouter initialEntries={["/123/dashboard"]}>
    <Routes>
      <Route path="/:projectId/*" element={children} />
    </Routes>
  </MemoryRouter>
);

describe("Sidebar", () => {
  // C.C.SB.1
  it("rendert Menüeinträge korrekt", () => {
    mount(
      <Wrapper>
        <Sidebar />
      </Wrapper>
    );

    // Buttons sicher über get() finden
    cy.get("button").contains("Dashboard").should("exist");
    cy.get("button").contains("Projectbacklog").should("exist");
    cy.get("button").contains("Logout").should("exist");
  });
  // C.C.SB.2
  it("reagiert auf Klick und wechselt Route (simuliert)", () => {
    mount(
      <Wrapper>
        <Sidebar />
      </Wrapper>
    );

    // Klick auf Projectbacklog
    cy.get("button").contains("Projectbacklog").click();

    cy.get("button.bg").contains("Projectbacklog").should("exist");
  });
  // C.C.SB.3
  it("führt Logout aus und ruft API auf", () => {
    cy.intercept("GET", "http://localhost:8080/logout", {
      statusCode: 200,
    }).as("logout");

    mount(
      <Wrapper>
        <Sidebar />
      </Wrapper>
    );

    cy.get("button").contains("Logout").click();
    cy.wait("@logout");
  });
});