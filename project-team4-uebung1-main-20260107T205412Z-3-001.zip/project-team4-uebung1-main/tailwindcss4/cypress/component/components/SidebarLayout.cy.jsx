import { mount } from 'cypress/react';
import React from 'react';
import { MemoryRouter } from 'react-router-dom';
import SidebarLayout from '../../../src/components/SidebarLayout';

// Dummy Child-Komponente, um Prop sidebarOpen zu prüfen
const DummyChild = ({ sidebarOpen }) => (
  <div data-testid="dummy-child">{sidebarOpen ? 'Sidebar ist offen' : 'Sidebar ist geschlossen'}</div>
);

describe('SidebarLayout Komponente', () => {
  // C.C.SBL.1
  it('rendert Sidebar und gibt sidebarOpen an Kind weiter', () => {
    mount(
      <MemoryRouter>
        <SidebarLayout>
          <DummyChild />
        </SidebarLayout>
      </MemoryRouter>
    );

    // Prüfe, ob DummyChild mit sidebarOpen Prop gerendert wird
    cy.get('[data-testid="dummy-child"]').should('contain.text', 'Sidebar ist offen');
  });
});
