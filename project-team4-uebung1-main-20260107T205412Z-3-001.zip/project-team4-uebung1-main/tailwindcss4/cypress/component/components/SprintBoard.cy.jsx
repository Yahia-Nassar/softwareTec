import React from 'react';
import { mount } from 'cypress/react';
import { MemoryRouter, Routes, Route } from 'react-router-dom';
import SprintBoard from '../../../src/components/SprintBoard';

Cypress.on('uncaught:exception', () => false);

describe('SprintBoard Komponente', () => {
  beforeEach(() => {
    cy.intercept('GET', '**/getRole?*', { statusCode: 200, body: 'Admin' }).as('getRole');
    cy.intercept('GET', '**/getsprints?*', {
      statusCode: 200,
      body: [
        { sprintid: 1, name: 'Unsorted' },
        { sprintid: 2, name: 'Sprint 1' }
      ]
    }).as('getSprints');
    cy.intercept('GET', '**/getuserstories?*', {
      statusCode: 200,
      body: [
        { id: 1, title: 'Story 1', description: 'Desc', sprint: 1 }
      ]
    }).as('getUserStories');
    cy.intercept('POST', '**/saveUSCards?*', { statusCode: 200, body: {} }).as('saveUSCards');
    cy.intercept('POST', '**/createSprint?*', { statusCode: 200, body: { sprintid: 3, name: 'Sprint 3' } }).as('createSprint');
    cy.intercept('POST', '**/deleteSprint?*', { statusCode: 200, body: {} }).as('deleteSprint');

    mount(
      <MemoryRouter initialEntries={['/1']}>
        <Routes>
          <Route path="/:projectId" element={<SprintBoard sidebarOpen={true} />} />
        </Routes>
      </MemoryRouter>
    );
  });

  // C.C.SPBD.1
  it('mountet und macht Requests', () => {
    cy.wait('@getRole');
    cy.wait('@getSprints');
    cy.wait('@getUserStories');
    cy.get('body').should('exist');
    cy.contains('Save').should('exist');
  });

  // C.C.SPBD.2
  it('führt Save aus', () => {
    cy.contains('Save').click();
    cy.wait('@saveUSCards').its('response.statusCode').should('eq', 200);
  });

  // C.C.SPBD.3
  it('versucht einen Sprint hinzuzufügen (optional)', () => {
    cy.get('button').then(buttons => {
      const addBtn = [...buttons].find(b => /add|sprint/i.test(b.innerText));
      if (addBtn) {
        cy.intercept('POST', '**/createSprint?*').as('realCreateSprint');
        cy.wrap(addBtn).click({ force: true });
        
        cy.wait(500); // kurz warten ob Request kommt
        cy.get('@realCreateSprint.all').then(calls => {
          if (calls.length > 0) {
            cy.wait('@realCreateSprint').its('response.statusCode').should('eq', 200);
          } else {
            cy.log('Klick hat keinen Sprint-Request ausgelöst');
          }
        });
      } else {
        cy.log('Kein AddSprint-Button sichtbar, Test übersprungen');
      }
    });
  });

  // C.C.SPBD.4
  it('versucht einen Sprint zu löschen (optional)', () => {
    cy.get('button').then(buttons => {
      const delBtn = [...buttons].find(b => /delete/i.test(b.innerText));
      if (delBtn) {
        cy.intercept('POST', '**/deleteSprint?*').as('realDeleteSprint');
        cy.wrap(delBtn).click({ force: true });
        
        cy.wait(500); // kurz warten ob Request kommt
        cy.get('@realDeleteSprint.all').then(calls => {
          if (calls.length > 0) {
            cy.wait('@realDeleteSprint').its('response.statusCode').should('eq', 200);
          } else {
            cy.log('Klick hat keinen Delete-Request ausgelöst');
          }
        });
      } else {
        cy.log('Kein Delete-Button sichtbar, Test übersprungen');
      }
    });
  });
});
