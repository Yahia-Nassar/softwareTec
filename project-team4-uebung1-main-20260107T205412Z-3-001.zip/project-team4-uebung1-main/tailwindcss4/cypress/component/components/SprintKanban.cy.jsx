import React from 'react';
import { mount } from 'cypress/react';
import { MemoryRouter, Routes, Route } from 'react-router-dom';
import SprintKanban from '../../../src/components/SprintKanban';

Cypress.on('uncaught:exception', () => false); // Unterdrückt React-Warnungen

describe('SprintKanban Komponente – Sichtbarkeits- und Daten-Tests', () => {
  beforeEach(() => {
    //  Rolle setzen (wichtig für Berechtigungen/UI-Sichtbarkeit)
    cy.intercept('GET', '**/getRole?*', {
      statusCode: 200,
      body: 'Scrum Master'
    }).as('getRole');

    //  Sprintliste mocken
    cy.intercept('GET', '**/getsprints?*', {
      statusCode: 200,
      body: [
        { sprintid: 1, name: 'Unsorted' },
        { sprintid: 2, name: 'Sprint 1' }
      ]
    }).as('getSprints');

    //  Tasks mocken
    cy.intercept('GET', '**/getsprinttasks?*', {
      statusCode: 200,
      body: [
        { id: 1, title: 'Task 1', description: 'Desc 1', status: 'BACKLOG' }
      ]
    }).as('getTasks');

    //  User Stories mocken
    cy.intercept('GET', '**/getsprintUS?*', {
      statusCode: 200,
      body: [
        {
          id: 10,
          title: 'User Story 1',
          description: 'Desc US 1',
          sprint: { sprintid: 1 }
        }
      ]
    }).as('getUS');

    //  Komponente mounten mit MemoryRouter für `:projectId`
    mount(
      <MemoryRouter initialEntries={['/1']}>
        <Routes>
          <Route path="/:projectId" element={<SprintKanban sidebarOpen={true} />} />
        </Routes>
      </MemoryRouter>
    );

    // Auf Daten warten
    cy.wait('@getRole');
    cy.wait('@getSprints');
    cy.wait('@getTasks');
    cy.wait('@getUS');
  });

  //  C.C.SPK.1
  it('zeigt mindestens eine Task-Karte an (z.B. Task 1)', () => {
    cy.contains('Task 1', { timeout: 5000 }).should('exist');
  });

  

  //  C.C.SPK.2
  it('zeigt eine Sprint-Auswahl mit mindestens einem Eintrag', () => {
    cy.get('select').first().find('option').should('have.length.at.least', 1);
  });

  //  C.C.SPK.3
  it('zeigt alle DOM-Texte', () => {
    cy.get('body').then(($body) => {
      const fullText = $body.text();
      cy.log('DOM-Inhalt:', fullText);
    });
  });
});