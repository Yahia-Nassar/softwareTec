import React from 'react';
import { mount } from 'cypress/react';
import { TaskDetails } from '../../../src/components/TaskDetails'; // Richtiger Import

Cypress.on('uncaught:exception', () => false);

describe('TaskDetails Komponente', () => {
  const mockTask = {
    id: 1,
    title: 'Test Task',
    description: 'Test Beschreibung',
    priority: 'MEDIUM',
    status: 'BACKLOG',
    estTime: 5,
    actTime: 0,
    userInfos: [{ id: 1, name: 'User1' }],
    comments: [],
    userStory: { id: '10', title: 'User Story 1' },
    frontendID: 'task-1',
    createdAt: '2024-06-20T00:00:00.000Z'
  };

  const mockCards = [
    { id: '10', title: 'User Story 1', type: 'userStory' },
    { id: '11', title: 'User Story 2', type: 'userStory' }
  ];

  beforeEach(() => {
    mount(
      <TaskDetails
        task={mockTask}
        cards={mockCards}
        onClose={cy.stub().as('onClose')}
        onSave={cy.stub().as('onSave')}
      />
    );
  });

  // C.C.TD.1
  it('zeigt Title und Description', () => {
    cy.get('input[type="text"]').should('have.value', mockTask.title);
    cy.get('textarea').should('have.value', mockTask.description);
  });

  // C.C.TD.2
  it('ändert Title und speichert', () => {
    cy.get('input[type="text"]').clear().type('Updated Task Title');
    cy.contains('Save').click();
    cy.get('@onSave').should('have.been.called');
  });

  // C.C.TD.3
  it('klickt Cancel', () => {
    cy.contains('Cancel').click();
    cy.get('@onClose').should('have.been.called');
  });

  // C.C.TD.4
  it('zeigt User Stories im Dropdown', () => {
    cy.get('select').contains('User Story 1').should('exist');
    cy.get('select').contains('User Story 2').should('exist');
  });
});
