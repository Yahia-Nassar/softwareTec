import React from 'react';
import { mount } from 'cypress/react';
import TaskReminder from '../../../src/components/TaskReminder';

Cypress.on('uncaught:exception', () => false);

describe('TaskReminder Komponente', () => {
  beforeEach(() => {
    cy.window().then(win => {
      win.localStorage.clear();
    });
  });

  // C.C.TR.1
  it('mountet ohne Fehler', () => {
    const mockCards = [
      {
        id: 1,
        title: 'Test Task',
        type: 'task',
        createdAt: new Date().toISOString(),
        estTime: 1,
        status: 'BACKLOG'
      }
    ];

    mount(<TaskReminder cards={mockCards} />);
    
    cy.wait(100);
  });
});
