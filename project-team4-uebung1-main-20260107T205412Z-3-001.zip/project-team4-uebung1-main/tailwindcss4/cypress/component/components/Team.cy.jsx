import React from 'react';
import { mount } from 'cypress/react';
import { MemoryRouter, Route, Routes } from 'react-router-dom';
import Team from '../../../src/components/Team';

const mountWithRouter = (projectId = '123') => {
  mount(
    <MemoryRouter initialEntries={[`/project/${projectId}/team`]}>
      <Routes>
        <Route path="/project/:projectId/team" element={<Team />} />
      </Routes>
    </MemoryRouter>
  );
};

describe('Team Komponente', () => {
  beforeEach(() => {
    // Nur notwendige API-Mocks zum stabilen Laden (kann bei echtem Backend weggelassen werden)
    cy.intercept('GET', '**/getusersinproject*', {
      statusCode: 200,
      body: [{ id: 1, username: 'JohnDoe', email: 'john@example.com' }],
    });

    cy.intercept('GET', '**/req/login', {
      statusCode: 200,
      body: {},
    });
  });

  // C.C.TM.1
  it('mountet ohne Fehler', () => {
    mountWithRouter();
    cy.contains('Add Team Member').should('exist');
  });

  // C.C.TM.2
  it('öffnet das Modal und fügt einen Member hinzu', () => {
    mountWithRouter();

    cy.contains('Add Team Member').click();
    cy.get('#username-input').should('be.visible').type('Alice');

    cy.get('div[style*="position: fixed"]')
      .contains('Add')
      .should('be.visible')
      .click();

  });

  // C.C.TM.3
  it('öffnet das Modal und bricht ab', () => {
    mountWithRouter();

    cy.contains('Add Team Member').click();
    cy.get('#username-input').should('be.visible').type('Bob');

    cy.get('div[style*="position: fixed"]')
      .contains('Cancel')
      .should('be.visible')
      .click();

    cy.get('#username-input').should('not.exist');
  });
});