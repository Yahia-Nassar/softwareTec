import React from 'react';
import { mount } from 'cypress/react';
import ToDoList from '../../../src/components/ToDoList';

describe('ToDoList Komponente', () => {
  beforeEach(() => {
    cy.intercept('GET', '**/getusertasks?*', {
      statusCode: 200,
      body: [
        { id: 1, title: 'Task 1', status: 'BACKLOG' },
        { id: 2, title: 'Task 2', status: 'COMPLETED' },
        { id: 3, title: 'Task 3', status: 'IN_PROGRESS' }
      ]
    }).as('getTasks');
  });

  // C.C.TDL.1
  it('zeigt nur nicht-abgeschlossene Tasks', () => {
    mount(<ToDoList projectId={1} />);
    cy.wait('@getTasks');

    cy.contains('Task 1').should('exist');
    cy.contains('Task 3').should('exist');
    cy.contains('Task 2').should('not.exist');
  });

  // C.C.TDL.2
  it('zeigt Fehler bei fehlgeschlagenem Fetch', () => {
    cy.intercept('GET', '**/getusertasks?*', {
      statusCode: 500
    }).as('getTasksError');

    mount(<ToDoList projectId={1} />);
    cy.wait('@getTasksError');

    cy.contains('Fehler').should('exist');
  });
});
