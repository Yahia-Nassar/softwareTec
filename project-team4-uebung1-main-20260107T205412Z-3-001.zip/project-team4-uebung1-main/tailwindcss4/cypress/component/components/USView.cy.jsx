import React from 'react';
import { mount } from 'cypress/react';
import { MemoryRouter, Routes, Route } from 'react-router-dom';
import USView from '../../../src/components/USView';

// Mocks für Unterkomponenten
import '../../../src/components/UserStoryKanban'; // wenn nötig mockbar halten

describe('USView Komponente', () => {
  const mountWithRouter = () => {
    mount(
      <MemoryRouter initialEntries={['/project/123']}>
        <Routes>
          <Route path="/project/:projectId" element={<USView />} />
        </Routes>
      </MemoryRouter>
    );
  };

  // C.C.USV.1
  it('zeigt initial das Backlog', () => {
    mountWithRouter();

    // Wir erwarten hier Inhalte aus <Backlog />
    // Wenn du keine Texte weißt, prüfe z. B. auf die Umschalt-Schaltfläche
    cy.contains(/kanban/i).should('exist'); // z. B. Button "Kanban View"
  });

  // C.C.USV.2
  it('schaltet auf Kanban-Ansicht um', () => {
    mountWithRouter();

    // Klick auf Umschaltfläche (z. B. Button „Kanban View“)
    cy.get('button').contains(/kanban/i).click();

    // Danach erwarten wir Inhalte aus <UserStoryKanban />
    cy.contains('Save').should('exist'); // z. B. „Save“-Button im Kanban
  });
});
