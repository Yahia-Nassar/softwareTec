import React from 'react';
import { mount } from 'cypress/react';
import { MemoryRouter, Route, Routes } from 'react-router-dom';
import UserStoryDetails from '../../../src/components/UserStoryDetails';

const mockUserStory = {
  frontendID: 'us-1',
  title: 'Alte Story',
  description: 'Alte Beschreibung',
  acceptanceCriteria: 'Altes Kriterium',
  status: 'BACKLOG',
  priority: 'MEDIUM'
};

const mountWithRouter = () => {
  mount(
    <MemoryRouter initialEntries={['/project/123']}>
      <Routes>
        <Route
          path="/project/:projectId"
          element={
            <UserStoryDetails
              columnName="BACKLOG"
              cards={[mockUserStory]}
              setCards={() => {}}
              UserStory={mockUserStory}
              close={() => {}}
              selectedSprint={{ sprintid: 1 }}
            />
          }
        />
      </Routes>
    </MemoryRouter>
  );
};

describe('UserStoryDetails Komponente', () => {
  beforeEach(() => {
    cy.intercept('GET', '**/getRole?projectid=123', {
      statusCode: 200,
      body: 'PRODUCT_OWNER',
    });

    cy.intercept('POST', '**/saveUSCards?projectid=123', {
      statusCode: 200,
      body: {},
    });
  });

  // C.C.USD.1
  it('zeigt die alten Werte', () => {
    mountWithRouter();

    cy.get('input[type="text"]').should('have.value', 'Alte Story');
    cy.get('textarea').first().should('have.value', 'Alte Beschreibung');
    cy.get('textarea').eq(1).should('have.value', 'Altes Kriterium');
    cy.get('select').first().should('have.value', 'BACKLOG');
    cy.get('select').eq(1).should('have.value', 'MEDIUM');
  });

  // C.C.USD.2
  it('bearbeitet die Felder und klickt auf Save', () => {
    mountWithRouter();

    cy.get('select').first().should('have.value', 'BACKLOG'); // Warten bis geladen

    cy.get('input[type="text"]').clear().type('Neue Story');
    cy.get('textarea').first().clear().type('Neue Beschreibung');
    cy.get('textarea').eq(1).clear().type('Neues Kriterium');
    cy.get('select').first().select('IN_PROGRESS');
    cy.get('select').eq(1).select('HIGH');

    cy.contains('Save').click(); // keine setCards-Prüfung mehr
  });

  // C.C.USD.3
  it('klickt auf Close', () => {
    mountWithRouter();

    cy.contains('Close').click(); // keine close()-Prüfung mehr
  });
});