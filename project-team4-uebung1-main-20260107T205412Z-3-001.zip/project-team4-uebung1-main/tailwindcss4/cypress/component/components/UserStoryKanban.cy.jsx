import React from 'react';
import { mount } from 'cypress/react';
import { MemoryRouter, Routes, Route } from 'react-router-dom';
import UserStoryKanban from '../../../src/components/UserStoryKanban';

const mountWithRouter = () => {
  cy.intercept('GET', '**/getRole?*', {
    statusCode: 200,
    body: 'PRODUCT_OWNER'
  });

  cy.intercept('GET', '**/getuserstories?*', {
    statusCode: 200,
    body: [
      { id: 1, title: 'Story 1', status: 'BACKLOG' },
      { id: 2, title: 'Story 2', status: 'IN_PROGRESS' },
      { id: 3, title: 'Story 3', status: 'COMPLETED' }
    ]
  });

  cy.intercept('GET', '**/getsprints?*', {
    statusCode: 200,
    body: [
      { sprintid: 1, sprintname: 'Sprint 1' },
      { sprintid: 2, sprintname: 'Sprint 2' }
    ]
  });

  cy.intercept('POST', '**/saveUSCards?*', {
    statusCode: 200,
    body: { success: true }
  });

  mount(
    <MemoryRouter initialEntries={['/project/123']}>
      <Routes>
        <Route path="/project/:projectId" element={<UserStoryKanban sidebarOpen={true} isKanbanView={true} />} />
      </Routes>
    </MemoryRouter>
  );
};

describe('UserStoryKanban Komponente', () => {
  // C.C.USK.1
  it('zeigt User Stories in den Spalten', () => {
    mountWithRouter();

    cy.contains('Story 1').should('exist');
    cy.contains('Story 2').should('exist');
    cy.contains('Story 3').should('exist');
  });

  // C.C.USK.2
  it('klickt auf Save', () => {
    mountWithRouter();

    cy.contains('Save').click(); // pruft nur Klickbarkeit
  });
});