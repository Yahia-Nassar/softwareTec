import React from 'react';
import { mount } from 'cypress/react';
import ViewSwitch from '../../../src/components/ViewSwitch';

describe('ViewSwitch Komponente', () => {
  // C.C.VS.1
  it('zeigt "Switch to Kanban", wenn isKanbanView false ist', () => {
    mount(<ViewSwitch isKanbanView={false} onSwitch={() => {}} />);
    cy.contains('Switch to Kanban').should('exist');
  });

  // C.C.VS.2
  it('zeigt "Switch to Backlog", wenn isKanbanView true ist', () => {
    mount(<ViewSwitch isKanbanView={true} onSwitch={() => {}} />);
    cy.contains('Switch to Backlog').should('exist');
  });

  // C.C.VS.3
  it('ruft onSwitch bei Klick auf', () => {
    const onSwitch = cy.stub().as('onSwitch');
    mount(<ViewSwitch isKanbanView={false} onSwitch={onSwitch} />);

    cy.contains('Switch to Kanban').click();
    cy.get('@onSwitch').should('have.been.calledOnce');
  });
});
