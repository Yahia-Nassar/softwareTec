import React from 'react';
import { mount } from 'cypress/react';
import { MemoryRouter, Routes, Route } from 'react-router-dom';
import BacklogPage from '../../../src/pages/BacklogPage';

describe('BacklogPage Komponententest', () => {
  // C.P.BP.1
  it('zeigt Ladeanzeige', () => {
    cy.intercept('GET', 'http://localhost:8080/auth/status*', {
      statusCode: 200,
      body: { isAuthenticated: null },
    });

    mount(
      <MemoryRouter initialEntries={['/project/123/backlog']}>
        <Routes>
          <Route path="/project/:projectId/backlog" element={<BacklogPage />} />
        </Routes>
      </MemoryRouter>
    );

    cy.contains('Lade Authentifizierungsstatus...').should('exist');
  });

  // C.P.BP.2
  it('rendert Backlog-Komponente wenn authentifiziert', () => {
    cy.intercept('GET', 'http://localhost:8080/auth/status*', {
      statusCode: 200,
      body: { isAuthenticated: true },
    });

    mount(
      <MemoryRouter initialEntries={['/project/123/backlog']}>
        <Routes>
          <Route path="/project/:projectId/backlog" element={<BacklogPage />} />
        </Routes>
      </MemoryRouter>
    );

    cy.get('.Inhalt').should('exist');
  });

  // C.P.BP.3
  it('zeigt keinen Backlog-Inhalt wenn nicht authentifiziert', () => {
    cy.intercept('GET', 'http://localhost:8080/auth/status*', {
      statusCode: 200,
      body: { isAuthenticated: false },
    });

    mount(
      <MemoryRouter initialEntries={['/project/123/backlog']}>
        <Routes>
          <Route path="/project/:projectId/backlog" element={<BacklogPage />} />
        </Routes>
      </MemoryRouter>
    );

    // Da Redirect per window.location.href passiert, können wir hier nur prüfen, dass kein Inhalt gerendert wird
    cy.get('.Inhalt').should('not.exist');
  });
});
