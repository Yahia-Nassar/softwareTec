import React from 'react';
import { mount } from 'cypress/react';
import { MemoryRouter, Routes, Route } from 'react-router-dom';
import DashboardPage from '../../../src/pages/DashboardPage';

describe('DashboardPage Komponententest', () => {

  beforeEach(() => {
    // API für Auth-Status mocken
    cy.intercept('GET', /\/auth\/status\?projectid=.*/, (req) => {
      // default Antwort, kann pro Test überschrieben werden
      req.reply({ isAuthenticated: null });
    }).as('authStatus');
    // API für Meetings mocken
    cy.intercept('GET', /\/getmeetings\?projectid=.*/, {
      statusCode: 200,
      body: [],
    }).as('meetings');
  });

  // C.P.DP.1
  it('zeigt Ladeanzeige', () => {
    mount(
      <MemoryRouter initialEntries={['/project/1']}>
        <Routes>
          <Route path="/project/:projectId" element={<DashboardPage />} />
        </Routes>
      </MemoryRouter>
    );

    cy.contains('Lade Authentifizierungsstatus...').should('exist');
  });

  // C.P.DP.2
  it('rendert Dashboard wenn authentifiziert', () => {
    cy.intercept('GET', /\/auth\/status\?projectid=.*/, {
      statusCode: 200,
      body: { isAuthenticated: true },
    }).as('authTrue');

    mount(
      <MemoryRouter initialEntries={['/project/1']}>
        <Routes>
          <Route path="/project/:projectId" element={<DashboardPage />} />
        </Routes>
      </MemoryRouter>
    );

    // Prüfen, ob ToDoList gerendert wird
    cy.get('.p-4').should('exist');
    // Prüfen, ob BasicDateCalendar gerendert wird (flex-Box)
    cy.get('div').should('contain', ''); // ggf. anpassen je nach Inhalten von BasicDateCalendar
  });

  // C.P.DP.3
  it('zeigt Fehler an wenn Fehler gesetzt', () => {
    cy.intercept('GET', /\/auth\/status\?projectid=.*/, (req) => {
      req.reply(500);
    }).as('authError');

    mount(
      <MemoryRouter initialEntries={['/project/1']}>
        <Routes>
          <Route path="/project/:projectId" element={<DashboardPage />} />
        </Routes>
      </MemoryRouter>
    );

    // Fehleranzeige prüfen
    cy.contains('Fehler beim Abrufen des Authentifizierungsstatus').should('exist');
  });

  // C.P.DP.4
  it('leitet weiter zur Login-Seite wenn nicht authentifiziert', () => {
    cy.intercept('GET', /\/auth\/status\?projectid=.*/, {
      statusCode: 200,
      body: { isAuthenticated: false },
    }).as('authFalse');

    // Statt window.location.href zu stubben, prüfen wir, dass kein Dashboard gerendert wird
    mount(
      <MemoryRouter initialEntries={['/project/1']}>
        <Routes>
          <Route path="/project/:projectId" element={<DashboardPage />} />
        </Routes>
      </MemoryRouter>
    );

    cy.get('.p-4').should('not.exist');
  });

});
