import React from 'react';
import { mount } from 'cypress/react';
import { MemoryRouter, Route, Routes } from 'react-router-dom';
import MeetingPage from '../../../src/pages/MeetingPage';

describe('MeetingPage Komponententest', () => {
  const projectId = '123';

  const mountWithRouter = () => {
    cy.intercept('GET', `http://localhost:8080/auth/status?projectid=${projectId}`, {
      statusCode: 200,
      body: { isAuthenticated: true },
    });

    cy.intercept('GET', `http://localhost:8080/getmeetings?projectid=${projectId}`, {
      statusCode: 200,
      body: [
        { meetingId: 1, description: 'Meeting 1', date: '2025-06-20', time: '15:00' },
        { meetingId: 2, description: 'Meeting 2', date: '2025-06-21', time: '16:00' },
      ],
    });

    cy.intercept('GET', `http://localhost:8080/getprojectusers?projectid=${projectId}`, {
      statusCode: 200,
      body: [
        { username: 'Alice', email: 'alice@example.com' },
        { username: 'Bob', email: 'bob@example.com' },
      ],
    });

    cy.intercept('POST', `http://localhost:8080/createmeeting?projectid=${projectId}`, {
      statusCode: 200,
      body: [
        { meetingId: 99, description: 'Daily Standup', date: '2025-07-10', time: '10:00' },
      ],
    });

    mount(
      <MemoryRouter initialEntries={[`/project/${projectId}`]}>
        <Routes>
          <Route path="/project/:projectId" element={<MeetingPage />} />
        </Routes>
      </MemoryRouter>
    );
  };

  // C.C.MP.1
  it('zeigt Meetingliste, wenn authentifiziert', () => {
    mountWithRouter();
    cy.contains('MeetingID: 1').should('exist');
    cy.contains('MeetingID: 2').should('exist');
  });

  // C.C.MP.2
  it('öffnet das Modal und fügt ein Meeting hinzu', () => {
    mountWithRouter();

    cy.contains('Add Meeting').click();
    cy.get('input[placeholder="Description"]').type('Planung');
    cy.get('input[type="date"]').type('2025-07-01');
    cy.get('input[type="time"]').type('14:00');
    cy.get('select').select(['__all__']);
    cy.contains('Add').click();
  });

  // C.C.MP.3
  it('bricht das Hinzufügen eines Meetings ab', () => {
    mountWithRouter();

    cy.contains('Add Meeting').click();
    cy.get('input[placeholder="Description"]').type('Wird abgebrochen');
    cy.contains('Cancel').click();
  });

  // C.C.MP.4
  it('klickt auf Save-Button', () => {
    mountWithRouter();

    cy.contains('Add Meeting').click();
    cy.get('input[placeholder="Description"]').type('Daily Standup');
    cy.get('input[type="date"]').type('2025-07-10');
    cy.get('input[type="time"]').type('10:00');
    cy.contains('Add').click();

    cy.contains('Save').click();
  });
});