import React from 'react';
import ProfilView from '../../../src/pages/ProfilView';
import { mount } from 'cypress/react';

describe('ProfilView Komponententest', () => {
  beforeEach(() => {
    // Mock API-Response für den Nutzer
    cy.intercept('GET', 'http://localhost:8080/nutzer', {
      statusCode: 200,
      body: {
        vorname: 'Max',
        beschreibung: 'Neue Beschreibung',
        rolle: 'Benutzer',
        email: 'max@example.com'
      }
    }).as('getUser');
  });

  // C.P.PV.1
  it('zeigt Ladeanzeige und rendert Nutzerdaten', () => {
    mount(<ProfilView />);
    cy.contains('Lade Nutzer...').should('exist'); // Ladeanzeige sichtbar
    cy.wait('@getUser');
    cy.contains('Max').should('exist');
    cy.contains('Neue Beschreibung').should('exist');
    cy.contains('Benutzer').should('exist');
    cy.contains('max@example.com').should('exist');
  });

  // C.P.PV.2
  it('wechselt in den Bearbeitungsmodus und speichert Änderungen', () => {
    mount(<ProfilView />);
    cy.wait('@getUser');

    cy.get('button[title="Bearbeiten"]').click();

    // Erstes Textfeld (Vorname)
    cy.get('input[type="text"]').first().clear().type('Moritz');

    // Textarea (Beschreibung)
    cy.get('textarea').clear().type('Neue Beschreibung');

    // Letztes Textfeld (Rolle)
    cy.get('input[type="text"]').last().clear().type('Benutzer');

    cy.contains('Speichern').click();

    // Änderungen werden angezeigt
    cy.contains('Moritz').should('exist');
    cy.contains('Neue Beschreibung').should('exist');
    cy.contains('Benutzer').should('exist');
  });
});
