import React from 'react';
import ProfilViewPage from '../../../src/pages/ProfilViewPage';
import { mount } from 'cypress/react';
import { MemoryRouter, Route, Routes } from 'react-router-dom';

describe('ProfilViewPage Komponententest', () => {
  const projectId = '123';

  const mountWithRouter = (pid) => {
    cy.intercept('GET', `http://localhost:8080/auth/status?projectid=${pid}`, {
      statusCode: 200,
      body: { isAuthenticated: true },
    });

    mount(
      <MemoryRouter initialEntries={[`/profil/${pid}`]}>
        <Routes>
          <Route path="/profil/:projectId" element={<ProfilViewPage />} />
        </Routes>
      </MemoryRouter>
    );
  };

  // C.P.PVP.1
  it('mountet korrekt und zeigt Ladeanzeige', () => {
    mountWithRouter(projectId);
    cy.contains('Lade Authentifizierungsstatus...').should('exist');
  });

  // C.P.PVP.2
  it('blockiert Zugriff bei nicht authentifiziertem Benutzer', () => {
    const unauthId = '999';
    cy.intercept('GET', `http://localhost:8080/auth/status?projectid=${unauthId}`, {
      statusCode: 200,
      body: { isAuthenticated: false },
    });

    mount(
      <MemoryRouter initialEntries={[`/profil/${unauthId}`]}>
        <Routes>
          <Route path="/profil/:projectId" element={<ProfilViewPage />} />
        </Routes>
      </MemoryRouter>
    );

    // Nur prÃ¼fen, ob initial gemountet wurde
    cy.get('body').should('exist');
  });
});