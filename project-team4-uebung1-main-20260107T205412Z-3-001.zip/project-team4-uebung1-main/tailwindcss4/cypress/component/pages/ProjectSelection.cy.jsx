import React from 'react';
import { mount } from 'cypress/react';
import { MemoryRouter, Routes, Route } from 'react-router-dom';
import ProjectSelection from '../../../src/pages/ProjectSelection';

describe('ProjectSelection Komponententest', () => {
  // C.P.PS.1
  it('zeigt Ladeanzeige', () => {
    cy.intercept('GET', 'http://localhost:8080/auth/status', {
      statusCode: 200,
      body: { isAuthenticated: null },
    });

    mount(
      <MemoryRouter initialEntries={['/']}>
        <Routes>
          <Route path="/" element={<ProjectSelection />} />
        </Routes>
      </MemoryRouter>
    );

    cy.contains('Lade Authentifizierungsstatus...').should('exist');
  });

  // C.P.PS.2
  it('rendert Projektliste wenn authentifiziert', () => {
    cy.intercept('GET', 'http://localhost:8080/auth/status', {
      statusCode: 200,
      body: { isAuthenticated: true },
    });

    cy.intercept('GET', 'http://localhost:8080/getprojects', {
      statusCode: 200,
      body: [
        { id: '1', name: 'Projekt A' },
        { id: '2', name: 'Projekt B' },
      ],
    });

    mount(
      <MemoryRouter initialEntries={['/']}>
        <Routes>
          <Route path="/" element={<ProjectSelection />} />
        </Routes>
      </MemoryRouter>
    );

    cy.contains('Projekt A').should('exist');
    cy.contains('Projekt B').should('exist');
  });

  // C.P.PS.3
  it('zeigt keinen Projektinhalt wenn nicht authentifiziert', () => {
    cy.intercept('GET', 'http://localhost:8080/auth/status', {
      statusCode: 200,
      body: { isAuthenticated: false },
    });

    mount(
      <MemoryRouter initialEntries={['/']}>
        <Routes>
          <Route path="/" element={<ProjectSelection />} />
        </Routes>
      </MemoryRouter>
    );

    // Da Redirect via window.location.href gemacht wird, können wir nur prüfen, dass kein Projekt-Button angezeigt wird
    cy.get('button').should('not.exist');
  });
});
