import React from 'react';
import { mount } from 'cypress/react';
import { MemoryRouter, Routes, Route } from 'react-router-dom';
import SprintBacklogPage from '../../../src/pages/SprintBacklogPage';

describe('SprintBacklogPage Komponententest', () => {
  // C.P.SPBP.1
  it('zeigt Ladeanzeige', () => {
    cy.intercept('GET', 'http://localhost:8080/auth/status*', {
      statusCode: 200,
      body: { isAuthenticated: null },
    });

    mount(
      <MemoryRouter initialEntries={['/project/123/sprintbacklog']}>
        <Routes>
          <Route path="/project/:projectId/sprintbacklog" element={<SprintBacklogPage />} />
        </Routes>
      </MemoryRouter>
    );

    cy.contains('Lade Authentifizierungsstatus...').should('exist');
  });

  // C.P.SPBP.2
  it('rendert SprintBacklog wenn authentifiziert', () => {
    cy.intercept('GET', 'http://localhost:8080/auth/status*', {
      statusCode: 200,
      body: { isAuthenticated: true },
    });

    mount(
      <MemoryRouter initialEntries={['/project/123/sprintbacklog']}>
        <Routes>
          <Route path="/project/:projectId/sprintbacklog" element={<SprintBacklogPage />} />
        </Routes>
      </MemoryRouter>
    );

    cy.get('.Inhalt').should('exist');
  });

  // C.P.SPBP.3
  it('zeigt keinen SprintBacklog-Inhalt wenn nicht authentifiziert', () => {
    cy.intercept('GET', 'http://localhost:8080/auth/status*', {
      statusCode: 200,
      body: { isAuthenticated: false },
    });

    mount(
      <MemoryRouter initialEntries={['/project/123/sprintbacklog']}>
        <Routes>
          <Route path="/project/:projectId/sprintbacklog" element={<SprintBacklogPage />} />
        </Routes>
      </MemoryRouter>
    );

    // Da bei fehlender Authentifizierung kein Inhalt gerendert wird
    cy.get('.Inhalt').should('not.exist');
  });
});
