import React from 'react';
import { mount } from 'cypress/react';
import SprintBoardPage from '../../../src/pages/SprintBoardPage';
import { MemoryRouter, Routes, Route } from 'react-router-dom';

describe('SprintBoardPage Komponententest', () => {
  // C.P.SPBDP.1
  it('zeigt Ladeanzeige während Authentifizierungsstatus noch unbekannt ist', () => {
    cy.intercept('GET', '**/auth/status*', {
      statusCode: 200,
      body: { isAuthenticated: null },
    }).as('authStatus');

    mount(
      <MemoryRouter initialEntries={['/sprint/123']}>
        <Routes>
          <Route path="/sprint/:projectId" element={<SprintBoardPage />} />
        </Routes>
      </MemoryRouter>
    );

    cy.contains('Lade Authentifizierungsstatus...').should('exist');
  });

  // C.P.SPBDP.2
  it('zeigt Fehlermeldung bei fehlerhaftem Abruf', () => {
    cy.intercept('GET', '**/auth/status*', {
      statusCode: 500,
      body: 'Serverfehler',
    }).as('authStatusError');

    mount(
      <MemoryRouter initialEntries={['/sprint/123']}>
        <Routes>
          <Route path="/sprint/:projectId" element={<SprintBoardPage />} />
        </Routes>
      </MemoryRouter>
    );

    cy.contains('Fehler beim Abrufen des Authentifizierungsstatus').should('exist');
  });

  // C.P.SPBDP.3
  it('zeigt SprintBoard wenn authentifiziert', () => {
    cy.intercept('GET', '**/auth/status*', {
      statusCode: 200,
      body: { isAuthenticated: true },
    }).as('authStatusTrue');

    mount(
      <MemoryRouter initialEntries={['/sprint/123']}>
        <Routes>
          <Route path="/sprint/:projectId" element={<SprintBoardPage />} />
        </Routes>
      </MemoryRouter>
    );

    cy.get('.Inhalt').should('exist');
  });

  // C.P.SPBDP.4
  it('zeigt keinen Inhalt wenn nicht authentifiziert (Redirect nicht testbar)', () => {
    cy.intercept('GET', '**/auth/status*', {
      statusCode: 200,
      body: { isAuthenticated: false },
    }).as('authStatusFalse');

    mount(
      <MemoryRouter initialEntries={['/sprint/123']}>
        <Routes>
          <Route path="/sprint/:projectId" element={<SprintBoardPage />} />
        </Routes>
      </MemoryRouter>
    );

    cy.get('.Inhalt').should('not.exist');
  });
});
