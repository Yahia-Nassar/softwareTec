import React from 'react';
import { mount } from 'cypress/react';
import { MemoryRouter, Routes, Route } from 'react-router-dom';
import SprintPage from '../../../src/pages/SprintPage';

describe('SprintPage Komponententest', () => {
  // C.P.SPP.1
  it('zeigt Ladeanzeige', () => {
    cy.intercept('GET', 'http://localhost:8080/auth/status*', {
      statusCode: 200,
      body: { isAuthenticated: null },
    });

    mount(
      <MemoryRouter initialEntries={['/sprint/123']}>
        <Routes>
          <Route path="/sprint/:projectId" element={<SprintPage />} />
        </Routes>
      </MemoryRouter>
    );

    cy.contains('Lade Authentifizierungsstatus...').should('exist');
  });

  // C.P.SPP.2
  it('zeigt SprintKanban wenn authentifiziert', () => {
    cy.intercept('GET', 'http://localhost:8080/auth/status*', {
      statusCode: 200,
      body: { isAuthenticated: true },
    });

    mount(
      <MemoryRouter initialEntries={['/sprint/123']}>
        <Routes>
          <Route path="/sprint/:projectId" element={<SprintPage />} />
        </Routes>
      </MemoryRouter>
    );

    cy.get('.Inhalt').should('exist');
  });

  // C.P.SPP.3
  it('zeigt keinen SprintKanban wenn nicht authentifiziert', () => {
    cy.intercept('GET', 'http://localhost:8080/auth/status*', {
      statusCode: 200,
      body: { isAuthenticated: false },
    });

    mount(
      <MemoryRouter initialEntries={['/sprint/123']}>
        <Routes>
          <Route path="/sprint/:projectId" element={<SprintPage />} />
        </Routes>
      </MemoryRouter>
    );

    cy.get('.Inhalt').should('not.exist');
  });
});