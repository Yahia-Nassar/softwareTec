import React from 'react';
import { mount } from 'cypress/react';
import TeamPage from '../../../src/pages/TeamPage';
import { MemoryRouter, Routes, Route } from 'react-router-dom';

describe('TeamPage Komponententest', () => {
  // C.P.TMP.1
  it('zeigt Ladeanzeige während Authentifizierungsstatus geladen wird', () => {
    cy.intercept('GET', 'http://localhost:8080/auth/status', {
      delayMs: 1500,
      statusCode: 200,
      body: { isAuthenticated: true }
    });

    mount(
      <MemoryRouter initialEntries={['/team']}>
        <Routes>
          <Route path="/team" element={<TeamPage />} />
        </Routes>
      </MemoryRouter>
    );

    cy.contains('Lade Authentifizierungsstatus...').should('exist');
  });

  // C.P.TMP.2
  it('rendert Seite korrekt bei authentifiziertem Benutzer', () => {
    cy.intercept('GET', 'http://localhost:8080/auth/status', {
      statusCode: 200,
      body: { isAuthenticated: true }
    });

    mount(
      <MemoryRouter initialEntries={['/team']}>
        <Routes>
          <Route path="/team" element={<TeamPage />} />
        </Routes>
      </MemoryRouter>
    );

    cy.get('body').should('exist');
  });

  // C.P.TMP.3
  it('rendert nichts, wenn Benutzer nicht authentifiziert ist', () => {
    cy.intercept('GET', 'http://localhost:8080/auth/status', {
      statusCode: 200,
      body: { isAuthenticated: false }
    });

    mount(
      <MemoryRouter initialEntries={['/team']}>
        <Routes>
          <Route path="/team" element={<TeamPage />} />
        </Routes>
      </MemoryRouter>
    );

    // Wir prüfen nur auf Existenz des DOMs, nicht auf Weiterleitung
    cy.get('body').should('exist');
  });

  // C.P.TMP.4
  it('zeigt eine Fehlermeldung bei Serverfehler', () => {
    cy.intercept('GET', 'http://localhost:8080/auth/status', {
      statusCode: 500,
      body: 'Serverfehler'
    });

    mount(
      <MemoryRouter initialEntries={['/team']}>
        <Routes>
          <Route path="/team" element={<TeamPage />} />
        </Routes>
      </MemoryRouter>
    );

    cy.contains('Fehler beim Abrufen des Authentifizierungsstatus').should('exist');
  });
});