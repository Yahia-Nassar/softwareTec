import React from 'react';
import { mount } from 'cypress/react';
import USViewPage from '../../../src/pages/USViewPage';
import { MemoryRouter, Route, Routes } from 'react-router-dom';

describe('USViewPage Komponententest', () => {
  const validProjectId = '123';
  const invalidProjectId = '999';
  const errorProjectId = '500';

  // Authentifizierter Zustand
  beforeEach(() => {
    cy.intercept('GET', `http://localhost:8080/auth/status?projectid=${validProjectId}`, {
      statusCode: 200,
      body: { isAuthenticated: true },
    });

    // Nicht authentifiziert
    cy.intercept('GET', `http://localhost:8080/auth/status?projectid=${invalidProjectId}`, {
      statusCode: 200,
      body: { isAuthenticated: false },
    });

    // Serverfehler
    cy.intercept('GET', `http://localhost:8080/auth/status?projectid=${errorProjectId}`, {
      statusCode: 500,
      body: 'Fehler',
    });
  });

  // C.P.USVP.1
  it('zeigt Ladeanzeige und rendert USView wenn authentifiziert', () => {
    mount(
      <MemoryRouter initialEntries={[`/usview/${validProjectId}`]}>
        <Routes>
          <Route path="/usview/:projectId" element={<USViewPage />} />
        </Routes>
      </MemoryRouter>
    );

    cy.contains('Lade Authentifizierungsstatus...').should('exist');
  });

  // C.P.USVP.2
  it('zeigt keine Inhalte wenn nicht authentifiziert (Redirect nicht geprüft)', () => {
    mount(
      <MemoryRouter initialEntries={[`/usview/${invalidProjectId}`]}>
        <Routes>
          <Route path="/usview/:projectId" element={<USViewPage />} />
        </Routes>
      </MemoryRouter>
    );

    cy.get('body').should('exist');
  });

  // C.P.USVP.3
  it('zeigt Fehlermeldung bei Serverfehler', () => {
    mount(
      <MemoryRouter initialEntries={[`/usview/${errorProjectId}`]}>
        <Routes>
          <Route path="/usview/:projectId" element={<USViewPage />} />
        </Routes>
      </MemoryRouter>
    );

    cy.contains('Fehler beim Abrufen des Authentifizierungsstatus').should('exist');
  });
});
