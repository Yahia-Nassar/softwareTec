describe('Sprint-Management', () => {

  // E2E.C.AS.1
  it('Ermöglicht das Hinzufügen eines Sprints über die UI', () => {
    cy.visit('/sprint'); // Besuche die Sprint-Management-Seite

    cy.contains('Sprint hinzufügen').click();
    cy.get('input[type="text"]').type('Sprint 1');
    cy.get('input[type="date"]').eq(0).type('2025-06-01');
    cy.get('input[type="date"]').eq(1).type('2025-06-15');
    cy.contains('Hinzufügen').click();

    cy.contains('Sprint 1').should('exist'); // Stelle sicher, dass der Sprint in der UI erscheint
  });
});
