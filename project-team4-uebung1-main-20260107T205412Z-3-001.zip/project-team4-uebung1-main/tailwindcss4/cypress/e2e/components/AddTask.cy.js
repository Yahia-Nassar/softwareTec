describe('AddTask-Komponente', () => {
  beforeEach(() => {
    cy.visit('/'); // Besuche die Anwendung, passe die URL entsprechend an
  });

  // E2E.C.AT.1
  it('Sollte das Aufgaben-Modal öffnen, wenn die Schaltfläche "Aufgabe hinzufügen" geklickt wird', () => {
    cy.contains('Aufgabe hinzufügen').click();
    cy.get('.bg-#121629').should('be.visible'); // Überprüfung, ob das Modal sichtbar ist
  });

  // E2E.C.AT.2
  it('Sollte es dem Benutzer ermöglichen, eine neue Aufgabe hinzuzufügen', () => {
    cy.contains('Aufgabe hinzufügen').click(); 

    cy.get('input[type="text"]').type('Neue Aufgabe');
    cy.get('textarea').type('Dies ist eine neue Aufgabe');
    cy.get('select').first().select('IN_PROGRESS');
    cy.get('select').eq(1).select('HIGH');
    cy.get('input[type="number"]').type('3');

    cy.get('button[type="submit"]').click();

    cy.get('.task-list').contains('Neue Aufgabe').should('exist'); // Überprüfung, ob die Aufgabe zur Liste hinzugefügt wurde
  });

  // E2E.C.AT.3
  it('Sollte das Modal schließen, wenn die Schaltfläche "Schließen" geklickt wird', () => {
    cy.contains('Aufgabe hinzufügen').click();
    cy.contains('Schließen').click();
    cy.get('.bg-#121629').should('not.exist');
  });
});
