describe('Verwaltung von User Stories', () => {
  // E2E.C.AUS.1
  it('Ermöglicht das Hinzufügen einer User Story über die UI', () => {
    cy.visit('/board'); // Besuche die Board-Seite

    cy.contains('User Story hinzufügen').click();
    cy.get('input[type="text"]').type('Neue Funktion');
    cy.get('textarea').eq(0).type('Beschreibung der Funktion');
    cy.get('textarea').eq(1).type('Akzeptanzkriterien');
    cy.contains('Hinzufügen').click();

    cy.contains('Neue Funktion').should('exist'); // Überprüfe, ob sie in der UI erscheint
  });
});
