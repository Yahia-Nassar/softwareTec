describe('Benutzerzuweisung', () => {
  // E2E.C.ASUS.1
  it('Ermöglicht das Auswählen und Entfernen von Benutzern', () => {
    cy.visit('/tasks'); // Navigiere zum Aufgaben-Board

    cy.contains('+ Benutzer hinzufügen').select('Bob');
    cy.contains('Bob').should('exist'); // Überprüfe das Erscheinen

    cy.contains('Bob').click(); // Entferne Benutzer
    cy.contains('Bob').should('not.exist'); // Überprüfe, ob Bob entfernt wurde
  });
});
