/// <reference types="cypress" />

describe('End-to-End-Test der Backlog-Seite', () => {
  // Führt Setup-Aktionen aus, bevor jeder Test startet
  beforeEach(() => {
    cy.intercept('GET', 'http://localhost:8080/auth/status?projectid=*', {
      statusCode: 200,
      body: { isAuthenticated: true }, // Simuliert einen authentifizierten Benutzer
    }).as('authCheck'); // Gibt der Anfrage einen Alias für spätere Verwendung
  });

  // E2E.P.BP.1
  it('Leitet bei fehlender Authentifizierung zur Anmeldung weiter', () => {
    cy.intercept('GET', 'http://localhost:8080/auth/status?projectid=*', {
      statusCode: 200,
      body: { isAuthenticated: false }, // Simuliert einen nicht authentifizierten Benutzer
    }).as('authDenied'); // Alias für die abgelehnte Authentifizierung

    cy.visit('/backlogPage'); // Besucht die Backlog-Seite
    cy.wait('@authDenied'); // Wartet auf die Antwort der Authentifizierungsanfrage
    cy.url().should('eq', 'http://localhost:8080/req/login'); // Überprüft, ob die Weiterleitung zur Login-Seite erfolgt ist
  });

  // E2E.P.BP.2
  it('Lädt das Backlog bei erfolgreicher Authentifizierung', () => {
    cy.visit('/backlogPage'); // Besucht die Backlog-Seite
    cy.wait('@authCheck'); // Wartet auf die erfolgreiche Authentifizierungsanfrage
    cy.get('.Inhalt').should('exist'); // Überprüft, ob das Backlog geladen wurde
  });
});
