import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import DashboardPage from "./pages/DashboardPage";
import SprintPage from "./pages/SprintPage";
import BacklogPage from "./pages/BacklogPage";
import ProfilViewPage from "./pages/ProfilViewPage";
import TeamPage from "./pages/TeamPage";
import ProjectSelection from "./pages/ProjectSelection";
import Notification from "./components/Notification";
import 'react-toastify/dist/ReactToastify.css'; 
import MeetingPage from "./pages/MeetingPage";
import SprintBoardPage from "./pages/SprintBoardPage";
import SprintBacklogPage from "./pages/SprintBacklogPage"
import TaskReminder from "./components/TaskReminder";
import { useState, useEffect } from "react";
import USViewPage from "./pages/USViewPage";
import SprintViewPage from "./pages/SprintViewPage";
import MeetingReminder from "./components/MeetingReminder";
import { ConfirmDialog } from "primereact/confirmdialog";


function App() {
  const pathParts = window.location.pathname.split("/");
  const projectId = pathParts[1];

  return (
    <Router>
      <Notification />
      <ConfirmDialog />
      {projectId && <TaskReminder/>}
      {projectId && <MeetingReminder />}
      <Routes>
        <Route path="/projectselection" element={<ProjectSelection />} />
        <Route path="/:projectId/sprint" element={<SprintPage />} />
        <Route path="/:projectId/backlog" element={<BacklogPage />} />
        <Route path="/:projectId/profil" element={<ProfilViewPage />} />
        <Route path="/:projectId/team" element={<TeamPage />} />
        <Route path="/:projectId/dashboard" element={<DashboardPage />} />
        <Route path="/:projectId/meetings" element={<MeetingPage />} />
        <Route path="/:projectId/sprintboard" element={<SprintBoardPage />} />
        <Route path="/:projectId/sprintbacklog" element={<SprintBacklogPage />} />
        <Route path="/:projectId/USView" element={<USViewPage />} />
        <Route path="/:projectId/SprintView" element={<SprintViewPage />} />
        <Route path="/" element={<SprintPage />} />
      </Routes>
    </Router>
  );
}

export default App;