import React, { useState } from "react";
import Popup from "reactjs-popup";
import { FiPlus } from "react-icons/fi";
import "reactjs-popup/dist/index.css";

const AddSprint = ({ onAddSprint }) => {
  const [name, setName] = useState("");
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");

  const handleAddSprint = (e, close) => {
    e.preventDefault();
    onAddSprint({ name: name.trim(), startDate, endDate });
    setName("");
    setStartDate("");
    setEndDate("");
    close();
  };

  return (
    <Popup
      trigger={
        <button className="flex w-full items-center gap-1.5 px-3 py-1.5 text-xs text-neutral-400 transition-colors hover:text-neutral-50">
          Add Sprint <FiPlus />
        </button>
      }
      modal
      nested
      contentStyle={{ padding: 0, border: "none", background: "none" }}
    >
      {close => (
        <div className="fixed inset-0 bg-[#121629]/80 flex items-center justify-center p-4 z-50">
          <div className="bg-[#232946] rounded-lg p-6 w-full max-w-[600px] mx-4 sm:mx-auto overflow-y-auto max-h-[90vh] text-white">
            <form onSubmit={e => handleAddSprint(e, close)}>
              <div className="flex flex-col space-y-4">
                <label className="flex flex-col">
                  Sprint Name:
                  <input
                    type="text"
                    value={name}
                    onChange={e => setName(e.target.value)}
                    required
                    className="mt-1 p-2 rounded bg-[#121629]"
                  />
                </label>
                <label className="flex flex-col">
                  Start Date:
                  <input
                    type="date"
                    value={startDate}
                    onChange={e => setStartDate(e.target.value)}
                    required
                    className="mt-1 p-2 rounded bg-[#121629]"
                  />
                </label>
                <label className="flex flex-col">
                  End Date:
                  <input
                    type="date"
                    value={endDate}
                    onChange={e => setEndDate(e.target.value)}
                    required
                    className="mt-1 p-2 rounded bg-[#121629]"
                  />
                </label>
              </div>
              <div className="flex justify-end space-x-2 mt-4">
                <button type="submit" className="px-4 py-2 bg-[#121629] text-white rounded">
                  Add
                </button>
                <button
                  type="button"
                  onClick={close}
                  className="px-4 py-2 bg-[#121629] text-white rounded"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </Popup>
  );
};

export default AddSprint;
