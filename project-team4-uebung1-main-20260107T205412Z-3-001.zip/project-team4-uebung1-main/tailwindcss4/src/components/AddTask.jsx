import React, { useState, useEffect } from "react";
import Popup from 'reactjs-popup';
import { FiPlus } from "react-icons/fi";
import AssignedUserSelector from "./AssignedUserSelection";
import { useParams } from 'react-router-dom';

//Trace: "AddTask" in https://git.informatik.uni-rostock.de/softwaretechnik-ws-2024-25/uebung1/team4/abgabedokument-sprint-4/-/blob/5f41bdf8c1770d6e342ab58ddca00db73b12077c/Klassendiagramm_Sprint_4.svg


const AddTask = ({setCards, cards, task, selectedSprint}) => {
    const [title, setTitle] = useState('');
    const [description, setDescription] = useState('');
    const [status, setStatus] = useState('NOT_STARTED'); 
    const [priority, setPriority] = useState('LOW');
    const [estTime, setEstTime] = useState(0); 
    const [type, setType] = useState('task');
    const [userStory, setUserStory] = useState([]);
    const [isTemp, setisTemp] = useState(true)
    const [frontendID, setFrontendID] = useState('');
    const [userStories, setUserStories] = useState([]);
    const [selectedUserStory, setSelectedUserStory] = useState("");
    const [users, setUsers] = useState([]);
    const { projectId } = useParams();

useEffect(() => {
  const fetchUserStories = async () => {
    try {
      const response = await fetch(`http://localhost:8080/getuserstories?projectid=${projectId}`, {
        method: "GET",
        credentials: 'include',
      });
      const data = await response.json();
      const filtered = data.filter(story => !story.isTemp);
      setUserStories(filtered);

      console.log("Geladene User Stories:", filtered);
    } catch (error) {
      console.error("Fehler beim Laden der User Stories:", error);
    }
  };

  fetchUserStories();
}, [projectId]);

    const handleSubmit = (e, close) => {
        e.preventDefault();

        const randomId = Math.floor(Math.random() * 1_000_000_000);

        if (!title.trim().length) return;
        const newCard = {
            title: title.trim(),
            description: description.trim(),
            status,
            priority,
            estTime,
            users,
            userStory: selectedUserStory,
            id: randomId,
            sprint: selectedSprint,
            type: "task",
            frontendID: 'task-' + randomId.toString(),
            createdAt: new Date().toISOString(),
        };
        setCards((pv) => [...pv, newCard]);
        setTitle('');
        setDescription('');
        setStatus('NOT_STARTED');
        setPriority('LOW');
        setEstTime(0);
        setType('task');
        setisTemp(true);
        setFrontendID('');
        setUsers([]);

        const userStoryValue = newCard.userStory
            ? { id: newCard.userStory }
            : null;

        const task_with_sprint = {
            ...newCard,
            sprint: { sprintid: selectedSprint },
            userStory: userStoryValue
        };

        fetch(`http://localhost:8080/saveTasks?projectid=${projectId}`, {
            method: 'POST',
            credentials: 'include',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify([task_with_sprint])
        })
            .then((response) => response.json())
            .then((data) => {
                console.log('Erfolg:', data);
                //window.location.reload();
            })
            .catch((error) => {
                console.error('Fehler:', error);
            });

        close();
    };

    return (
        <Popup trigger={<button className="flex w-full items-center gap-1.5 px-3 py-1.5 text-xs text-neutral-400 transition-colors hover:text-neutral-50">Add Task <FiPlus /></button>} 
        modal 
        nested
        contentStyle={{ padding: 0, border: 'none', background: 'none' }}
>
            {close => (
              <div className="fixed inset-0 bg-[#121629]/80 flex items-center justify-center p-4 z-50">
                <div className="bg-[#232946] rounded-lg p-6 w-full max-w-[600px] mx-4 sm:mx-auto overflow-y-auto max-h-[90vh]">
                <form onSubmit={(e) => handleSubmit(e, close)}>
                  <div className='flex flex-col space-y-4'>
                    <label className='flex flex-col'>
                      Title:
                      <input
                        type='text'
                        value={title}
                        onChange={(e) => setTitle(e.target.value)}
                        required
                        className='mt-1 p-2 rounded bg-[#121629]'
                      />
                    </label>
                    <label className='flex flex-col'>
                      Description:
                      <textarea
                        value={description}
                        onChange={(e) => setDescription(e.target.value)}
                        required
                        className='mt-1 p-2 rounded  bg-[#121629]'
                      />
                    </label>
                    <label className='flex flex-col'>
                      Status:
                      <select
                        value={status}
                        onChange={(e) => setStatus(e.target.value)}
                        className='mt-1 p-2 rounded bg-[#121629]'
                      >
                        <option value='NOT_STARTED'>Not Started</option>
                        <option value='IN_PROGRESS'>In Progress</option>
                        <option value='IN_TESTING'>In Testing</option>
                        <option value='COMPLETED'>Completed</option>
                        <option value='Blocked'>Blocked</option>
                      </select>
                    </label>
                    <label className='flex flex-col'>
                      Priority:
                      <select
                        value={priority}
                        onChange={(e) => setPriority(e.target.value)}
                        className='mt-1 p-2 rounded bg-[#121629]'
                      >
                        <option value='LOW'>Low</option>
                        <option value='MEDIUM'>Medium</option>
                        <option value='HIGH'>High</option>
                      </select>
                    </label>
                    <div className="mb-4">
          <label className="block text-sm font-medium mb-1">Estimated Time (days)</label>
          <input
            type="number"
            value={estTime}
            onChange={(e) => setEstTime(parseInt(e.target.value))}
            className="w-full p-2 rounded bg-[#121629] text-white"
            min="0"
          />
        </div>
        <AssignedUserSelector
          assignedUsers={users}
          setAssignedUsers={setUsers}
          projectId={projectId}
        />

                    <select
  value={selectedUserStory}
  onChange={(e) => setSelectedUserStory(e.target.value)}
  className="w-full p-2 rounded bg-[#121629] text-white"
>
  <option value="">Select a User Story</option>
  {userStories
    .filter(story => !story.isTemp)
    .map(story => (
      <option key={story.id} value={story.id}>
        {story.title}
      </option>
  ))}
</select>
                  </div>
                  <div className='flex justify-end space-x-2 mt-4'>
                    <button type='submit' className='px-4 py-2 bg-[#121629] text-white rounded'>
                      Add
                    </button>
                    <button onClick={close} className='px-4 py-2 bg-[#121629] text-white rounded'>
                      Cancel
                    </button>
                  </div>
                </form>
              </div>
              </div>
            )}
        </Popup>
    );
};

export default AddTask;