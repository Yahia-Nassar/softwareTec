import React, { useState } from "react";
import Popup from 'reactjs-popup';
import { FiPlus } from "react-icons/fi";
import 'reactjs-popup/dist/index.css';
import { useParams } from 'react-router-dom';


//Trace: "AddUserStory" in https://git.informatik.uni-rostock.de/softwaretechnik-ws-2024-25/uebung1/team4/abgabedokument-sprint-4/-/blob/5f41bdf8c1770d6e342ab58ddca00db73b12077c/Klassendiagramm_Sprint_4.svg


const AddUserStory = ({ columnName, setCards , setFilteredCards, selectedSprint}) => {
    const [title, setTitle] = useState('');
    const [description, setDescription] = useState('');
    const [status, setStatus] = useState('BACKLOG'); 
    const [acceptanceCriteria, setAcceptanceCriteria] = useState(''); 
    const [priority, setPriority] = useState('LOW');
    const [type, setType] = useState('userStory');
    const [isTemp, setisTemp] = useState(true);
    const [frontendID, setFrontendID] = useState('');
    const [sprint, setSprint] = useState(1);
    const { projectId } = useParams();

    const handleSubmit = (e) => {
        e.preventDefault();

        const randomId = Math.floor(Math.random() * 1_000_000_000);

        if (!title.trim().length) return;
        const newCard = {
            columnName,
            title: title.trim(),
            description: description.trim(),
            status,
            acceptanceCriteria: acceptanceCriteria.trim(),
            priority,
            id: randomId,
            type: "userStory",
            isTemp: true,
            frontendID: 'us-'+randomId.toString(),
            sprint: selectedSprint || 1
        };
        setCards((pv) => [...pv, newCard]);
        if (typeof setFilteredCards === "function") {
            setFilteredCards((prev) => [...prev, newCard]);
        }
        setTitle('');
        setDescription('');
        setAcceptanceCriteria('');
        setStatus('BACKLOG');
        setPriority('LOW');
        setType('userStory');
        setisTemp(true);
        setFrontendID('');
        setSprint(1);

        const us_with_sprint = {
            ...newCard,
            sprint: { sprintid: selectedSprint || 1}
        };

        fetch(`http://localhost:8080/saveUSCards?projectid=${projectId}`, {
            method: "POST",
            credentials: "include",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify([us_with_sprint])
        })
            .then((response) => response.json())
            .then((data) => {
                console.log("Erfolg:", data);
                window.location.reload();
            })
            .catch((error) => {
                console.error("Fehler:", error);
            });

        close();
    };

    return (
        <Popup trigger={<button className="flex w-full items-center gap-1.5 px-3 py-1.5 text-xs text-neutral-400 transition-colors hover:text-neutral-50">Add User Story <FiPlus /></button>} 
                modal 
                nested
                contentStyle={{ padding: 0, border: 'none', background: 'none' }}
        >
            {close => (
                <div className="fixed inset-0 bg-[#121629]/80 flex items-center justify-center p-4 z-50">
                <div className="bg-[#232946] rounded-lg p-6 w-full max-w-[600px] mx-4 sm:mx-auto overflow-y-auto max-h-[90vh]">
                    <form onSubmit={handleSubmit}>
                        <div className="flex flex-col space-y-4">
                         <label className="flex flex-col">
                             User Story 
                        </label> 
                            <label className="flex flex-col">
                                Title:
                                <input 
                                    type='text' 
                                    value={title} 
                                    onChange={(e) => setTitle(e.target.value)} 
                                    required 
                                    className="mt-1 p-2 rounded bg-[#121629]"
                                />
                            </label>
                            <label className="flex flex-col">
                                Description:
                                <textarea 
                                    value={description} 
                                    onChange={(e) => setDescription(e.target.value)} 
                                    required 
                                    className="mt-1 p-2 rounded  bg-[#121629]"
                                />
                            </label>
                            <label className="flex flex-col">
                                Acceptance Criteria:
                                <textarea 
                                    value={acceptanceCriteria} 
                                    onChange={(e) => setAcceptanceCriteria(e.target.value)} 
                                    required 
                                    className="mt-1 p-2 rounded  bg-[#121629]"
                                />
                            </label>
                            <label className="flex flex-col">
                                Status:
                                <select 
                                    value={status} 
                                    onChange={(e) => setStatus(e.target.value)}
                                    className="mt-1 p-2  rounded bg-[#121629]"
                                >
                                    <option value="BACKLOG">Backlog</option>
                                    <option value="IN_PROGRESS">In Progress</option>
                                    <option value="COMPLETED">Completed</option>
                                    <option value="INCOMPLETE">Incomplete</option>
                                </select>
                            </label>
                            <label className="flex flex-col">
                                Priority:
                                <select 
                                    value={priority} 
                                    onChange={(e) => setPriority(e.target.value)}
                                    className="mt-1 p-2 rounded bg-[#121629]"
                                >
                                    <option value="LOW">Low</option>
                                    <option value="MEDIUM">Medium</option>
                                    <option value="HIGH">High</option>
                                </select>
                            </label>
                        </div>
                        <div className="flex justify-end space-x-2 mt-4">
                            <button type='submit' className="px-4 py-2 text-white rounded">
                                Add
                            </button>
                            <button type='button' onClick={close} className="px-4 py-2  text-white rounded">
                                Cancel
                            </button>
                        </div>
                    </form>
                </div>
                </div>
            )}
        </Popup>
    );
};

export default AddUserStory;