import { FiUser, FiX } from "react-icons/fi";
import { useEffect, useState } from "react";

const AssignedUserSelector = ({ assignedUsers, setAssignedUsers, projectId, task }) => {
  const [allProjectUsers, setAllProjectUsers] = useState([]);

  useEffect(() => {

    const fetchUsers = async () => {
      try {
        const res = await fetch(`http://localhost:8080/getprojectusers?projectid=${projectId}`, {
            method: "GET",
            credentials: "include",
        });
        if (!res.ok) throw new Error("Fehler beim Laden der Projektmitglieder");
        const data = await res.json();
        setAllProjectUsers(data);
      } catch (err) {
        console.error("Fehler beim Laden der User:", err);
      }
    };

    if (projectId) fetchUsers();
  }, [projectId]);

  const availableUsers = allProjectUsers.filter(
    (u) => !assignedUsers.some((au) => au.id === u.id)
  );

  const handleAddUser = (user) => {
    setAssignedUsers(prev => [...prev, user]);
  };

  const handleRemoveUser = (userId) => {
    setAssignedUsers(prev => prev.filter(u => u.id !== userId));
  };

  return (
    <div className="mb-4">
      <label className="block text-sm font-medium mb-1 flex items-center">
        <FiUser className="mr-1" /> Assigned Users
      </label>

      <div className="flex flex-wrap gap-2 p-2 rounded bg-[#121629] min-h-10 mb-2">
        {assignedUsers.map((user) => (
          <span
            key={user.id}
            className="bg-violet-600 text-white text-xs px-2 py-1 rounded-full flex items-center gap-1 cursor-pointer hover:bg-violet-500"
            title="Click to remove user"
            onClick={() => handleRemoveUser(user.id)}
          >
            {user.username}
            <FiX className="text-white text-xs" />
          </span>
        ))}
        {assignedUsers.length === 0 && (
          <span className="text-white">No users assigned</span>
        )}
      </div>

      <select
        onChange={(e) => {
          const user = availableUsers.find((u) => u.id === parseInt(e.target.value));
          if (user) handleAddUser(user);
        }}
        value=""
        className="w-full p-2 rounded bg-[#121629]  text-white text-sm"
      >
        <option value="" disabled>
          + Add user
        </option>
        {availableUsers.map((user) => (
          <option key={user.id} value={user.id}>
            {user.username}
          </option>
        ))}
      </select>
    </div>
  );
};

export default AssignedUserSelector;
