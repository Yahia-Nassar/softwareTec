import React, { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import SearchFilterSortPanel from "./SearchFilterSortPanel";
import AddUserStory from "./AddUserStory";
import EditUserStory from "./EditUserStory";
import DeleteUserStory from "./DeleteUserStory";
import { notify } from "./Notification";
import ViewSwitch from "./ViewSwitch";

//Trace: "ProjectBacklog" in https://git.informatik.uni-rostock.de/softwaretechnik-ws-2024-25/uebung1/team4/abgabedokument-sprint-4/-/blob/5f41bdf8c1770d6e342ab58ddca00db73b12077c/Klassendiagramm_Sprint_4.svg

export const Backlog = ({ isKanbanView, onSwitch }) => {
    const { projectId } = useParams();

    const [allCards, setAllCards] = useState([]);

    const [filteredCards, setFilteredCards] = useState([]);

    const [sprints, setSprints] = useState([]);

    useEffect(() => {
        const fetchSprints = async () => {
            try {
                const response = await fetch(`http://localhost:8080/getsprints?projectId=${projectId}`, {
                    method: "GET",
                    credentials: "include",
                });
                if (!response.ok) {
                    throw new Error("Fehler beim Laden der Sprints");
                }
                const data = await response.json();
                const sprintOptions = data.map(sprint => ({
                    label: sprint.sprintname || sprint.name || `Sprint ${sprint.sprintid}`,
                    value: String(sprint.sprintid),
                }));
                setSprints(sprintOptions);
            } catch (error) {
                console.error("Fehler:", error);
            }
        };

        fetchSprints();
    }, [projectId]);

    useEffect(() => {
        fetch(`http://localhost:8080/getuserstories?projectid=${projectId}`, {
            method: "GET",
            credentials: "include",
        })
            .then((response) => {
                if (!response.ok) {
                    throw new Error(
                        `Fehler beim Laden der User Stories: ${response.status} ${response.statusText}`
                    );
                }
                return response.json();
            })
            .then((data) => {
                const updatedData = data.map((card) => ({
                    ...card,
                    sprint: card.sprint !== undefined && card.sprint !== null ? String(card.sprint) : "",
                    type: "userStory",
                    frontendID: "us-" + card.id,
                }));
                setAllCards(updatedData);
                setFilteredCards(updatedData);
            })
            .catch((error) => {
                console.error("Fehler:", error);
            });
    }, [projectId]);

    function handleFilteredItems(filteredItems) {
        setFilteredCards(filteredItems);
    }

    function handleSave() {
        const sanitizedCards = filteredCards.map(({ frontendId, sprint, ...rest }) => {
            return {
                ...rest,
                sprint: { sprintid: sprint },
            };
        });
        fetch(`http://localhost:8080/saveUSCards?projectid=${projectId}`, {
            method: "POST",
            credentials: "include",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify(sanitizedCards),
        })
            .then((response) => response.json())
            .then(() => {
                notify.success("saved!");
            })
            .catch((error) => {
                console.error("Fehler:", error);
                notify.error("Error while saving!");
            });
    }

    return (
        <div>
            <div className="p-4 pr-5">
            <SearchFilterSortPanel className="p-5"
                fields={[
                    { name: "status", type: "select", options: ["BACKLOG", "NOT_STARTED", "IN_PROGRESS", "COMPLETED", "INCOMPLETE"] },
                    { name: "priority", type: "select", options: ["LOW", "MEDIUM", "HIGH"] },
                    { name: "sprint", type: "select", options: sprints},
                ]}
                getItems={() => allCards}
                onFilteredItems={handleFilteredItems}
            />
            </div>
            <div className="flex gap-4 p-5 items-center">
            <div className="w-[200px]"> 
                <AddUserStory setCards={setAllCards} setFilteredCards={setFilteredCards} />   
            </div>
                <ViewSwitch isKanbanView={isKanbanView} onSwitch={onSwitch} />
            </div>
            <div className="max-h-[680px] max-w-[1300px] overflow-y-auto border border-transparent bg-[#121629] rounded-md">
            <table>
                <thead className="font-bold item">
                <tr>
                    <th className="p-5">Title</th>
                    <th className="p-5">ID</th>
                    <th className="p-5">Description</th>
                    <th className="p-5">Acceptance Criteria</th>
                    <th className="p-5">Priority</th>
                    <th className="p-5">Status</th>
                    <th className="p-5">Sprint</th>
                    <th className="p-5"></th>
                    <th className="p-5"></th>
                </tr>
                </thead>
                <tbody className="text-center">
                {filteredCards.map((story) => (
                    <tr key={story.id}>
                        <td className="p-5">{story.title}</td>
                        <td className="p-5">{story.id}</td>
                        <td className="p-5">{story.description}</td>
                        <td className="p-5">{story.acceptanceCriteria}</td>
                        <td className="p-5">{story.priority}</td>
                        <td className="p-5">{story.status}</td>
                        <td className="p-5">{sprints.find(s => s.value === story.sprint)?.label || ''}</td>
                        <td className="p-5">
                            <EditUserStory setCards={setAllCards} UserStory={story} setFilteredCards={setFilteredCards}/>
                        </td>
                        <td className="p-5">
                            <DeleteUserStory setCards={setAllCards} UserStory={story} setFilteredCards={setFilteredCards}/>
                        </td>
                    </tr>
                ))}
                </tbody>
            </table>
            </div>
        </div>
    );
};

export default Backlog;