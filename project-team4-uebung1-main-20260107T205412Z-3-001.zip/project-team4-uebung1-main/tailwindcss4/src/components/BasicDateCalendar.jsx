import * as React from 'react';
import { useState } from 'react';
import dayjs from 'dayjs';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { DateCalendar } from '@mui/x-date-pickers/DateCalendar';
import { PickersDay } from '@mui/x-date-pickers/PickersDay';
import { Tooltip, Button } from '@mui/material';

// Trace: "Calendar" in https://git.informatik.uni-rostock.de/softwaretechnik-ws-2024-25/uebung1/team4/abgabedokument-sprint-4/-/blob/5f41bdf8c1770d6e342ab58ddca00db73b12077c/Klassendiagramm_Sprint_4.svg

function BasicDateCalendar({ events = [], onOpenMeetingModal }) {
  const [selectedDate, setSelectedDate] = useState(dayjs());

  function CustomDay(props) {
    const { day, outsideCurrentMonth, ...other } = props;
    const isToday = dayjs().isSame(day, 'day');
    const eventForDay = events.find(e => dayjs(e.date).isSame(day, 'day'));
    const handleClick = () => {
      if (eventForDay) {
        alert(`Type: ${eventForDay.type}\nDescription: ${eventForDay.description}`);
      } else {
        onOpenMeetingModal?.(day);
      }
    };

    return (
      <Tooltip
        title={eventForDay ? `${eventForDay.type}: ${eventForDay.description}` : ''}
        arrow
      >
        <PickersDay
          {...other}
          day={day}
          outsideCurrentMonth={outsideCurrentMonth}
          onClick={handleClick}
          sx={{
            color: 'white',
            border: isToday ? '3px solid #EEBBC3 !important' : undefined,
            borderRadius: '100%',
            backgroundColor: eventForDay ? '#232946 !important' : 'inherit',
            '&:hover': {
              backgroundColor: eventForDay ? 'cornflowerblue' : '#e0e0e0',
            },
          }}
        />
      </Tooltip>
    );
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column' }}>
      <LocalizationProvider dateAdapter={AdapterDayjs}>
        <DateCalendar
          value={selectedDate}
          onChange={(newValue) => setSelectedDate(newValue)}
          slots={{ day: CustomDay }}
          sx={{
            color: 'white !important',
            backgroundColor: '#121629',
            p: 2,
            borderRadius: 2,
            '&, & *': {
              color: 'white !important',
            },
          }}
        />
      </LocalizationProvider>
      <Button
        variant="contained"
        onClick={() => setSelectedDate(dayjs())}
        sx={{
          marginTop: '16px',
          backgroundColor: '#EEBBC3',
          color: '#121629',
          '&:hover': {
            backgroundColor: '#EEBBC3',
            opacity: 0.8,
          },
        }}
      >
        Today
      </Button>
    </div>
  );
}

export default BasicDateCalendar;