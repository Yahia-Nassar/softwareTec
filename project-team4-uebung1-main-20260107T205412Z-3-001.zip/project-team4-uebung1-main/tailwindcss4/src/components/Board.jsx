import React, { useState, useEffect } from "react";
import { FiPlus, FiTrash } from "react-icons/fi";
import { motion } from "framer-motion";
import { FaFire } from "react-icons/fa";
import Popup from 'reactjs-popup';
import 'reactjs-popup/dist/index.css';
import AddTask from "./AddTask"; 
import AddUserStory from "./AddUserStory"; 
import { TaskDetails } from "./TaskDetails";
import UserStoryDetails from "./UserStoryDetails";
import { notify } from "./Notification";
import { useParams } from "react-router-dom";
import EditSprint from "./EditSprint";
import { confirm3 } from "./Confirmbox.jsx";


// Trace: "Column" in https://git.informatik.uni-rostock.de/softwaretechnik-ws-2024-25/uebung1/team4/abgabedokument-sprint-4/-/blob/5f41bdf8c1770d6e342ab58ddca00db73b12077c/Klassendiagramm_Sprint_4.svg

const Column = ({ title, headingColor, cards, status, setCards, boardType, sprint, sprintData, setSprints, showDelete = false, onDelete=() => {}, showCardCount = true}) => {
  const [active, setActive] = useState(false);
  const [selectedTask, setSelectedTask] = useState(null);
  const [userRole, setUserRole] = useState("");
  const { projectId } = useParams();

  useEffect(() => {
    fetch(`http://localhost:8080/getRole?projectid=${projectId}`, {
      method: 'GET',
      credentials: 'include',
    })
      .then(res => res.json())
      .then(roleData => setUserRole(roleData))
      .catch(err => console.error(err));
  }, [projectId]);

  const handleSaveDetails = (updatedTask) => {
    const updatedCards = cards.map((card) =>
      card.frontendID === updatedTask.frontendID ? updatedTask : card
    );
    setCards(updatedCards);
    setSelectedTask(null);
  };

  const handleDragStart = (e, card) => {
    e.dataTransfer.setData("cardId", card.frontendID);
  };

  const handleDragEnd = (e) => {
    const cardId = e.dataTransfer.getData("cardId");
    const cardToMove = cards.find((c) => c.frontendID === cardId);
    if (!cardToMove) return;
    if (cardToMove.type === "userStory" && userRole !== "PRODUCT_OWNER") {
      notify.error("Only the Product Owner can edit User Stories");
      return;
    }
    setActive(false);
    clearHighlights();
    const indicators = getIndicators();
    const { element } = getNearestIndicator(e, indicators);
    const before = element.dataset.before || "-1";
    if (before !== cardId) {
      let copy = [...cards];
      let cardNew = copy.find((c) => c.frontendID === cardId);
      if (!cardNew) return;
      if (status) {
        cardNew = { ...cardNew, status };
      } else {
        cardNew = { ...cardNew, sprint };
      }
      copy = copy.filter((c) => c.frontendID !== cardId);
      const moveToBack = before === "-1";
      if (moveToBack) {
        copy.push(cardNew);
      } else {
        const insertAtIndex = copy.findIndex((el) => el.frontendID === before);
        if (insertAtIndex === undefined) return;
        copy.splice(insertAtIndex, 0, cardNew);
      }
      setCards(copy);
    }
  };

  const handleDragOver = (e) => {
    e.preventDefault();
    highlightIndicator(e);
    setActive(true);
  };

  const clearHighlights = (els) => {
    const indicators = els || getIndicators();
    indicators.forEach((i) => {
      i.style.opacity = "0";
    });
  };

  const highlightIndicator = (e) => {
    const indicators = getIndicators();
    clearHighlights(indicators);
    const el = getNearestIndicator(e, indicators);
    el.element.style.opacity = "1";
  };

  const getNearestIndicator = (e, indicators) => {
    const DISTANCE_OFFSET = 50;
    const el = indicators.reduce(
      (closest, child) => {
        const box = child.getBoundingClientRect();
        const offset = e.clientY - (box.top + DISTANCE_OFFSET);
        if (offset < 0 && offset > closest.offset) {
          return { offset, element: child };
        } else {
          return closest;
        }
      },
      {
        offset: Number.NEGATIVE_INFINITY,
        element: indicators[indicators.length - 1],
      }
    );
    return el;
  };

  const getIndicators = () => {
    if (sprint) {
    return Array.from(document.querySelectorAll(`[data-sprint="${sprint}"]`));
  } else {
    return Array.from(document.querySelectorAll(`[data-status="${status}"]`));
  }
  };

  const handleDragLeave = () => {
    clearHighlights();
    setActive(false);
  };

  const filteredCards = status ? cards.filter((c) => c.status === status) : cards.filter((c) => c.sprint === sprint);

  return (
    <div className={`flex flex-col basis-[220px] min-w-[200px] max-w-[280px] ${boardType === 'sprint' ? 'max-h-[288px]' : 'max-h-[630px]'}`}>
      <div className="mb-3 flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <h3 className={`font-medium pl-2 ${headingColor}`}>{title}</h3>
          {showCardCount && (
            <span className="rounded text-sm text-neutral-400">
              {filteredCards.length}
            </span>
          )}
        </div>
  
        {showDelete && sprint !== 1 && (
          <div className="flex items-center space-x-4 ml-auto">
            <EditSprint
              sprint={sprintData}
              setSprints={setSprints}
              projectId={projectId}
            />
            <div className="flex items-center space-x-4 ml-auto">
            <button
              onClick={() => onDelete(status)}
              className="text-white! font-bold bg-transparent! border-none cursor-pointer p-0"
              aria-label={`Delete Sprint ${title}`}
              title={`Delete Sprint ${title}`}
              type="button"
            >
              ×
            </button>
            </div>
          </div>
        )}
      </div>
      <div className="flex-1 overflow-hidden flex flex-col">
        <div
        onDrop={handleDragEnd}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        className={`overflow-y-auto flex-1 transition-colors px-1 ${
          active ? "bg-[#121629]/50" : "bg-[#121629]/0"
        }`}
      >
        {filteredCards.map((c) => (
          <Card
            key={c.frontendID}
            {...c}
            handleDragStart={handleDragStart}
            handleSaveDetails={handleSaveDetails}
            cards={cards}
            setCards={setCards}
            boardType={boardType}
            userRole={userRole}
            sprint={sprint}
          />
        ))}
        <DropIndicator beforeId={null} status={status} sprint={sprint} />
        </div>
        <div className="pt-2">
        {boardType === "userStory" && status === "BACKLOG" && (
          <AddUserStory status={status} setCards={setCards} selectedSprint={sprint}/>
        )}
        {boardType === "userStory" && sprint === 1 && (
          <AddUserStory status={status} setCards={setCards} selectedSprint={sprint}/>
        )}
        {boardType === "sprint" && status == "NOT_STARTED" && status !== "BACKLOG" && (
          <AddTask status={status} setCards={setCards} cards={cards} selectedSprint={sprint}/>
        )}
        {boardType === "sprint" && status === "BACKLOG" && (
          <AddUserStory status={status} setCards={setCards} selectedSprint={sprint}/>
        )}
      </div>
      {selectedTask && (
        <TaskDetails
          task={selectedTask}
          onClose={() => setSelectedTask(null)}
          onSave={handleSaveDetails}
          cards={cards}
          selectedSprint={sprint}
        />
      )}
    </div>
    </div>
  );
};


// Trace: "Card" in https://git.informatik.uni-rostock.de/softwaretechnik-ws-2024-25/uebung1/team4/abgabedokument-sprint-4/-/blob/5f41bdf8c1770d6e342ab58ddca00db73b12077c/Klassendiagramm_Sprint_4.svg

const Card = ({
  type,
  title,
  id,
  status,
  description,
  acceptanceCriteria,
  priority,
  isTemp,
  frontendID,
  handleSaveDetails,
  cards,
  setCards,
  boardType,
  userRole,
  sprint,
  userInfos,
  userStory,
  estTime,
  actTime,
  inProgressAt,
  completedAt,
}) => {
  const [open, setOpen] = useState(false);

  const handleDragStart = (e) => {
    if (type === "userStory" && userRole !== "PRODUCT_OWNER") {
      e.preventDefault();
      notify.error("Only the Product Owner can edit User Stories");
      return;
    }
    e.dataTransfer.setData("cardId", frontendID);
  };

  return (
    <>
      <DropIndicator beforeId={frontendID} status={status} sprint={sprint}/>
      <motion.div
        layout
        layoutId={frontendID}
        draggable={
          (type !== "userStory" && boardType === "sprint") ||
          (type !== "task" && boardType === "userStory")
        }
        onDragStart={(e) => handleDragStart(e, { title, frontendID, status })}
        onClick={() => setOpen(true)}
        className="cursor-grab rounded border border-neutral-700 bg-neutral-800 p-3 active:cursor-grabbing"
      >
        <p className="text-sm text-neutral-100">{title}</p>
      </motion.div>
      {open && type === "task" && (
        <Popup
          open={open}
          onClose={() => setOpen(false)}
          closeOnDocumentClick
          modal
          nested
          contentStyle={{ background: "rgba(255, 255, 255, 0)", border: "none", padding: "0" }}
          overlayStyle={{ background: "rgba(57, 57, 57, 0.5)" }}
        >
          <TaskDetails
            task={{ id, title, status, description, priority, type, isTemp, frontendID, sprint, userInfos, userStory, estTime, actTime, inProgressAt, completedAt }}
            onClose={() => setOpen(false)}
            onSave={(updatedTask) => {
              handleSaveDetails(updatedTask);
              setOpen(false);
            }}
            cards={cards}
            selectedSprint={sprint}
          />
        </Popup>
      )}
      {open && type === "userStory" && (
        <Popup
          open={open}
          onClose={() => setOpen(false)}
          closeOnDocumentClick
          modal
          nested
          contentStyle={{ background: "rgba(255, 255, 255, 0)", border: "none", padding: "0" }}
          overlayStyle={{ background: "rgba(57, 57, 57, 0.5)" }}
        >
          {(close) => (
            <UserStoryDetails
              status={status}
              cards={cards}
              setCards={setCards}
              UserStory={{ id, title, status, description, priority, acceptanceCriteria, isTemp, frontendID, sprint}}
              close={close}
              selectedSprint={sprint}
            />
          )}
        </Popup>
      )}
    </>
  );
};

const DropIndicator = ({ beforeId, status, sprint }) => {
  return (
    <div
      data-before={beforeId || "-1"}
      data-status={status}
      data-sprint={sprint}
      className="my-0.5 h-0.5 w-full bg-violet-400 opacity-0"
    />
  );
};

const BurnBarrel = ({ cards, setCards }) => {
  const { projectId } = useParams();
  const [active, setActive] = useState(false);
  const handleDragOver = (e) => {
    e.preventDefault();
    setActive(true);
  };
  const handleDragLeave = () => {
    setActive(false);
  };

  const handleDragEnd = async (e) => {
    const cardId = e.dataTransfer.getData("cardId");
   const card = cards.find((c) => c.frontendID === cardId);
   if (!card) return;

   const confirmed = await confirm3();
  if (!confirmed) {
    setActive(false);
    return;
  }

  try {
    const updatedCard = { ...card, status: "BURNBARREL" };
    const tasks = [updatedCard].filter(card => card.type === 'task');
    const response = await fetch(`http://localhost:8080/saveTasks?projectid=${projectId}`, {
      method: "POST",
      credentials: "include",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(tasks),
    });

    if (!response.ok) throw new Error("Error deleting card");
      
    setCards((prevCards) => prevCards.filter((c) => c.frontendID !== cardId));
    notify.success("Delete successful!"); 
    } catch (err) {
      console.error(err);
      notify.error("Error deleting card");
    }
  
    setActive(false);
  };

  
      

  const handleDragStart = (e, card) => {
    e.dataTransfer.setData("cardId", card.frontendID);
  };
  const filteredCards = cards.filter((c) => c.status === "BURNBARREL");

  return (
    <div
      onDrop={handleDragEnd}
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      className={`mt-10 grid h-56 w-56 shrink-0 place-content-center rounded border text-3xl ${
        active
          ? "border-red-800 bg-red-800/20 text-red-500"
          : "border-neutral-500 bg-neutral-500/20 text-neutral-500"
      }`}
    >
      {filteredCards.map((c) => (
        <Card key={c.frontendID} {...c} handleDragStart={handleDragStart} />
      ))}
      {active ? <FaFire className="animate-bounce" /> : <FiTrash />}
    </div>
  );
};

export { Column, BurnBarrel, Card };