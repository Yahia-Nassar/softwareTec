import React, { useRef } from 'react';
import { ConfirmDialog, confirmDialog } from 'primereact/confirmdialog';
import { Toast } from 'primereact/toast';
import { Button } from 'primereact/button';

export const confirm3 = ({ message, header }) => {
  return new Promise((resolve) => {
    confirmDialog({
      message: (
        <div style={{ padding: '1rem' }}>
          {message || "Do you want to proceed?"}
        </div>
      ),
      header: (
        <div style={{ padding: '1rem' }}>
          {header || "Delete Confirmation"}
        </div>
      ),
      icon: 'pi pi-info-circle',
      defaultFocus: 'reject',
      acceptClassName: 'p-button-danger',
      className: 'my-confirm-dialog',
      style: { backgroundColor: '#121629', borderRadius: '8px' },
      width: '600px',
      height: 'auto',
      closable: false,
      accept: () => {
        resolve(true);
      },
      reject: () => {
        resolve(false);
      },
      footer: (props) => (
        <div style={{ display: 'flex', gap: '1rem', justifyContent: 'flex-end', padding: '1rem' }}>
          <Button
            label="Cancel"
            icon="pi pi-times"
            onClick={() => {
              props.reject();
            }}
          />
          <Button
            label="Confirm"
            icon="pi pi-check"
            className="p-button-danger"
            onClick={() => {
              props.accept();
            }}
          />
        </div>
      ),
    });
  });
};
  

export default function Confirmbox() {
    const toast = useRef(null);

    const accept = () => {
        toast.current.show({ severity: 'info', summary: 'Confirmed', detail: 'You have accepted', life: 3000 });
    }

    const reject = () => {
        toast.current.show({ severity: 'warn', summary: 'Rejected', detail: 'You have rejected', life: 3000 });
    }

    const confirm1 = () => {
        confirmDialog({
            message: 'Are you sure you want to proceed?',
            header: 'Confirmation',
            icon: 'pi pi-exclamation-triangle',
            defaultFocus: 'accept',
            accept,
            reject
        });
    };

    const confirm2 = () => {
        confirmDialog({
            message: 'Do you want to delete the task?',
            header: 'Delete Confirmation',
            icon: 'pi pi-info-circle',
            defaultFocus: 'reject',
            acceptClassName: 'p-button-danger',
            accept,
            reject
        });
    };

    return (
        <>
            <Toast ref={toast} />
            <ConfirmDialog />
            <div className="card flex flex-wrap gap-2 justify-content-center">
                <Button onClick={confirm1} icon="pi pi-check" label="Confirm" className="mr-2"></Button>
                <Button onClick={confirm2} icon="pi pi-times" label="Delete"></Button>
                <Button onClick={confirm3} icon="pi pi-times" label="Delete"></Button>
            </div>
        </>
    )
}
        
        