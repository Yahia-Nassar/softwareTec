import React, { useState } from 'react';

export default function DeleteMeeting({ meeting, setMeetings, projectId, closeModal }) {
  const [showModal, setShowModal] = useState(false);


  const handleDelete = (event) => {
    event.preventDefault();
    fetch(`http://localhost:8080/deletemeeting?projectid=${projectId}&meetingId=${meeting.meetingId}`, {
      method: 'POST',
      credentials: 'include',
      headers: {
        'Content-Type': 'application/json',
      }
    })
    .then((res) => {
      if (!res.ok) {
        throw new Error('Fehler beim Löschen');
      }
      return res.json();
    })
    .then((updatedMeetings) => {
      setMeetings(updatedMeetings);
      if (closeModal) closeModal(); 
    })
    .catch((err) => {
      console.error('Fehler beim Löschen:', err);
    });
  };

  return (
    <button onClick={handleDelete}>Delete</button>
  );
}
