import React, { useState } from "react";
import Popup from 'reactjs-popup';
import { FiTrash } from "react-icons/fi";
import 'reactjs-popup/dist/index.css';
import { useParams } from 'react-router-dom';
import { notify } from './Notification';
import { useEffect } from "react";

const DeleteTask = ({ columnName, setCards, UserStory }) => {
    const { projectId } = useParams();

    const handleDelete = () => {

        setCards(prevCards => {
            const updatedCards = prevCards.map(card => 
                card.id === UserStory.id ? { ...card, status: "BURNBARREL" } : card
            );

        fetch(`http://localhost:8080/saveTasks?projectid=${projectId}`, {
            method: 'POST',
            credentials: 'include',
            headers: {
              'Content-Type': 'application/json'
            },
            body: JSON.stringify(updatedCards)
          })
          .then(response => response.json())
          .catch((error) => {
            console.error('Fehler:', error);
          })
          .then(() => {
          setCards(current => current.filter(card => card.id !== UserStory.id));
          });

          return(updatedCards);
        });

    };

    return(
        <Popup 
            trigger={
                <button className="flex items-center gap-1.5 px-3 py-1.5 text-xs text-neutral-400 transition-colors hover:text-neutral-50">
                    Delete <FiTrash />
                </button>
            } 
            modal 
            nested
            contentStyle={{ background: 'rgba(255, 255, 255, 0)', border: 'none', padding: '0' }}
            overlayStyle={{ background: 'rgba(57, 57, 57, 0.5)' }}
        >
            {close => (
                <div className="fixed inset-0 bg-[#121629]/80 flex items-center justify-center p-4 z-50">
                    <div className="bg-[#232946] rounded-lg p-6 w-fit max-w-2xl mx-auto border-none shadow-none max-h-screen overflow-y-auto">
                        <div className="flex flex-col space-y-4 p-3">
                         <label className="flex flex-col">
                             Are you sure you want to delete this Task?
                        </label> 
                        </div>
                        <div className="flex justify-end space-x-2 mt-4">
                            <button 
                                type='button' 
                                onClick={() => {
                                    handleDelete();
                                    close();
                                }}  
                                className="px-4 py-2 bg-[#121629] text-white rounded">
                                Delete
                            </button>
                            <button 
                                type='button' 
                                onClick={close} 
                                className="px-4 py-2 bg-[#121629] text-white rounded">
                                Cancel
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </Popup>
      );
    };

export default DeleteTask;