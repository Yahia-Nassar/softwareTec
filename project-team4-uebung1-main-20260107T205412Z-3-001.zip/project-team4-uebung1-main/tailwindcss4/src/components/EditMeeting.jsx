import React, { useState } from 'react';
import { useEffect } from 'react';

export default function EditMeeting({ meeting, setMeetings, projectId }) {
  const [showModal, setShowModal] = useState(false);
  const [localMeeting, setLocalMeeting] = useState(meeting);
  const [allMembers, setAllMembers] = useState([]);

  useEffect(() => {
    fetch(`http://localhost:8080/getprojectusers?projectid=${projectId}`, {
      credentials: 'include',
      method: 'GET',
    })
      .then((res) => res.json())
      .then((data) => setAllMembers(data))
      .catch((err) => console.error("Error fetching Teammembers:", err));
  }, [projectId]);

  const handleSave = () => {
    fetch(`http://localhost:8080/editmeeting?projectid=${projectId}`, {
      method: 'PUT',
      credentials: 'include',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(localMeeting),
    })
      .then((res) => res.json())
      .then((updatedMeetings) => {
        setMeetings(updatedMeetings); 
        setShowModal(false); 
      })
      .catch((err) => {
        console.error('Error while deleting:', err);
      });
    };    

  return (
    <>
      <button
        onClick={() => setShowModal(true)}
        className="px-3 py-1 bg-[#EEBBC3] text-[#121629] rounded hover:opacity-80"
      >
        Edit
      </button>
      {showModal && (
        <div className="fixed inset-0 flex items-center justify-center bg-[#121629]/80 p-4 z-50">
          <div className="bg-[#232946] p-6 w-80 rounded shadow-md text-white">
            <h2 className="text-xl font-bold mb-4">Edit Meeting</h2>
            <input
              type="text"
              className="border border-transparent p-2 mb-2 w-full bg-[#121629] text-white rounded"
              value={localMeeting.description}
              onChange={(e) =>
                setLocalMeeting({ ...localMeeting, description: e.target.value })
              }
            />
            <input
              type="date"
              className="border border-transparent p-2 mb-2 w-full bg-[#121629] text-white rounded"
              value={localMeeting.date}
              onChange={(e) =>
                setLocalMeeting({ ...localMeeting, date: e.target.value })
              }
            />
            <input
              type="time"
              className="border border-transparent p-2 mb-4 w-full bg-[#121629] text-white rounded"
              value={localMeeting.time}
              onChange={(e) =>
                setLocalMeeting({ ...localMeeting, time: e.target.value })
              }
            />
            <select
          multiple
          value={localMeeting.participants}
          onChange={(e) => {
            const selected = Array.from(e.target.selectedOptions, (opt) => opt.value);
            if (selected.includes("__all__")) {
              const emailsOnly = allMembers.map((user) => user.email);
              setLocalMeeting((prev) => ({ ...prev, participants: emailsOnly }));
            } else {
              setLocalMeeting((prev) => ({ ...prev, participants: selected }));
            }
          }}
          className="bg-[#121629] text-white p-2 rounded mb-2 w-full"
        >
          <option value="__all__">All members</option>
          {allMembers.map((user) => (
            <option key={user.email} value={user.email}>
              {user.username} ({user.email})
            </option>
          ))}
        </select>

        <div className="mb-4">
          Participants:{' '}
          {Array.isArray(localMeeting.participants) && localMeeting.participants.length > 0
            ? localMeeting.participants
                .map((email) => {
                  const user = allMembers.find((u) => u.email === email);
                  return user ? `${user.username} (${user.email})` : email;
                })
                .join(', ')
            : 'None'}
        </div>
            <div className="flex justify-end">
              <button
                onClick={() => setShowModal(false)}
                className="mr-2 px-4 py-2 bg-gray-300 text-[#121629] rounded hover:opacity-80"
              >
                Cancel
              </button>
              <button
                onClick={handleSave}
                className="px-4 py-2 bg-[#EEBBC3] text-[#121629] rounded hover:opacity-80"
              >
                Save
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}