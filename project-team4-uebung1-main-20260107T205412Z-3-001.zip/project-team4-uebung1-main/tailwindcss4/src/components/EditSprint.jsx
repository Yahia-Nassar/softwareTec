import React, { useState } from 'react';
import { CiEdit } from "react-icons/ci";

export default function EditSprint({ sprint, projectId }) {
  const [showModal, setShowModal] = useState(false);
  const [localSprint, setLocalSprint] = useState(sprint);

  const handleSave = () => {
    fetch(`http://localhost:8080/editSprint?projectId=${projectId}`, {
      method: 'PUT',
      credentials: 'include',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(localSprint),
    })
      .then((res) => res.json())
      .then((updatedSprint) => {
        setLocalSprint(updatedSprint);
        setShowModal(false);      
      })
      .catch((err) => {
        console.error('Fehler beim Bearbeiten:', err);
      });
  };

  return (
    <>
      <button
        onClick={() => {
          setLocalSprint(sprint);
          setShowModal(true);
        }}
        className="p-2 text-white! bg-transparent! rounded"
      >
        <CiEdit size={20} />
      </button>

      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#232946] bg-opacity-80">
          <div className="bg-[#121629] p-6 w-80 rounded shadow-md text-white">
            <h2 className="text-xl font-bold mb-4">Edit Sprint</h2>

            <input
              type="text"
              className="border border-transparent p-2 mb-2 w-full bg-[#232946] text-white rounded"
              value={localSprint.name}
              onChange={(e) =>
                setLocalSprint({ ...localSprint, name: e.target.value })
              }
            />

            <input
              type="date"
              className="border border-transparent p-2 mb-2 w-full bg-[#232946] text-white rounded"
              value={localSprint.startDate}
              onChange={(e) =>
                setLocalSprint({ ...localSprint, startDate: e.target.value })
              }
            />

<input
              type="date"
              className="border border-transparent p-2 mb-2 w-full bg-[#232946] text-white rounded"
              value={localSprint.endDate}
              onChange={(e) =>
                setLocalSprint({ ...localSprint, startDate: e.target.value })
              }
            />

            <div className="flex justify-end">
              <button
                onClick={() => setShowModal(false)}
                className="mr-2 px-4 py-2 bg-gray-300 text-[#121629] rounded hover:opacity-80"
              >
                Cancel
              </button>
              <button
                onClick={handleSave}
                className="px-4 py-2 bg-[#EEBBC3] text-[#121629] rounded hover:opacity-80"
              >
                Save
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}