import { useEffect, useRef, useState } from "react";
import { useLocation } from "react-router-dom";
import dayjs from "dayjs";
import { notify } from "./Notification";

//Trace: "MeetingReminder" in https://git.informatik.uni-rostock.de/softwaretechnik-ws-2024-25/uebung1/team4/abgabedokument-sprint-4/-/blob/5f41bdf8c1770d6e342ab58ddca00db73b12077c/Klassendiagramm_Sprint_4.svg

const MeetingReminder = () => {
  const [meetings, setMeetings] = useState([]);
  const [meetingNotification, setMeetingNotification] = useState(null);
  const notifiedRef = useRef(new Set());
  const projectId = useLocation().pathname.split("/")[1];

  useEffect(() => {
    if (!projectId) return;

    fetch(`http://localhost:8080/getmeetingnotification?projectid=${projectId}`, {
      credentials: "include",
    })
        .then((r) => {
          if (!r.ok) throw new Error();
          return r.json();
        })
        .then((n) => setMeetingNotification(Number(n ?? 60)))
        .catch(() => setMeetingNotification(60));
  }, [projectId]);

  useEffect(() => {
    if (!projectId || meetingNotification == null) return;

    const checkInterval = 60_000;

    const fetchAndCheck = () => {
      fetch(`http://localhost:8080/getmeetings?projectid=${projectId}`, {
        credentials: "include",
      })
          .then((r) => {
            if (!r.ok) throw new Error();
            return r.json();
          })
          .then((data) => {
            setMeetings(data);
            const now = dayjs();
            data.forEach((m) => {
              const start = dayjs(`${m.date} ${m.time}`, "YYYY-MM-DD HH:mm");
              const remindAt = start.subtract(meetingNotification, "minutes");
              const diff = remindAt.diff(now);
              const key = m.id ?? `${m.date}-${m.time}-${m.description}`;
              if (Math.abs(diff) <= checkInterval && !notifiedRef.current.has(key)) {
                notify.success(`Meeting in ${meetingNotification} minutes!\nTopic: ${m.description}`);
                notifiedRef.current.add(key);
              }
            });
          })
          .catch((e) => console.error("Error fetching meetings:", e));
    };

    fetchAndCheck();
    const id = setInterval(fetchAndCheck, checkInterval);
    return () => clearInterval(id);
  }, [projectId, meetingNotification]);

  return null;
};

export default MeetingReminder;