import React, { useState } from 'react';

export default function NewProject({ onCreate, onCancel }) {
    const [projectName, setProjectName] = useState('');

    const handleSubmit = (e) => {
        e.preventDefault();
        if (projectName) {
            onCreate(projectName); 
            setProjectName(''); 
        }
    };

    return (
        <div className="project-container">
            <div className="project-title">Neues Projekt erstellen</div>
            <div className="add-project-rectangle">
                <form onSubmit={handleSubmit}>
                    <input
                        type="text"
                        placeholder="Projektname"
                        value={projectName}
                        onChange={(e) => setProjectName(e.target.value)}
                        className="border border-gray-300 p-2 mb-4 w-full"
                    />
                    <button
                        type="submit"
                        className="bg-blue-500 text-white p-2 rounded w-full hover:bg-blue-600"
                    >
                        Projekt erstellen
                    </button>
                </form>
                <button
                    onClick={onCancel}
                    className="mt-4 text-blue-500 hover:underline"
                >
                    Abbrechen
                </button>
            </div>
        </div>
    );
}