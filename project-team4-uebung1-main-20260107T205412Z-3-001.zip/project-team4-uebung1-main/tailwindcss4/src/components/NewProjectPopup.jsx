import React, { useState } from 'react';
import Popup from 'reactjs-popup';
import 'reactjs-popup/dist/index.css';

export default function NewProjectPopup({ onCreate }) {
    const [projectName, setProjectName] = useState('');

    const handleSubmit = (e, close) => {
        e.preventDefault();
        if (projectName) {
            onCreate(projectName);
            setProjectName(projectName);
            close();
        }
    };

    return (
        <Popup 
            className="custom-popup"
            trigger={<button style={{ width: '100%', backgroundColor: '#EEBBC3', color: '#232946', border: 'none', padding: '15px', borderRadius: '5px', marginTop: '10px', cursor: 'pointer', fontFamily: 'Inter, sans-serif, bold' }}>+ Add project</button>} 
            modal 
            nested
        >
            {close => (
                <div style={{
                    border: '1px solid transparent',
                    backgroundColor: '#232946',
                    color: 'white', 
                    padding: '20px',
                    borderRadius: '8px',
                    textAlign: 'left', 
                }}>
                    <h4 style={{ marginBottom: '20px' }}>Create Project</h4>
                    <form onSubmit={(e) => handleSubmit(e, close)} >
                        <input
                            type="text"
                            placeholder="Project Name"
                            value={projectName}
                            onChange={(e) => setProjectName(e.target.value)}
                            required
                            style={{
                                border: '1px solid #ccc',
                                borderRadius: '5px',
                                padding: '10px',
                                width: '100%',
                                marginBottom: '20px',
                                backgroundColor: '#fff', 
                                color: '#232946' 
                            }}
                        />
                        <button 
                            type="submit" 
                            style={{
                                backgroundColor: '#EEBBC3', 
                                color: '#232946',
                                padding: '10px',
                                border: 'none',
                                borderRadius: '5px',
                                width: '100%',
                                cursor: 'pointer',
                                fontSize: '16px'
                            }}
                        >
                            Create Project
                            
                        </button>
                        <button 
                            onClick={close} 
                            style={{
                                marginTop: '10px',
                                backgroundColor: 'transparent',
                                color: '#EEBBC3', 
                                border: 'none',
                                cursor: 'pointer',
                                textDecoration: 'underline'
                            }}
                        >
                            Cancel
                        </button>
                    </form>
                </div>
            )}
        </Popup>
    );
}