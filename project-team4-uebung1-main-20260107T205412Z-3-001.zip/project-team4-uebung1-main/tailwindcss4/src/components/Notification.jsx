import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { Bounce } from 'react-toastify';

//Trace: "Notification" in https://git.informatik.uni-rostock.de/softwaretechnik-ws-2024-25/uebung1/team4/abgabedokument-sprint-4/-/blob/5f41bdf8c1770d6e342ab58ddca00db73b12077c/Klassendiagramm_Sprint_4.svg

export const notify = {
    reminder: (message) => toast.info(message, { autoClose: false, closeOnClick: false, hideProgressBar: true,  
      style: {
        color: '#60a5fa',
      },
    }),
    success: (message) => toast.success(message),
    error: (message) => toast.error(message),
  };

const Notification = () => {
     return (
       <ToastContainer
         position="top-right"
         autoClose={5000}
         hideProgressBar={false}
         newestOnTop={false}
         closeOnClick
         rtl={false}
         pauseOnFocusLoss
         draggable
         pauseOnHover
         theme="dark"
         transition={Bounce}
       />
     );
   };

export default Notification;