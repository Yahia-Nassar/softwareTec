const PageWrapper = ({ children }) => {
  return (
    <div className="min-h-screen flex justify-center items-center bg#121629">
      <div className="w-full max-w-xl p-8 bg-#121629 rounded-lg shadow-lg">
        {children}
      </div>
    </div>
  );
};

export default PageWrapper;
