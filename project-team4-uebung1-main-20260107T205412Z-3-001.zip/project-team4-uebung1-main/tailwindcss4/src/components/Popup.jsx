import React, { useState } from 'react';
import Popup from 'reactjs-popup';
import 'reactjs-popup/dist/index.css';

export default function Popup() {
    const [title, setTitle] = useState('');
    const [description, setDescription] = useState('');
    const [type, setType] = useState('task');

    const handleSubmit = (e) => {
        e.preventDefault();
        console.log(`Neuer ${type}:`, title, description);
        setTitle('');
        setDescription('');
    };

    return (
        <div>
            <h4>Aufgabe oder Benutzer-Story hinzufügen</h4>
            <Popup trigger={<button> Öffne Formular </button>} modal nested>
                {close => (
                    <div className='modal'>
                        <form onSubmit={handleSubmit}>
                            <div className='content'>
                                <label>
                                    Titel:
                                    <input 
                                        type='text' 
                                        value={title} 
                                        onChange={(e) => setTitle(e.target.value)} 
                                        required 
                                    />
                                </label>
                                <label>
                                    Beschreibung:
                                    <textarea 
                                        value={description} 
                                        onChange={(e) => setDescription(e.target.value)} 
                                        required 
                                    />
                                </label>
                                <label>
                                    Typ:
                                    <select value={type} onChange={(e) => setType(e.target.value)}>
                                        <option value='task'>Aufgabe</option>
                                        <option value='userStory'>Benutzer-Story</option>
                                    </select>
                                </label>
                            </div>
                            <div>
                                <button type='submit'>Hinzufügen</button>
                                <button onClick={close}>Schließen</button>
                            </div>
                        </form>
                    </div>
                )}
            </Popup>
        </div>
    );
}