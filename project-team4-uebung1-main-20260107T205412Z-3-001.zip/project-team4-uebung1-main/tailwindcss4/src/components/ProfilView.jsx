import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";

const meetingMap = { None: 0, "0.5 hour": 30, "1 hour": 60, "3 hours": 180 };
const meetingReverse = { 0: "None", 30: "0.5 hour", 60: "1 hour", 180: "3 hours" };
const taskMap = { None: 0, "1 day": 1, "2 days": 2, "3 days": 3 };
const taskReverse = { 0: "None", 1: "1 day", 2: "2 days", 3: "3 days" };

const ProfilView = () => {
    const { projectId } = useParams();
    const [editMode, setEditMode] = useState(false);
    const [role, setRole] = useState("DEVELOPER");
    const [tempRole, setTempRole] = useState(role);
    const [meetingNotification, setMeetingNotification] = useState("1 hour");
    const [taskNotification, setTaskNotification] = useState("1 day");
    const [tempMeeting, setTempMeeting] = useState(meetingNotification);
    const [tempTask, setTempTask] = useState(taskNotification);
    const [userName, setUserName] = useState("NAME");
    const [email, setEmail] = useState("[E-mail address]");
    const [error, setError] = useState(null);

    const handleSave = async () => {
        setRole(tempRole);
        setMeetingNotification(tempMeeting);
        setTaskNotification(tempTask);
        const meetingVal = meetingMap[tempMeeting];
        const taskVal = taskMap[tempTask];
        setEditMode(false);
        const mapToEnum = (v) => (v === "DEVELOPER" ? "DEVELOPER" : "PRODUCT_OWNER");
        await fetch(`http://localhost:8080/editrole?projectid=${projectId}`, {
            method: "POST",
            credentials: "include",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ role: mapToEnum(tempRole) }),
        });
        await fetch(`http://localhost:8080/editmeetingnotification?projectid=${projectId}`, {
            method: "POST",
            credentials: "include",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(meetingVal),
        });
        await fetch(`http://localhost:8080/edittasknotification?projectid=${projectId}`, {
            method: "POST",
            credentials: "include",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(taskVal),
        });
    };

    useEffect(() => {
        fetch("http://localhost:8080/getUsername", { credentials: "include" })
            .then((r) => r.text())
            .then(setUserName);
        fetch("http://localhost:8080/getUserEmail", { credentials: "include" })
            .then((r) => r.text())
            .then(setEmail);
        fetch(`http://localhost:8080/gettasknotification?projectid=${projectId}`, { credentials: "include" })
            .then((r) => r.json())
            .then((d) => {
                const label = taskReverse[d] || "1 day";
                setTaskNotification(label);
                setTempTask(label);
            });
        fetch(`http://localhost:8080/getmeetingnotification?projectid=${projectId}`, { credentials: "include" })
            .then((r) => r.json())
            .then((d) => {
                const label = meetingReverse[d] || "1 hour";
                setMeetingNotification(label);
                setTempMeeting(label);
            });
        fetch(`http://localhost:8080/getRole?projectid=${projectId}`, { credentials: "include" })
            .then((r) => r.json())
            .then((d) => {
                setRole(d);
                setTempRole(d);
            });
    }, [projectId]);

    if (error) return <div>{error}</div>;

    return (
        <div style={{ padding: "5rem", backgroundColor: "#232946", minHeight: "100vh", color: "#ffffff" }}>
            <style>{`
        .save-btn{background-color:#EEBBC3;color:#232946;cursor:pointer;border:2px solid transparent;padding:0.4rem 1rem;border-radius:0.5rem;transition:border-color .25s;}
        .save-btn:hover{border-color:#646cff;}
        .toggle-button{background-color:#121629!important;border:none!important;padding:0!important;}
        .toggle-button:hover{background-color:#121629!important;}
        .toggle-button.absolute{background-color:#121629!important;}
      `}</style>
            <div style={{ minWidth: "900px", minHeight: "600px", backgroundColor: "#101324", borderRadius: "1.5rem", overflow: "hidden", position: "relative" }}>
                <div style={{ backgroundColor: "#14182d", height: "150px", display: "flex", alignItems: "center", justifyContent: "center" }}>
                    <h2 style={{ fontSize: "2.5rem", fontWeight: "bold" }}>{userName}</h2>
                </div>
                <div style={{ padding: "2rem" }}>
                    <div style={{ marginBottom: "1.25rem" }}>
                        <p style={{ fontSize: "1rem", color: "#b0b0b0" }}>{email}</p>
                        <p style={{ fontSize: "1rem", color: "#b0b0b0" }}>{role}</p>
                    </div>
                    <div style={{ position: "relative" }}>
                        {editMode ? (
                            <>
                                <select value={tempRole} onChange={(e) => setTempRole(e.target.value)} style={{ width: "100%", marginBottom: ".75rem", padding: ".6rem", backgroundColor: "#1e1f22", color: "#ffffff", border: "1px solid #444", borderRadius: ".6rem" }}>
                                    <option value="DEVELOPER">DEVELOPER</option>
                                    <option value="PRODUCT_OWNER">PRODUCT_OWNER</option>
                                </select>
                                <h3 style={{ fontSize: "1.3rem", fontWeight: "bold", marginBottom: ".6rem" }}>Meeting notifications</h3>
                                <select value={tempMeeting} onChange={(e) => setTempMeeting(e.target.value)} style={{ width: "100%", marginBottom: ".75rem", padding: ".6rem", backgroundColor: "#1e1f22", color: "#ffffff", border: "1px solid #444", borderRadius: ".6rem" }}>
                                    <option value="None">No notifications</option>
                                    <option value="0.5 hour">30 minutes before</option>
                                    <option value="1 hour">1 hour before</option>
                                    <option value="3 hours">3 hours before</option>
                                </select>
                                <h3 style={{ fontSize: "1.3rem", fontWeight: "bold", marginBottom: ".6rem" }}>Task notifications</h3>
                                <select value={tempTask} onChange={(e) => setTempTask(e.target.value)} style={{ width: "100%", marginBottom: ".75rem", padding: ".6rem", backgroundColor: "#1e1f22", color: "#ffffff", border: "1px solid #444", borderRadius: ".6rem" }}>
                                    <option value="None">No notifications</option>
                                    <option value="1 day">1 day before</option>
                                    <option value="2 days">2 days before</option>
                                    <option value="3 days">3 days before</option>
                                </select>
                                <button onClick={handleSave} className="save-btn">Save</button>
                            </>
                        ) : (
                            <>
                                <div style={{ marginBottom: ".6rem" }}>
                                    <h3 style={{ fontSize: "1.1rem", fontWeight: "bold" }}>Meeting notifications</h3>
                                    <p style={{ fontSize: "1rem", color: "#d0d0d0" }}>{meetingNotification}</p>
                                </div>
                                <div style={{ marginBottom: ".6rem" }}>
                                    <h3 style={{ fontSize: "1.1rem", fontWeight: "bold" }}>Task notifications</h3>
                                    <p style={{ fontSize: "1rem", color: "#d0d0d0" }}>{taskNotification}</p>
                                </div>
                            </>
                        )}
                    </div>
                </div>
                <button
                    onClick={() => {
                        setTempRole(role);
                        setTempMeeting(meetingNotification);
                        setTempTask(taskNotification);
                        setEditMode(true);
                    }}
                    className="toggle-button absolute"
                    style={{ bottom: "2rem", right: "2rem", position: "absolute", background: "transparent", border: "none", cursor: "pointer" }}
                >
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="#EEBBC3" strokeWidth={1.5} width="32" height="32">
                        <path strokeLinecap="round" strokeLinejoin="round" d="m16.862 4.487 1.687-1.688a1.875 1.875 0 1 1 2.652 2.652L10.582 16.07a4.5 4.5 0 0 1-1.897 1.13L6 18l.8-2.685a4.5 4.5 0 0 1 1.13-1.897l8.932-8.931Zm0 0L19.5 7.125M18 14v4.75A2.25 2.25 0 0 1 15.75 21H5.25A2.25 2.25 0 0 1 3 18.75V8.25A2.25 2.25 0 0 1 5.25 6H10" />
                    </svg>
                </button>
            </div>
        </div>
    );
};

export default ProfilView;