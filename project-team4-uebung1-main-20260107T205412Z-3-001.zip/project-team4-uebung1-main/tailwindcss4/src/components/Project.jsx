import React from 'react';

const Project = ({ project, onClick }) =>{
  return (
    <div className="fproject-container">
      <div className="project-title">Select your projects</div>
      <div className ="project-rectangle"
        onClick={onClick}> {project.name}
      </div>
    </div>
  );
}

export default Project;