import React, { useState } from "react";

//Trace: "SearchFilterSortPanel" in https://git.informatik.uni-rostock.de/softwaretechnik-ws-2024-25/uebung1/team4/abgabedokument-sprint-4/-/blob/5f41bdf8c1770d6e342ab58ddca00db73b12077c/Klassendiagramm_Sprint_4.svg

export default function SearchFilterSortPanel({ fields, getItems, onFilteredItems }) {
    const [searchQuery, setSearchQuery] = useState("");
    const [activeFilters, setActiveFilters] = useState({});

    function handleSearch(query) {
        setSearchQuery(query);
        applyFilter(query, activeFilters);
    }

    function handleFilterChange(filterName, value) {
        const updatedFilters = { ...activeFilters, [filterName]: value };
        setActiveFilters(updatedFilters);
        applyFilter(searchQuery, updatedFilters);
    }

    function applyFilter(query, filters) {
        const items = getItems() || [];
        let filtered = items;

        if (query) {
            filtered = filtered.filter((item) =>
                item.title?.toLowerCase().includes(query.toLowerCase()) ||
                item.userStoryTitle?.toLowerCase().includes(query.toLowerCase())
            );
        }

        Object.entries(filters).forEach(([key, value]) => {
            if (value) {
            filtered = filtered.filter((item) => {
                if (key === "assignedUsers") {
                    const assignedUsersString = (item.userInfos || [])
                      .map(u => u.name.toLowerCase())
                      .join(" ");
                    return assignedUsersString.includes(value.toLowerCase());
                } else {
                    const itemValue = item[key];
                    if (typeof itemValue === "string") {
                        return itemValue.toLowerCase().includes(value.toLowerCase());
                    }
                    return itemValue === value;
                }
            });
            }
        });

        onFilteredItems(filtered);
    }

    return (
        <div className="bg-[#121629] p-4 flex flex-wrap gap-2 rounded-md mb-4">
            <input
                type="text"
                placeholder="Search..."
                value={searchQuery}
                onChange={(e) => handleSearch(e.target.value)}
                className="bg-[#232946] text-white p-2 rounded-md"
            />

            {fields
                .filter((field) => field.type === "text")
                .map((field) => (
                    <input
                    key={field.name}
                    type="text"
                    placeholder={field.label}
                    value={activeFilters[field.name] || ""}
                    onChange={(e) => handleFilterChange(field.name, e.target.value)}
                    className="bg-[#232946] text-white p-2 rounded-md"
                    />
                ))}

            {fields
                .filter((field) => field.type === "select")
                .map((field) => (
                    <select
                        key={field.name}
                        onChange={(e) => handleFilterChange(field.name, e.target.value)}
                        className="bg-[#232946] text-white p-2 rounded-md"
                    >
                        <option value="">{field.name} (all)</option>
                        {field.options.map((opt) => {
                            const optionValue = typeof opt === "object" ? opt.value : opt;
                            const optionLabel = typeof opt === "object" ? opt.label : opt;
                            return (
                                <option value={optionValue} key={optionValue}>
                                    {optionLabel}
                                </option>
                            );
                        })}
                    </select>
                ))}
        </div>
    );
}