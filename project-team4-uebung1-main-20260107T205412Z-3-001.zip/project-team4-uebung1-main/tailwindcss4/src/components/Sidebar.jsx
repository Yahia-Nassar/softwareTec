import React, { useState } from "react";
import {
  FiCalendar,
  FiLayout,
  FiChevronDown,
  FiChevronsRight,
  FiClipboard,
  FiHome,
  FiUser,
  FiUsers,
  FiLogOut,
  FiList,
  FiWind,
} from "react-icons/fi";
import { motion } from "framer-motion";
import { useNavigate } from 'react-router-dom';
import { useParams } from 'react-router-dom';

//Trace: "Sidebar", "Option" in https://git.informatik.uni-rostock.de/softwaretechnik-ws-2024-25/uebung1/team4/abgabedokument-sprint-4/-/blob/5f41bdf8c1770d6e342ab58ddca00db73b12077c/Klassendiagramm_Sprint_4.svg

const Sidebar = () => {
  const [open, setOpen] = useState(true);
  const [selected, setSelected] = useState("Dashboard");
  const navigate = useNavigate();
  const { projectId } = useParams();

  return (
    <motion.nav
      layout
      className="sticky top-0 h-screen shrink-0 bg #232946 p-2 border-transparent border-r"
      style={{
        width: open ? "225px" : "fit-content",
      }}
    >
      <TitleSection open={open} />

      <div className="space-y-1">
        <Option
          Icon={FiHome}
          title="Dashboard"
          selected={selected}
          setSelected={setSelected}
          open={open}
          onClick= {() => {
            navigate(`/${projectId}/dashboard`);
          }}
        />
        <Option
          Icon={FiClipboard}
          title="Projectbacklog"
          selected={selected}
          setSelected={setSelected}
          open={open}
          onClick= {() => {
            navigate(`/${projectId}/USView`);
          }}
        />
        <Option
          Icon={FiLayout}
          title="Sprintboard"
          selected={selected}
          setSelected={setSelected}
          open={open}
          onClick= {() => {
            navigate(`/${projectId}/sprintboard`);
          }}
        />
        <Option
          Icon={FiWind}
          title="Sprintbacklog"
          selected={selected}
          setSelected={setSelected}
          open={open}
          onClick= {() => {
            navigate(`/${projectId}/SprintView`)
          }}
        />
        <Option
          Icon={FiUsers}
          title="Team"
          selected={selected}
          setSelected={setSelected}
          open={open}
          onClick={() =>{
            navigate(`/${projectId}/team`);
          }}
        />
        <Option
          Icon={FiCalendar}
          title="Meetings"
          selected={selected}
          setSelected={setSelected}
          open={open}
          onClick= {() => {
            navigate(`/${projectId}/meetings`);
          }}
        />
        <Option
          Icon={FiUser}
          title="Profile"
          selected={selected}
          setSelected={setSelected}
          open={open}
          onClick={() =>{
            navigate(`/${projectId}/profil`);
          }}
        />
        <Option
          Icon={FiList}
          title="Projects"
          selected={selected}
          setSelected={setSelected}
          open={open}
          onClick={() => {
            navigate(`/projectselection`);
          }}
        />
        <Option
          Icon={FiLogOut}
          title="Logout"
          selected={selected}
          setSelected={setSelected}
          open={open}
          onClick={() => {
            fetch('http://localhost:8080/logout', {
              method: 'GET',
              credentials: 'include',
            })
              .then((response) => {
                window.location.href = 'http://localhost:8080/req/login';
              })
              .catch((error) => {
                console.error('Fehler beim Logout:', error);
              });
          }}
        />
      </div>

      <ToggleClose open={open} setOpen={setOpen} />
    </motion.nav>
  );
};

const Option = ({ Icon, title, selected, setSelected, open, notifs, onClick }) => {
  const handleClick = () => {
    setSelected(title);
    if (onClick) {
      onClick();
    }
  }
  
  return (
    <motion.button
      layout
      onClick={handleClick}
      className={`relative flex h-10 w-full items-center rounded-md transition-colors ${selected === title ? "bg #232946 text#232946" : "text#232946 hover:bg-indigo-100"}`}
    >
      <motion.div
        layout
        className="grid h-full w-10 place-content-center text-#232946"
      >
        <Icon />
      </motion.div>
      {open && (
        <motion.span
          layout
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.125 }}
          className="text-xs font-medium"
        >
          {title}
        </motion.span>
      )}

      {notifs && open && (
        <motion.span
          initial={{ scale: 0, opacity: 0 }}
          animate={{
            opacity: 1,
            scale: 1,
          }}
          style={{ y: "-50%" }}
          transition={{ delay: 0.5 }}
          className="absolute right-2 top-1/2 size-4 rounded bg #232946 text-xs text #232946"
        >
          {notifs}
        </motion.span>
      )}
    </motion.button>
  );
};

const TitleSection = ({ open }) => {
  return (
    <div className="mb-3 bg- #232946 pb-3">
      <div className="flex cursor-pointer items-center justify-between rounded-md transition-colors hover: bg #232946">
        <div className="flex items-center gap-2">
          {open && (
            <motion.div
              layout
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.125 }}
            >
            </motion.div>
          )}
        </div>
      </div>
    </div>
  );
};

const ToggleClose = ({ open, setOpen }) => {
  return (
    <motion.button
      layout
      onClick={() => setOpen((pv) => !pv)}
      className="toggle-button absolute bottom-0 left-0 right-0 transition-colors"
    >
      <div className="flex items-center p-2">
        <motion.div
          layout
          className="grid size-10 place-content-center text-white"
        >
          <FiChevronsRight
            className={`transition-transform ${open && "rotate-180"}`}
          />
        </motion.div>
        {open && (
          <motion.span
            layout
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.125 }}
            className="text-xs font-medium text-white"
          >
            Hide
          </motion.span>
        )}
      </div>
    </motion.button>
  );
};

export default Sidebar;