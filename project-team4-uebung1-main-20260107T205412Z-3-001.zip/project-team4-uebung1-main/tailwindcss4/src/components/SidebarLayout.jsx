import React , { useState }from 'react';
import Sidebar from './Sidebar';
import { motion } from "framer-motion";

//Trace: "Sidebar" in https://git.informatik.uni-rostock.de/softwaretechnik-ws-2024-25/uebung1/team4/abgabedokument-sprint-4/-/blob/5f41bdf8c1770d6e342ab58ddca00db73b12077c/Klassendiagramm_Sprint_4.svg

const SidebarLayout = ({ children }) => {
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const contentOffset = sidebarOpen ? 80 : 32;

  return (
    <div className="flex">
      <Sidebar open={sidebarOpen} setOpen={setSidebarOpen} />
      <motion.div
        style={{ flexGrow: 1 }}
        animate={{ marginLeft: contentOffset}}
        transition={{ duration: 0.3, ease: "easeInOut" }}
      >
        {React.cloneElement(children, { sidebarOpen })}
      </motion.div>
    </div>
  );
};

export default SidebarLayout;