import { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { notify } from "./Notification";
import AddTask from './AddTask';
import { FiEdit } from 'react-icons/fi';
import { TaskDetails } from './TaskDetails';
import { confirm3 } from "./Confirmbox.jsx";
import DeleteTask from './DeleteTask.jsx';
import SearchFilterSortPanel from "./SearchFilterSortPanel";
import ViewSwitch from './ViewSwitch.jsx';
import { motion } from 'framer-motion';

//Trace: "SprintBacklog" in https://git.informatik.uni-rostock.de/softwaretechnik-ws-2024-25/uebung1/team4/abgabedokument-sprint-4/-/blob/5f41bdf8c1770d6e342ab58ddca00db73b12077c/Klassendiagramm_Sprint_4.svg

export const SprintBacklog = ({ isKanbanView, onSwitch , sidebarOpen}) => {
  const { projectId } = useParams();
  const [status, setStatus] = useState('BACKLOG');
  const [allCards, setAllCards] = useState([]);
  const [filteredCards, setFilteredCards] = useState([]);
  const [selectedSprint, setSelectedSprint] = useState(1);
  const [sprints, setSprints] = useState([]);
  const [editTask, setEditTask] = useState(null);

  useEffect(() => {
    const fetchSprints = async () => {
      const response = await fetch(`http://localhost:8080/getsprints?projectId=${projectId}`, {
        method: 'GET',
        credentials: 'include',
      });
      if (response.ok) setSprints(await response.json());
    };
    if (projectId) fetchSprints();
  }, [projectId]);

  useEffect(() => {
    const fetchData = async () => {
      const res = await fetch(`http://localhost:8080/getsprinttasks?projectid=${projectId}&sprintid=${selectedSprint}`, {
        method: 'GET',
        credentials: 'include',
      });
      if (!res.ok) return;
      const data = await res.json();
      const tasks = data.map(c => ({ ...c, type: 'task', frontendID: 'task-'+c.id, userStoryTitle: c.userStory?.title || "", }));
      setAllCards(tasks);
      setFilteredCards(tasks);
      localStorage.setItem('cards', JSON.stringify(tasks));
    };
    fetchData();
  }, [projectId, selectedSprint]);

  const handleFilteredItems = (items) => setFilteredCards(items);

  const handleSave = async () => {
    const hasBurn = allCards.some(c => c.type === 'task' && c.status === 'BURNBARREL');
    if (hasBurn && !(await confirm3())) return;

    const tasksToSave = allCards.map(t => {
      const minimalUsers = (t.users || []).map(u => ({ id: u.id }));
      const userStory = typeof t.userStory === 'string' && !t.userStory.trim() ? null : t.userStory;
      return { ...t, sprint: { sprintid: selectedSprint }, userStory, users: minimalUsers };
    });

    await fetch(`http://localhost:8080/saveTasks?projectid=${projectId}`, {
      method: 'POST',
      credentials: 'include',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(tasksToSave),
    });
    notify.success("saved!");
  };

  const handleTaskUpdate = (updatedTask) => {
    const newCards = allCards.map(c => c.id === updatedTask.id ? { ...c, ...updatedTask } : c);
    setAllCards(newCards);
    setFilteredCards(newCards);
    setEditTask(null);
  };

  return (
    <motion.div
    className="transition"
    initial={false}
    animate={{
      width: sidebarOpen ? "calc(100% - 225px)" : "calc(100% - 64px)",
    }}
    transition={{ duration: 0.3, ease: "easeInOut" }}
    style={{ marginTop: '30px' }}
  >
      <div style={{marginTop: '30px', marginLeft: sidebarOpen ? '225px' : '64px'}}>
        <SearchFilterSortPanel
            className="m-0 p-0"
            fields={[
              {
                name: "status",
                type: "select",
                options: ["BACKLOG", "NOT_STARTED", "IN_PROGRESS", "COMPLETED", "BLOCKED"],
              },
              { name: "priority", type: "select", options: ["LOW", "MEDIUM", "HIGH"] },
              { name: "userStoryTitle", label: "User Story...", type: "text" },
              { name: "assignedUsers", label: "Assigned Users...", type: "text" },
            ]}
            getItems={() => allCards}
            onFilteredItems={handleFilteredItems}
        />

        <div className="flex gap-4 p-5 items-center">
          <div className="w-[150px]">
            <AddTask setCards={(c)=>{setAllCards(c);setFilteredCards(c);}} selectedSprint={selectedSprint}/>
          </div>
          <ViewSwitch isKanbanView={isKanbanView} onSwitch={onSwitch} />
          <select
              value={selectedSprint}
              onChange={(e) => setSelectedSprint(Number(e.target.value))}
              className="bg-[#121629] text-white p-2 rounded"
          >
            <option value={1}>unsorted</option>
            {sprints.filter(s => s.sprintid !== 1).map(s => (
                <option key={s.sprintid} value={s.sprintid}>
                  {s.name || `Sprint ${s.sprintid}`}
                </option>
            ))}
          </select>
        </div>
        <div className="max-h-[680px] max-w-[1300px] overflow-y-auto border border-transparent bg-[#121629] rounded-md">
        <table>
          <thead className="font-bold">
          <tr>
            <th className="p-5">Title</th>
            <th className="p-5">ID</th>
            <th className="p-5">Description</th>
            <th className="p-5">Status</th>
            <th className="p-5">Priority</th>
            <th className="p-5">Time Estimate</th>
            <th className="p-5">Assigned Users</th>
            <th className="p-5">User Story</th>
            <th className="p-5"></th>
            <th className="p-5"></th>
          </tr>
          </thead>
          <tbody>
          {filteredCards.map((task) => (
              <tr key={task.id}>
                <td className="p-5">{task.title}</td>
                <td className="p-5">{task.id}</td>
                <td className="p-5">{task.description}</td>
                <td className="p-5">{task.status}</td>
                <td className="p-5">{task.priority}</td>
                <td className="p-5">{task.estTime}</td>
                <td className="p-5">{(task.userInfos || []).map(user => user.username).join(', ')}</td>
                <td className="p-5">{task.userStory?.title || ''}</td>
                <td className="p-5"><button className="flex items-center gap-1" onClick={() => setEditTask(task)}>Edit <FiEdit/></button></td>
                <td className="p-5"><DeleteTask status={status} setCards={(c)=>{setAllCards(c);setFilteredCards(c);}} UserStory={task}/></td>
              </tr>
          ))}
          </tbody>
        </table>
        </div>
        {editTask && (
            <TaskDetails
                task={editTask}
                onSave={handleTaskUpdate}
                onClose={() => setEditTask(null)}
                cards={allCards}
                selectedSprint={selectedSprint}
            />
        )}
      </div>
    </motion.div>
  );
};
export default SprintBacklog;