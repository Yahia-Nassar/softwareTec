import React, { useState, useEffect } from "react";
import { Column } from "./Board.jsx";
import { useParams } from "react-router-dom";
import { notify } from "./Notification.jsx";
import { ConfirmDialog } from "primereact/confirmdialog";
import { motion } from "framer-motion";
import AddSprint from "./AddSprint";

// Trace: "SprintBoard" in https://git.informatik.uni-rostock.de/softwaretechnik-ws-2024-25/uebung1/team4/abgabedokument-sprint-4/-/blob/5f41bdf8c1770d6e342ab58ddca00db73b12077c/Klassendiagramm_Sprint_4.svg


export const SprintBoard = ({ sidebarOpen }) => {
  return (
    <>
      <ConfirmDialog />
      <motion.div
        className={`kanban transition ${sidebarOpen ? "lanes" : "lanes sidebar-collapsed"}`}
        initial={false}
        animate={{ width: sidebarOpen ? "calc(100% - 225px)" : "calc(100% - 64px)" }}
        transition={{ duration: 0.3, ease: "easeInOut" }}
      >
        <Board boardType="userStory" />
      </motion.div>
    </>
  );
};

const Board = ({ boardType }) => {
  const [cards, setCards] = useState([]);
  const [sprints, setSprints] = useState([]);
  const [userRole, setUserRole] = useState("");
  const { projectId } = useParams();

  useEffect(() => {
    fetch(`http://localhost:8080/getRole?projectid=${projectId}`, {
      method: "GET",
      credentials: "include",
    })
      .then(r => r.json())
      .then(d => setUserRole(d))
      .catch(e => console.error(e));
  }, [projectId]);

  useEffect(() => {
    fetch(`http://localhost:8080/getsprints?projectId=${projectId}`, {
      credentials: "include",
    })
      .then(r => r.json())
      .then(d => setSprints(d))
      .catch(e => console.error(e));
  }, [projectId]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const r = await fetch(`http://localhost:8080/getuserstories?projectid=${projectId}`, {
          method: "GET",
          credentials: "include",
        });
        if (!r.ok) throw new Error();
        const d = await r.json();
        const mapped = d.map(c => ({
          ...c,
          sprint: c.sprint,
          type: "userStory",
          frontendID: "us-" + c.id,
        }));
        setCards(mapped);
      } catch (e) {
        console.error(e);
      }
    };
    fetchData();
  }, [projectId]);

  const handleAddSprint = async data => {
    try {
      const r = await fetch(`http://localhost:8080/createSprint?projectId=${projectId}`, {
        method: "POST",
        credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!r.ok) throw new Error();
      const newSprint = await r.json();
      setSprints(prev => [...prev, newSprint]);
      notify.success(`Created sprint: ${newSprint.name}`);
    } catch (e) {
      console.error(e);
      notify.error("Error creating sprint");
    }
  };

  const handleSave = () => {
    const userStories = cards.filter(c => c.type === "userStory");
    const body = userStories.map(({ frontendId, sprint, ...rest }) => ({
      ...rest,
      sprint: { sprintid: sprint },
    }));
    fetch(`http://localhost:8080/saveUSCards?projectid=${projectId}`, {
      method: "POST",
      credentials: "include",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    })
      .then(r => r.json())
      .then(() => notify.success("Saved!"))
      .catch(e => {
        console.error(e);
        notify.error("Save error");
      });
  };

  const deleteSprint = (sprintId) => {
    if (sprintId != 1){
    fetch(`http://localhost:8080/deleteSprint?sprintId=${sprintId}`, {
      method: "POST",
      credentials: "include",
    })
      .then((res) => {
        if (!res.ok) throw new Error(`HTTP error! Status: ${res.status}`);
        setSprints(prev => prev.filter(s => s.sprintid !== sprintId));
        notify.success("Sprint deleted");
      })
      .catch((error) => {
        console.error("Fehler beim Löschen:", error);
        notify.error("Fehler beim Löschen des Sprints");
      });
  };}
  

  return (
    <div className="relative w-[80vw] h-[80vh] bg-transparent text-neutral-50">

    <div className="flex top-4 left-4 p-4 bg-[#232946] rounded z-50">
      <div className="w-[180px] pr-5">
        <AddSprint onAddSprint={handleAddSprint} />
      </div>

      <button
        onClick={handleSave}
      >Save</button>
    </div>
    
      <div className="flex gap-3 p-4 w-[80vw] h-[80vh]">
        {sprints.map(sprint => (
          <div
          key={sprint.sprintid}
          className="flex flex-col relative bg-[#1e213a] rounded p-4 flex-none w-[280px] flex-shrink-0"
          style={{ height: 'calc(100vh - 30vh)' }}
        >
          <Column
            isSprintBoard={true}
            key={sprint.sprintid}
            title={sprint.name}
            cards={cards}
            setCards={setCards}
            sprint={sprint.sprintid}
            boardType={boardType}
            showDelete={true}
            onDelete={() => deleteSprint(sprint.sprintid)}
            showCardCount={false}
            sprintData={sprint}
          />
            </div>
        ))}
      </div>
    </div>
  );
};

export default SprintBoard;