import React, { useState, useEffect } from "react";
import { FiPlus, FiTrash } from "react-icons/fi";
import { FaFire } from "react-icons/fa";
import { Column, BurnBarrel } from "./Board.jsx";
import SearchFilterSortPanel from "./SearchFilterSortPanel";
import { useParams } from "react-router-dom";
import { notify } from "./Notification";
import { motion } from "framer-motion";
import { confirm3 } from "./Confirmbox.jsx";
import { ConfirmDialog } from "primereact/confirmdialog";
import ViewSwitch from "./ViewSwitch.jsx";

//Trace: "SprintKanban" in https://git.informatik.uni-rostock.de/softwaretechnik-ws-2024-25/uebung1/team4/abgabedokument-sprint-4/-/blob/5f41bdf8c1770d6e342ab58ddca00db73b12077c/Klassendiagramm_Sprint_4.svg

export const SprintKanban = ({ sidebarOpen, isKanbanView, onSwitch }) => (
    <>
      <ConfirmDialog />
      <motion.div
          className={`kanban transition ${
              sidebarOpen ? "lanes" : "lanes sidebar-collapsed"
          }`}
          initial={false}
          animate={{
            width: sidebarOpen ? "calc(100% - 100x)" : "calc(100% - 56px)",
          }}
          transition={{ duration: 0.3, ease: "easeInOut" }}
      >
        <Board boardType="sprint" isKanbanView={isKanbanView} onSwitch={onSwitch} />
      </motion.div>
    </>
);

const Board = ({ boardType, isKanbanView, onSwitch }) => {
  const {projectId} = useParams();
  const [selectedSprint, setSelectedSprint] = useState(1);
  const [sprints, setSprints] = useState([]);
  const [allCards, setAllCards] = useState([]);
  const [filteredCards, setFilteredCards] = useState([]);

  useEffect(() => {
    const fetchSprints = async () => {
      const res = await fetch(
          `http://localhost:8080/getsprints?projectId=${projectId}`,
          {method: "GET", credentials: "include"}
      );
      if (res.ok) setSprints(await res.json());
    };
    if (projectId) fetchSprints();
  }, [projectId]);

  useEffect(() => {
    const fetchData = async () => {
      const tRes = await fetch(
          `http://localhost:8080/getsprinttasks?projectid=${projectId}&sprintid=${selectedSprint}`,
          {method: "GET", credentials: "include"}
      );
      const uRes = await fetch(
          `http://localhost:8080/getsprintUS?projectid=${projectId}&sprintid=${selectedSprint}`,
          {method: "GET", credentials: "include"}
      );
      if (!tRes.ok || !uRes.ok) return;

      const tasks = (await tRes.json()).map((c) => ({
        ...c,
        type: "task",
        frontendID: "task-" + c.id,
        userStoryTitle: c.userStory?.title || "",
      }));
      const stories = (await uRes.json()).map((c) => ({
        ...c,
        sprint: c.sprint.sprintid,
        type: "userStory",
        frontendID: "us-" + c.id,
      }));

      const merged = [...tasks, ...stories];
      setAllCards(merged);
      setFilteredCards(merged);
      localStorage.setItem("cards", JSON.stringify(merged));
    };
    fetchData();
  }, [projectId, selectedSprint]);

  const handleFilteredItems = (items) => setFilteredCards(items);
  const updateCards = (cards) => {
    setAllCards(cards);
    setFilteredCards(cards);
    localStorage.setItem("cards", JSON.stringify(cards));
  };

  const handleSave = async () => {
    const hasBurn = allCards.some(
        (c) => c.type === "task" && c.status === "BURNBARREL"
    );
    if (hasBurn && !(await confirm3())) return;

    const sanitized = allCards.map(({frontendId, ...rest}) => rest);
    const tasks = sanitized
        .filter((c) => c.type === "task")
        .map((t) => ({
          ...t,
          sprint: {sprintid: selectedSprint},
          userStory:
              typeof t.userStory === "string" && !t.userStory.trim()
                  ? null
                  : sanitized.find(
                      (s) => s.type === "userStory" && String(s.id) === t.userStory
                  ),
          users: (t.users || []).map((u) => ({id: u.id})),
        }));
    const stories = sanitized
        .filter((c) => c.type === "userStory")
        .map((c) => ({...c, sprint: {sprintid: selectedSprint}}));

    await fetch(`http://localhost:8080/saveTasks?projectid=${projectId}`, {
      method: "POST",
      credentials: "include",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify(tasks),
    });
    await fetch(`http://localhost:8080/saveUSCards?projectid=${projectId}`, {
      method: "POST",
      credentials: "include",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify(stories),
    });
    notify.success("saved!");
  };

  return ( 
      <div className="h-window w-full bg #232946 text-neutral-50 m-0 p-0">

        <div className="p-4 pr-5">
        <SearchFilterSortPanel
            fields={[
              {
                name: "status",
                type: "select",
                options: [
                  "BACKLOG",
                  "NOT_STARTED",
                  "IN_PROGRESS",
                  "IN_TESTING",
                  "COMPLETED",
                  "BLOCKED",
                ],
              },
              {name: "priority", type: "select", options: ["LOW", "MEDIUM", "HIGH"]},
              { name: "userStoryTitle", label: "User Story...", type: "text" },
              { name: "assignedUsers", label: "Assigned Users...", type: "text" },
            ]}
            getItems={() => allCards}
            onFilteredItems={handleFilteredItems}
        />
        </div>

        <div className="flex gap-4 p-5 items-center">
          <ViewSwitch isKanbanView={isKanbanView} onSwitch={onSwitch} />
          <button onClick={handleSave}>Save</button>
            <select
                value={selectedSprint}
                onChange={(e) => setSelectedSprint(Number(e.target.value))}
                className="bg-[#121629] text-white p-2 rounded"
            >
              <option value={1}>unsorted</option>
              {sprints
                  .filter((s) => s.sprintid !== 1)
                  .map((s) => (
                      <option key={s.sprintid} value={s.sprintid}>
                        {s.name || `Sprint ${s.sprintid}`}
                      </option>
                  ))}
            </select>
        </div>

        <div className="flex flex-wrap h-full w-full gap-8 overflow-hidden p-12">
          {[
            ["Backlog", "BACKLOG", "text-neutral-200"],
            ["Not started", "NOT_STARTED", "text-yellow-200"],
            ["In progress", "IN_PROGRESS", "text-blue-200"],
            ["In testing", "IN_TESTING", "text-emerald-200"],
            ["Complete", "COMPLETED", "text-violet-400"],
            ["Blocked", "BLOCKED", "text-red-500"],
          ].map(([title, status, color]) => (
              <Column
                  key={status}
                  className="w-1/2"
                  title={title}
                  status={status}
                  headingColor={color}
                  cards={filteredCards}
                  setCards={updateCards}
                  boardType={boardType}
                  sprint={selectedSprint}
              />
          ))}

          <BurnBarrel
              className="w-1/2"
              status="BURNBARREL"
              cards={filteredCards}
              setCards={updateCards}
              boardType={boardType}
          />
        </div>
      </div>
  );
};
export default SprintKanban;