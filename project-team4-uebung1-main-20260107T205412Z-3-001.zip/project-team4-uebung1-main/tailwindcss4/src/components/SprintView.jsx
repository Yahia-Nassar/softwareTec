import React, { useState } from "react";
import SprintBacklog from "./SprintBacklog";
import SprintKanban from "./SprintKanban";

const SprintView = () => {
  const [isKanbanView, setIsKanbanView] = useState(() => {
    const currentSprintView = localStorage.getItem("currentSprintView");
    return currentSprintView === "kanban";
  });

  const handleSwitch = () => {
    const newSprintView = !isKanbanView;
    setIsKanbanView(newSprintView);
    localStorage.setItem("currentSprintView", newSprintView ? "kanban" : "backlog");
  };

  return (
    <div>
      {isKanbanView ? (
        <SprintKanban sidebarOpen={true}
        isKanbanView={isKanbanView}
        onSwitch={handleSwitch}
        /> 
      ) : ( 
        <SprintBacklog 
          isKanbanView={isKanbanView} 
          onSwitch={handleSwitch}
        />
      )}
    </div>
  );
};

export default SprintView;