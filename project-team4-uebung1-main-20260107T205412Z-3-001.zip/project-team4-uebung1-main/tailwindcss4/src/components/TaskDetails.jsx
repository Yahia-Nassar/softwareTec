import React, { useState, useEffect } from "react";
import { FiUser, FiClock, FiMessageSquare } from "react-icons/fi";
import AssignedUserSelector  from "./AssignedUserSelection";
import { useParams } from 'react-router-dom';
import { saveTasks } from "./taskService";
import { FiX } from "react-icons/fi";


export const TaskDetails = ({ task, onClose, onSave, cards , selectedSprint}) => {
  const [title, setTitle] = useState(task.title);
  const [description, setDescription] = useState(task.description || "");
  const [priority, setPriority] = useState(task.priority || "MEDIUM");
  const [status, setStatus] = useState(task.status);
  const [estTime, setEstTime] = useState(task.estTime || 0);
  const [actTime, setActTime] = useState(task.actTime || 0);
  const [comments, setComments] = useState(task.comments || []);
  const [newComment, setNewComment] = useState("");
  const [userStories, setUserStories] = useState([]);
  const [selectedUserStory, setSelectedUserStory] = useState(task.userStory || ""); 
  //const [isEditingComments, setIsEditingComments] = useState(false);
  const [users, setUsers] = useState(
  task.userInfos?.map(u => ({
    id: u.id,
    username: u.username
  })) || []
);

  const [frontendID] = useState(task.frontendID || "");
  const { projectId } = useParams();
  const [inProgressAt, setInProgressAt] = useState(task.inProgressAt || null);
  const [completedAt, setCompletedAt] = useState(task.completedAt || null);


useEffect(() => {
  const fetchUserStories = async () => {
    try {
      const response = await fetch(`http://localhost:8080/getuserstories?projectid=${projectId}`, {
        method: "GET",
        credentials: 'include',
      });
      const data = await response.json();
      const filtered = data.filter(story => !story.isTemp && story.sprint == selectedSprint);
      setUserStories(filtered);

      console.log("Geladene User Stories:", filtered);
    } catch (error) {
      console.error("Fehler beim Laden der User Stories:", error);
    }
  };

  fetchUserStories();
}, [projectId]);

useEffect(() => {
  if (status === "IN_PROGRESS" && !inProgressAt) {
    const now = new Date().toISOString();
    setInProgressAt(now);
  }
    
  if (status === "COMPLETED" && inProgressAt && !completedAt) {
    const now = new Date().toISOString();
    setCompletedAt(now);
    
    const start = new Date(inProgressAt);
    const end = new Date(now);
    const diffInDays = Math.ceil((end - start) / (1000 * 60 * 60 * 24));
    setActTime(diffInDays);
  }
}, [status, inProgressAt, completedAt]);


  const handleSave = () => {
    if (!title.trim()) return;

    console.log(selectedSprint)

    const updatedTask = {
      ...task,
      title: title.trim(),
      description: description.trim(),
      priority,
      status,
      estTime,
      actTime,
      users,
      userInfos: users,
      comments,
      userStory: selectedUserStory,
      createdAt: task.createdAt || new Date().toISOString(),
      frontendID,
      inProgressAt,
      completedAt,
      sprint: selectedSprint,
      type: "task"
    };

    const userStoryValue = updatedTask.userStory
        ? { id: updatedTask.userStory }
        : null;

    const task_with_sprint = {
      ...updatedTask,
      sprint: { sprintid: selectedSprint },
      userStory: userStoryValue
    };

    fetch(`http://localhost:8080/saveTasks?projectid=${projectId}`, {
      method: "POST",
      credentials: "include",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify([task_with_sprint])
    })
        .then((response) => response.json())
        .then((data) => {
          console.log("Erfolg:", data);
        })
        .catch((error) => {
          console.error("Fehler:", error);
        });

    onSave(updatedTask);
  };

  const saveUpdatedTask = async () => {
    const payloadTask = {
        ...updatedTask,
        sprint: { sprintid: selectedSprint },
        userStory: updatedTask.userStory
          ? { id: updatedTask.userStory }
          : null,
      };

      try {
        const data = await saveTasks(projectId, [payloadTask]);
        console.log("Save Success:", data);
        onSave(updatedTask);
      } catch (err) {
        console.error("Save Error:", err);
        // Error
    };

  };

  const addComment = () => {
    if (!newComment.trim()) return;
    const comment = {
      id: Date.now().toString(),
      text: newComment.trim(),
      createdAt: new Date().toISOString(),
    };
    setComments([...comments, comment]);
    setNewComment("");
    //setIsEditingComments(false);
  };

  const actTimeDisplay = status === "COMPLETED"
  ? `${actTime} day(s)`
  : "Still running";


  return (
    <div className="fixed inset-0 bg-[#121629]/80 flex items-center justify-center p-4 z-50">
      <div className="bg-[#232946] text-neutral-100 p-6 rounded-lg shadow-lg w-full max-w-2xl max-h-[90vh] overflow-y-auto">
      <h2 className="text-xl font-bold mb-4 pb-2">Task Details</h2>
        
        <div className="mb-4">
          <label className="block text-sm font-medium mb-1">Title</label>
          <input
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="w-full p-2 rounded bg-[#121629]  text-white"
          />
        </div>
        
        <div className="mb-4">
          <label className="block text-sm font-medium mb-1">Description</label>
          <textarea
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            className="w-full p-2 rounded bg-[#121629] text-white min-h-24"
            rows={4}
          />
        </div>
        
        <div className="grid grid-cols-2 gap-4 mb-4">
          <div>
            <label className="block text-sm font-medium mb-1">Priority</label>
            <select
              value={priority}
              onChange={(e) => setPriority(e.target.value)}
              className="w-full p-2 rounded bg-[#121629]  text-white"
            >
              <option value="LOW">Low</option>
              <option value="MEDIUM">Medium</option>
              <option value="HIGH">High</option>
            </select>
          </div>
          
          <div>
            <label className="block text-sm font-medium mb-1">Status</label>
            <select
              value={status}
              onChange={(e) => setStatus(e.target.value)}
              className="w-full p-2 rounded  bg-[#121629]  text-white"
            >
              <option value="BACKLOG">Backlog</option>
              <option value="NOT_STARTED">Not Started</option>
              <option value="IN_PROGRESS">In Progress</option>
              <option value="IN_TESTING">In Testing</option>
              <option value="COMPLETE">Complete</option>
            </select>
          </div>
        </div>
        
        <div className="mb-4">
          <label className="block text-sm font-medium mb-1">Estimated Time days</label>
          <input
            type="number"
            value={estTime}
            onChange={(e) => setEstTime(parseInt(e.target.value) || 0)}
            className="w-full p-2 rounded  bg-[#121629]  text-white"
            min="0"
          />
        </div>

        <div className="mb-4">
          <label className="block text-sm font-medium mb-1">Time taken</label>
            <div className="w-full p-2 rounded bg-[#121629]  text-white">
              {actTimeDisplay}
            </div>

            <div className="mb-4">
          <label className="block text-sm font-medium mb-1 flex items-center">
            <FiMessageSquare className="mr-1" /> Comments
          </label>
          <div className="mb-2 max-h-40 overflow-y-auto p-2 rounded bg-[#121629]">
            {comments.map(comment => (
              <div key={comment.id} className="mb-2 pb-2 border-b border-neutral-600 last:border-0">
                <div className="flex justify-between text-xs text-neutral-400">
                  <span>{comment.user?.username || "Anonymous"}</span>
                  <span>{new Date(comment.createdAt).toLocaleString()}</span>
                </div>
                <p className="text-sm">{comment.text}</p>
              </div>
            ))}
            {comments.length === 0 && <p className="text-neutral-400 text-sm">No comments yet</p>}
          </div>
          <div className="flex gap-2">
            <input
              type="text"
              value={newComment}
              onChange={(e) => setNewComment(e.target.value)}
              placeholder="Add a comment..."
              className="flex-1 p-2 rounded bg-[#121629] text-white"
            />
            <button
              onClick={addComment}
              className="px-3 py-1 bg-violet-600 text-white rounded hover:bg-violet-700"
            >
              Add
            </button>
          </div>
        </div>


      </div>

        
        <AssignedUserSelector
          assignedUsers={users}
          setAssignedUsers={setUsers}
          projectId={projectId}
        />

        <div className="grid grid-cols-2 gap-4 mb-6">
          <div>
            <label className="block text-sm font-medium mb-1"> User Story </label>
<select
  value={selectedUserStory}
  onChange={(e) => setSelectedUserStory(e.target.value)}
  className="w-full p-2 rounded bg-[#121629] text-white"
>
  <option value="">Select a User Story</option>
  {userStories
    .filter(story => !story.isTemp)
    .map(story => (
      <option key={story.id} value={story.id}>
        {story.title}
      </option>
  ))}
</select>
          </div>
        </div>
        
        <div className="flex justify-end space-x-3">
        <button
            onClick={handleSave}
            className="px-4 py-2 bg violet-600 text-white rounded hover:bg violet-700"
          >
            Save
          </button>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-[#121629] text-white rounded hover:bg-[#121629]"
          >
            Cancel
          </button>
          
        </div>
      </div>
    </div>
  );
};