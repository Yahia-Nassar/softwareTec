import React, { useEffect, useState } from "react";
import {
  PieChart,
  Pie,
  Cell,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";

//Trace: "TaskPieChart" in https://git.informatik.uni-rostock.de/softwaretechnik-ws-2024-25/uebung1/team4/abgabedokument-sprint-4/-/blob/5f41bdf8c1770d6e342ab58ddca00db73b12077c/Klassendiagramm_Sprint_4.svg

function TaskPieChart({ projectId, sprintId }) {
  const [tasks, setTasks] = useState([]);

  useEffect(() => {
    fetch(`http://localhost:8080/getusersprinttasks?projectid=${projectId}&sprintid=${sprintId}`,
        {credentials: 'include'}
    )
      .then((res) => res.json())
      .then((data) => setTasks(data || []))
      .catch((err) => console.error("Error while Fetching:", err));
  }, [projectId, sprintId]);


  const statusCounts = tasks.reduce((acc, task) => {
    acc[task.status] = (acc[task.status] || 0) + 1;
    return acc;
  }, {});

  const chartData = Object.entries(statusCounts).map(([status, count]) => ({
    name: status,
    value: count,
  }));

  const STATUS_COLORS = {
    BACKLOG: "#0088FE",
    NOT_STARTED: "#00C49F",
    IN_PROGRESS: "#FFBB28",
    IN_TESTING: "#FF8042",
    COMPLETED: "#9B51E0",
    BLOCKED: "#FF0000",
    BURNBARREL: "#C0C0C0",
  };

  return (
    <div className="bg-[#121629] text-white p-4 rounded-lg shadow-md w-full">
      <h2 className="text-lg font-bold mb-4">Taskstatus</h2>
      <ResponsiveContainer width="100%" height={300}>
        <PieChart>
          <Pie
            data={chartData}
            dataKey="value"
            nameKey="name"
            cx="50%"
            cy="50%"
            outerRadius={80}
            label
            stroke="transparent"
          >
            {chartData.map((entry) => (
              <Cell
                key={`cell-${entry.name}`}
                fill={STATUS_COLORS[entry.name] || "#888888"}
              />
            ))}
          </Pie>
          <Tooltip 
            contentStyle={{
              backgroundColor: "#232946",
              border: "1px solid",
              borderColor: "transparent",
              borderRadius: "8px",
              color: "#fff", 
            }}
            itemStyle={{
              color: "#ffffff",
            }}
            labelStyle={{
              color: "#ccc",
            }}
          />
          <Legend />
        </PieChart>
      </ResponsiveContainer>
    </div>
  );
}

export default TaskPieChart;