import { useState, useEffect, useRef } from 'react';
import { notify } from './Notification';
import { useLocation } from 'react-router-dom';

//Trace: "TaskReminder" in https://git.informatik.uni-rostock.de/softwaretechnik-ws-2024-25/uebung1/team4/abgabedokument-sprint-4/-/blob/5f41bdf8c1770d6e342ab58ddca00db73b12077c/Klassendiagramm_Sprint_4.svg

const TaskReminder = () => {
  const [taskNotification, setTaskNotification] = useState(1);
  const [cards, setCards] = useState([]);

  const cardsRef = useRef([]);
  const notifRef = useRef(1);

  const projectId = useLocation().pathname.split('/')[1];

  useEffect(() => {
    const fetchTasks = async () => {
      try {
        console.log('[TaskReminder] Fetching tasks for project', projectId);
        const res = await fetch(
            `http://localhost:8080/gettasks?projectid=${projectId}`,
            { method: 'GET', credentials: 'include' }
        );
        if (!res.ok) throw new Error('Failed to load tasks');
        const data = await res.json();
        const tasks = data.map(c => ({
          ...c,
          type: 'task',
          frontendID: `task-${c.id}`,
        }));
        console.log('[TaskReminder] Loaded', tasks.length, 'tasks');
        setCards(tasks);
      } catch (err) {
        console.error('[TaskReminder] Error loading tasks', err);
        setCards([]);
      }
    };
    if (projectId) fetchTasks();
  }, [projectId]);

  useEffect(() => {
    const fetchSetting = async () => {
      try {
        console.log('[TaskReminder] Fetching notification setting');
        const res = await fetch(
            `http://localhost:8080/gettasknotification?projectid=${projectId}`,
            { credentials: 'include' }
        );
        if (!res.ok) throw new Error();
        const value = Number(await res.json());
        setTaskNotification(value >= 0 ? value : 1);
        console.log('[TaskReminder] Notification days set to', value);
      } catch {
        console.warn('[TaskReminder] Using default notification value 1');
        setTaskNotification(1);
      }
    };
    if (projectId) fetchSetting();
  }, [projectId]);

  useEffect(() => {
    cardsRef.current = cards;
  }, [cards]);

  useEffect(() => {
    notifRef.current = taskNotification;
  }, [taskNotification]);

  useEffect(() => {
    console.log('[TaskReminder] Interval started');
    const id = setInterval(() => {
      const today = new Date();
      today.setHours(0, 0, 0, 0);

      const notified = JSON.parse(localStorage.getItem('notifiedTasks') || '{}');
      const updated = { ...notified };

      console.log('[TaskReminder] Checking', cardsRef.current.length, 'cards');

      cardsRef.current.forEach(card => {
        if (card.type !== 'task' || !card.createdAt || card.estTime === 0) return;

        const dueDate = new Date(card.createdAt);
        dueDate.setHours(0, 0, 0, 0);
        dueDate.setDate(dueDate.getDate() + card.estTime);

        const reminderDay = new Date(dueDate);
        reminderDay.setDate(reminderDay.getDate() - notifRef.current);
        reminderDay.setHours(0, 0, 0, 0);

        const alreadyShown = updated[card.id];

        console.log(
            `[TaskReminder] Task "${card.title}" | Due: ${dueDate.toDateString()} | ` +
            `Reminder: ${reminderDay.toDateString()} | Today: ${today.toDateString()} | ` +
            `AlreadyNotified: ${!!alreadyShown}`
        );

        if (today.getTime() === reminderDay.getTime() && !alreadyShown) {
          notify.reminder(`Task "${card.title}" is due in ${notifRef.current} day(s)!`);
          console.log('[TaskReminder] Reminder triggered for', card.title);
          updated[card.id] = true;
        }

        if (today < reminderDay && alreadyShown) {
          console.log('[TaskReminder] Resetting reminder flag for', card.title);
          delete updated[card.id];
        }

        if (
            card.status === 'COMPLETED' &&
            card.actTime != null &&
            card.actTime > card.estTime
        ) {
          const overdueKey = `overdue_${card.id}`;
          if (!updated[overdueKey]) {
            notify.warning(
                `Task "${card.title}" exceeded planned time (${card.actTime} vs ${card.estTime} days).`
            );
            console.log('[TaskReminder] Overdue warning for', card.title);
            updated[overdueKey] = true;
          }
        }
      });

      localStorage.setItem('notifiedTasks', JSON.stringify(updated));
    }, 5000);

    return () => {
      clearInterval(id);
      console.log('[TaskReminder] Interval cleared');
    };
  }, []);

  return null;
};

export default TaskReminder;