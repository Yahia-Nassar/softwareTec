import React, {useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import SearchFilterSortPanel from "./SearchFilterSortPanel";
import { confirm3 } from "./Confirmbox";

function UserCard({ user, currentUsername, onRemove, onLeave }) {
    return (
      <div className="bg-[#121629] rounded-md p-4 flex items-center justify-between w-full m-2 text-white">
        <div className="flex flex-col flex-1 space-y-4">
          <p><span className="font-semibold mr-4">Username:</span> {user.username}</p>
          <p><span className="font-semibold mr-4">Email:</span> {user.email}</p>
          <p><span className="font-semibold mr-4">Role:</span> {user.role}</p>
        </div>
  
        <div className="ml-4">
          {user.username !== currentUsername ? (
            <button
              onClick={() => onRemove(user.username)}
            >
              Remove
            </button>
          ) : (
            <button
              onClick={onLeave}
            >
              Leave
            </button>
          )}
        </div>
      </div>
    );
  }
  
  
  
  

export default function TeamView() {
  const { projectId } = useParams();
  const [allUsers, setAllUsers] = useState([]);
  const [filteredUsers, setFilteredUsers] = useState([]);
  const [currentUsername, setCurrentUsername] = useState(null);
  const [showAddUserModal, setShowAddUserModal] = useState(false);
  const [newUsername, setNewUsername] = useState("");

  useEffect(() => {
    fetch("http://localhost:8080/currentuser", { credentials: "include" })
      .then((res) => res.json())
      .then((data) => setCurrentUsername(data.username))
      .catch(console.error);
  }, []);

  useEffect(() => {
    if (!projectId) return;
  
    fetch(`http://localhost:8080/getusersinproject?projectid=${projectId}`, { credentials: "include" })
      .then(res => res.json())
      .then(users => {
        fetch(`http://localhost:8080/getrolesinproject?projectid=${projectId}`, { credentials: "include" })
          .then(res => res.json())
          .then(roles => {
            const usersWithRoles = users.map(user => {
              const roleObj = roles.find(r => r.userId === user.id);
              return {
                ...user,
                role: roleObj ? roleObj.role : "UNKNOWN",
              };
            });
            setAllUsers(usersWithRoles);
            setFilteredUsers(usersWithRoles);
          })
          .catch(console.error);
      })
      .catch(console.error);
  }, [projectId]);
  

  function handleFilteredItems(items) {
    setFilteredUsers(items);
  }

  async function handleRemoveUser(username) {
    const confirmed = await confirm3({
      message: `Remove user ${username} from project?`,
      header: 'Remove User'
    });
    if (!confirmed) return;
  
    fetch(`http://localhost:8080/removeuserfromproject?projectid=${projectId}&username=${username}`, {
      method: "POST",
      credentials: "include",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username }),
    })
    .then(() => {
      setAllUsers((prev) => prev.filter((u) => u.username !== username));
      setFilteredUsers((prev) => prev.filter((u) => u.username !== username));
    })
    .catch(console.error);
  }
  
  async function handleLeaveProject() {
    const confirmed = await confirm3({
      message: 'Are you sure you want to leave the project?',
      header: 'Leave Project'
    });
    if (!confirmed) return;
  
    fetch(`http://localhost:8080/leaveproject?projectid=${projectId}`, {
        method: "POST",
        credentials: "include",
    })
    .then(() => window.location.href = "/projectselection")
    .catch(console.error);
  }
  function openAddUserModal() {
    setShowAddUserModal(true);
  }

  function closeAddUserModal() {
    setShowAddUserModal(false);
    setNewUsername("");
  }

  function handleAddUser() {
    fetch(`http://localhost:8080/addusertoproject?projectid=${projectId}`, {
      method: "POST",
      credentials: "include",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username: newUsername }),
    })
      .then(() => {
        closeAddUserModal();
        return fetch(`http://localhost:8080/getusersinproject?projectid=${projectId}`, { credentials: "include" });
      })
      .then((res) => res.json())
      .then((data) => {
        setAllUsers(data);
        setFilteredUsers(data);
      })
      .catch(console.error);
  }

  if (!currentUsername) return <div>Loading user info...</div>;

  return (
    <div className="p-4">
      <div className="flex gap-4 items-center mb-4">
        <SearchFilterSortPanel
            fields={[
                { name: "email", label: "E-Mail...", type:"text"},
            ]}
            getItems={() =>
                allUsers.map((u) => ({
                 ...u,
                    title: u.username || "",
                }))
            }
            onFilteredItems={handleFilteredItems}
        />
        <button
          onClick={openAddUserModal}
          className="bg-pink-500 hover:bg-pink-600 text-[#232946] font-semibold rounded px-4 py-2 transition"
        >
          Add Team Member
        </button>
      </div>

    <div className="flex flex-wrap gap-4 max-h-[600px] overflow-y-auto">
        {filteredUsers.map(user => (
            <div key={user.id} className="w-full md:w-1/2">
            <UserCard
                user={user}
                currentUsername={currentUsername}
                onRemove={handleRemoveUser}
                onLeave={handleLeaveProject}
            />
            </div>
        ))}
    </div>


      {showAddUserModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50">
          <div className="bg-[#232946] p-6 rounded-md w-80 text-white">
            <h2 className="text-xl mb-4 font-semibold">Add Team Member</h2>
            <input
              type="text"
              value={newUsername}
              onChange={(e) => setNewUsername(e.target.value)}
              placeholder="Username"
              className="w-full p-2 rounded border border-gray-600 bg-[#1e254f] mb-4 text-white"
            />
            <div className="flex justify-end gap-2">
              <button
                onClick={closeAddUserModal}
                className="bg-gray-600 hover:bg-gray-700 px-3 py-1 rounded transition"
              >
                Cancel
              </button>
              <button
                onClick={handleAddUser}
                className="bg-pink-500 hover:bg-pink-600 px-3 py-1 rounded font-semibold transition"
              >
                Add
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}