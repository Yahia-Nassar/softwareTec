import React, { useEffect, useState } from "react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";

//Trace: "TimeComparison" in https://git.informatik.uni-rostock.de/softwaretechnik-ws-2024-25/uebung1/team4/abgabedokument-sprint-4/-/blob/5f41bdf8c1770d6e342ab58ddca00db73b12077c/Klassendiagramm_Sprint_4.svg

function TimeComparison({ projectId, sprintId }) {
  const [tasks, setTasks] = useState([]);

  useEffect(() => {
    fetch(`http://localhost:8080/getusersprinttasks?projectid=${projectId}&sprintid=${sprintId}`,
        {credentials: 'include'}
    )
      .then((res) => res.json())
      .then((data) => setTasks(data))
      .catch((err) => console.error("Error while Fetching:", err));
  }, [projectId, sprintId]);

  const completedTasks = tasks.filter((task) => task.status === "COMPLETED");

  const chartData = completedTasks.map((task) => ({
    name: task.title.length > 15 ? task.title.slice(0, 15) + "..." : task.title,
    Estimated: task.estTime || 0,
    Actual: task.actTime || 0,
  }));

  return (
    <div className="bg-[#121629] text-white p-4 rounded-lg w-full">
      <h2 className="text-lg font-bold mb-4">
        Estimate Time vs Actual Time
      </h2>
      <ResponsiveContainer width="100%" height={300}>
        <LineChart data={chartData}>
          <CartesianGrid strokeDasharray="3 3" stroke="#444" />
          <XAxis
            dataKey="name"
            stroke="#ccc"
          />
          <YAxis label={{
            value: "days",
            angle: -90,
            position: "insideLeft",
            fill: "#ccc",
          }} stroke="#ccc" />
          <Tooltip contentStyle={{
            backgroundColor: "#232946",
            border: "1px solid #444",
            borderColor: "transparent",
            borderRadius: "8px",
            color: "#fff",
          }}/>
          <Legend />
          <Line type="monotone" dataKey="Estimated" stroke="#8884d8" />
          <Line type="monotone" dataKey="Actual" stroke="#82ca9d" />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}

export default TimeComparison;