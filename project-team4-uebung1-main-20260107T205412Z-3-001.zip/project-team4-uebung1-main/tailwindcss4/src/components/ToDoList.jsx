import React, { useEffect, useState } from 'react';
import { Box, Card, CardContent, Typography } from '@mui/material';

//Trace: "ToDoList" in https://git.informatik.uni-rostock.de/softwaretechnik-ws-2024-25/uebung1/team4/abgabedokument-sprint-4/-/blob/5f41bdf8c1770d6e342ab58ddca00db73b12077c/Klassendiagramm_Sprint_4.svg

function ToDoList({ projectId, sprintId }) {
  const [tasks, setTasks] = useState([]);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetch(`http://localhost:8080/getusersprinttasks?projectid=${projectId}&sprintid=${sprintId}`, {
      credentials: 'include'
    })
      .then(response => {
        if (!response.ok) {
          throw new Error(`HTTP-Fehler ${response.status}`);
        }
        return response.json();
      })
      .then(data => {
        setTasks(data);
      })
      .catch(err => {
        setError(err.message);
      });
  }, [projectId, sprintId]);

  if (error) {
    return <div>Fehler: {error}</div>;
  }

  return (
    <Box
      sx={{
        border: '4px solid',
        backgroundColor: '#121629',
        borderColor: '#121629',
        p: 2,
        borderRadius: 2,
        minHeight: '400px',
        maxHeight: '400px',
        display: 'flex',
        flexDirection: 'column',
        '&, & *': {
          color: 'white !important',
        },
      }}
    >
     <Box
    sx={{
      top: 0,
      zIndex: 1,
      backgroundColor: '#121629',
      paddingBottom: 1,
      paddingTop: 1,
    }}
  >
    <Typography variant="h6" fontWeight="bold">
      My To Do List
    </Typography>
  </Box>
  <Box
      sx={{
        flex: 1,
        overflowY: 'auto',
        mt: 1,
        pr: 1,
      }}
    >
      <Box display="flex" flexDirection="column" gap={1} mt={1}>
        {tasks?.filter(task => task.status !== 'COMPLETED').map(task => (
          <Card 
          key={task.id} 
          elevation={0} 
          sx={{ 
            backgroundColor: '#232946', 
            color: 'white', 
            padding: 1,
            maxHeight: '80px',
            mb: 1,
            borderRadius: 1,
          }}
        >
          <CardContent sx={{ padding: '8px 12px' }}>
            <Typography 
              variant="subtitle2" 
              component="div" 
              fontWeight="bold"
              sx={{ fontSize: '0.85rem' }}
            >
              {task.title}
            </Typography>
            <Typography 
              variant="caption" 
              color="gray"
              sx={{ fontSize: '0.75rem' }}
            >
              Status: {task.status}
            </Typography>
          </CardContent>
        </Card>        
        ))}
      </Box>
    </Box>
    </Box>
  );
}

export default ToDoList;
