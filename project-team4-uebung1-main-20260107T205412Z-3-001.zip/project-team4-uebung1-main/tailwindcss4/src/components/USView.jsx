import React, { useState } from "react";
import Backlog from "./Backlog";
import UserStoryKanban from "./UserStoryKanban";

const USView = () => {
  const [isKanbanView, setIsKanbanView] = useState(() => {
    const currentUSView = localStorage.getItem("currentUSView");
    return currentUSView === "kanban";
  });

  const handleSwitch = () => {
    const newUSView = !isKanbanView;
    setIsKanbanView(newUSView);
    localStorage.setItem("currentUSView", newUSView ? "kanban" : "backlog");
  };

  return (
    <div>
      {isKanbanView ? (
        <UserStoryKanban sidebarOpen={true}
        isKanbanView={isKanbanView}
        onSwitch={handleSwitch}
        /> 
      ) : ( 
        <Backlog 
          isKanbanView={isKanbanView} 
          onSwitch={handleSwitch}
        />
      )}
    </div>
  );
};

export default USView;