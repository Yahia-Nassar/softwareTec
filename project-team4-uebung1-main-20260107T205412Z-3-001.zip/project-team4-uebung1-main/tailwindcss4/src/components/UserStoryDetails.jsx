import React, { useState, useEffect } from "react";
import Popup from 'reactjs-popup';
import { FiEdit } from "react-icons/fi";
import 'reactjs-popup/dist/index.css';
import { toast as notify } from 'react-toastify';
import {useParams} from "react-router-dom";


const UserStoryDetails = ({ columnName, cards, setCards, UserStory, close, selectedSprint}) => {
    const { projectId } = useParams();
    const [title, setTitle] = useState(UserStory.title);
    const [description, setDescription] = useState(UserStory.description);
    const [status, setStatus] = useState(UserStory.status); 
    const [acceptanceCriteria, setAcceptanceCriteria] = useState(UserStory.acceptanceCriteria); 
    const [priority, setPriority] = useState(UserStory.priority);
    const [type, setType] = useState('userStory');
    const [frontendID] = useState(UserStory.frontendID || "");
    const [userRole, setuserRole] = useState('');

    useEffect(() => {
        fetch(`http://localhost:8080/getRole?projectid=${projectId}`, {
            method: 'GET',
            credentials: 'include',
        })
            .then(response => {
                if (!response.ok) {
                    throw new Error(`Fehler beim Laden der User Stories: ${response.status} ${response.statusText}`);
                }
                return response.json();
            })
            .then(data => {
                console.log('Erfolg:', data);
                setuserRole(data);
            })
            .catch((error) => {
                console.error('Fehler:', error);
            });
    }, []);

    const handleSubmit = (e) => {
        e.preventDefault();
        if (userRole !== 'PRODUCT_OWNER') {
            notify.error('Only Product Owners can edit User Stories');
            return;
        }
        if (!title.trim().length) return;

        const updatedUserStory = {
            ...UserStory,
            columnName,
            title: title.trim(),
            description: description.trim(),
            status,
            acceptanceCriteria: acceptanceCriteria.trim(),
            priority,
            type: "userStory",
            frontendID,
            sprint: selectedSprint,
        };

        setCards(prevCards =>
            prevCards.map(card =>
                card.frontendID === UserStory.frontendID ? updatedUserStory : card
            )
        );

        const us_with_sprint = {
            ...updatedUserStory,
            sprint: { sprintid: selectedSprint }
        };

        fetch(`http://localhost:8080/saveUSCards?projectid=${projectId}`, {
            method: "POST",
            credentials: "include",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify([us_with_sprint])
        })
            .then(res => res.json())
            .then(data => {
                console.log("Erfolg:", data);
                notify.success("Saved!");
            })
            .catch((err) => {
                console.error("Fehler:", err);
                notify.error("Error!");
            });

        close();
    };

return (
    <div className="fixed inset-0 bg-[#121629]/80 flex items-center justify-center p-4 z-50">
    <div className="bg-[#232946] rounded-lg p-6 w-full max-w-2xl mx-auto border-none shadow-none max-h-screen overflow-y-auto">
                    <form onSubmit={handleSubmit}>
                        <div className="flex flex-col space-y-4">
                         <label className="flex flex-col">
                             User Story 
                        </label> 
                            <label className="flex flex-col">
                                Title:
                                <input 
                                    type='text' 
                                    value={title} 
                                    onChange={(e) => setTitle(e.target.value)} 
                                    required 
                                    className="mt-1 p-2  rounded  bg-[#121629]"
                                />
                            </label>
                            <label className="flex flex-col">
                                Description:
                                <textarea 
                                    value={description} 
                                    onChange={(e) => setDescription(e.target.value)} 
                                    required 
                                    className="mt-1 p-2  rounded  bg-[#121629]"
                                />
                            </label>
                            <label className="flex flex-col">
                                Acceptance Criteria:
                                <textarea 
                                    value={acceptanceCriteria} 
                                    onChange={(e) => setAcceptanceCriteria(e.target.value)} 
                                    required 
                                    className="mt-1 p-2  rounded  bg-[#121629]"
                                />
                            </label>
                            <label className="flex flex-col">
                                Status:
                                <select 
                                    value={status} 
                                    onChange={(e) => setStatus(e.target.value)}
                                    className="mt-1 p-2  rounded bg-[#121629]"
                                >
                                    <option value="BACKLOG">Backlog</option>
                                    <option value="IN_PROGRESS">In Progress</option>
                                    <option value="COMPLETED">Completed</option>
                                    <option value="INCOMPLETE">Incomplete</option>
                                </select>
                            </label>
                            <label className="flex flex-col">
                                Priority:
                                <select 
                                    value={priority} 
                                    onChange={(e) => setPriority(e.target.value)}
                                    className="mt-1 p-2  rounded bg-[#121629]"
                                >
                                    <option value="LOW">Low</option>
                                    <option value="MEDIUM">Medium</option>
                                    <option value="HIGH">High</option>
                                </select>
                            </label>
                        </div>
                        <div className="flex justify-end space-x-2 mt-4">
                            <button type='submit' className="px-4 py-2 bg-[#121629] text-white rounded">
                                Save
                            </button>
                            <button type='button' onClick={close} className="px-4 py-2 bg-[#121629] text-white rounded">
                                Close
                            </button>
                        </div>
                    </form>
                </div>
    </div>
    );
}

export default UserStoryDetails;