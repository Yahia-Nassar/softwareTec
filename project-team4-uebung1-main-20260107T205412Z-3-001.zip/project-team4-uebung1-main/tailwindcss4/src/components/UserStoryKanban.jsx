import React, { useState, useEffect } from "react";
import { Column, BurnBarrel } from "./Board.jsx";
import SearchFilterSortPanel from "./SearchFilterSortPanel";
import { useParams } from "react-router-dom";
import { notify } from "./Notification.jsx";
import { confirm3 } from "./Confirmbox.jsx";
import { ConfirmDialog } from "primereact/confirmdialog";
import { motion } from "framer-motion";
import ViewSwitch from "./ViewSwitch.jsx";

//Trace: "UserStoryKanban" in https://git.informatik.uni-rostock.de/softwaretechnik-ws-2024-25/uebung1/team4/abgabedokument-sprint-4/-/blob/5f41bdf8c1770d6e342ab58ddca00db73b12077c/Klassendiagramm_Sprint_4.svg

export const UserStoryKanban = ({ sidebarOpen, isKanbanView, onSwitch }) => {
  const { projectId } = useParams();
  const [allCards, setAllCards] = useState([]);
  const [filteredCards, setFilteredCards] = useState([]);
  const [sprints, setSprints] = useState([]);

    useEffect(() => {
        const fetchSprints = async () => {
            try {
                const response = await fetch(`http://localhost:8080/getsprints?projectId=${projectId}`, {
                    method: "GET",
                    credentials: "include",
                });
                if (!response.ok) {
                    throw new Error("Fehler beim Laden der Sprints");
                }
                const data = await response.json();
                const sprintOptions = data.map(sprint => ({
                    label: sprint.sprintname || sprint.name || `Sprint ${sprint.sprintid}`,
                    value: String(sprint.sprintid),
                }));
                setSprints(sprintOptions);
            } catch (error) {
                console.error("Fehler:", error);
            }
        };

        fetchSprints();
    }, [projectId]);

  useEffect(() => {
    fetch(`http://localhost:8080/getuserstories?projectid=${projectId}`, {
      method: "GET",
      credentials: "include",
    })
        .then((response) => {
          if (!response.ok) {
            throw new Error(
                `Fehler beim Laden der User Stories: ${response.status} ${response.statusText}`
            );
          }
          return response.json();
        })
        .then((data) => {
          const updated = data.map((c) => ({
            ...c,
            type: "userStory",
            frontendID: "us-" + c.id,
            sprint: c.sprint !== undefined && c.sprint !== null ? String(c.sprint) : "",
          }));
          setAllCards(updated);
          setFilteredCards(updated);
        })
        .catch((err) => console.error("Fehler:", err));
  }, [projectId]);

  const handleFilteredItems = (items) => setFilteredCards(items);

  return (
      <div className="h-full w-full m-0 p-0">
        <ConfirmDialog />

        <div className="pl-24 p-4 pr-5">
        <SearchFilterSortPanel 
            fields={[
              {
                name: "status",
                type: "select",
                options: [
                  "BACKLOG",
                  "NOT_STARTED",
                  "IN_PROGRESS",
                  "COMPLETED",
                  "INCOMPLETE",
                ],
              },
              {
                name: "priority",
                type: "select",
                options: ["LOW", "MEDIUM", "HIGH"],
              },
              { name: "sprint", type: "select", options: sprints},
            ]}
            getItems={() => allCards}
            onFilteredItems={handleFilteredItems}
        />
        </div>

        <motion.div
            className={`kanban transition ${
                sidebarOpen ? "lanes" : "lanes sidebar-collapsed"
            }`}
            initial={false}
            animate={{
              width: sidebarOpen ? "calc(100% - 225px)" : "calc(100% - 64px)",
            }}
            transition={{ duration: 0.3, ease: "easeInOut" }}
        >
          <Board
              boardType="userStory"
              isKanbanView={isKanbanView}
              onSwitch={onSwitch}
              cards={filteredCards}
              setCards={(newCards) => {
                setAllCards(newCards);
                setFilteredCards(newCards);
              }}
          />
        </motion.div>
      </div>
  );
};

const Board = ({ boardType, isKanbanView, onSwitch, cards, setCards }) => {
  const { projectId } = useParams();
  const [userRole, setUserRole] = useState("");

  useEffect(() => {
    fetch(`http://localhost:8080/getRole?projectid=${projectId}`, {
      method: "GET",
      credentials: "include",
    })
        .then((res) => res.json())
        .then((roleData) => setUserRole(roleData))
        .catch((err) => console.error(err));
  }, [projectId]);

  const handleSave = async () => {
    const hasBurnBarrel = cards.some(
        (c) => c.type === "userStory" && c.status === "BURNBARREL"
    );

    if (hasBurnBarrel && userRole !== "PRODUCT_OWNER") {
      notify.error(
          "Only the Product Owner has permission to delete User Stories"
      );
      return;
    }

    let ok = true;
    if (hasBurnBarrel) ok = await confirm3();
    if (!ok) return;

    const sanitized = cards
        .filter((c) => c.type === "userStory")
        .map(({ frontendId, ...rest }) => rest);

    fetch(`http://localhost:8080/saveUSCards?projectid=${projectId}`, {
      method: "POST",
      credentials: "include",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(sanitized),
    })
        .then((res) => res.json())
        .then(() => notify.success("saved!"))
        .catch((err) => {
          console.error("Fehler:", err);
          notify.error("Error while saving!");
        });
  };

  return (
      <div className="h-window w-full bg #232946 text-neutral-50 m-0 p-0">

        <div className="flex gap-4 px-5 py-0 items-center">
          <ViewSwitch isKanbanView={isKanbanView} onSwitch={onSwitch} />
          <button onClick={handleSave}>Save</button>
        </div>

        <div className="flex flex-wrap h-full w-full gap-8 overflow-hidden p-12">
          <Column
              title="Backlog"
              status="BACKLOG"
              headingColor="text-neutral-200"
              cards={cards}
              setCards={setCards}
              boardType={boardType}
          />
          <Column
              title="Not started"
              status="NOT_STARTED"
              headingColor="text-yellow-200"
              cards={cards}
              setCards={setCards}
              boardType={boardType}
          />
          <Column
              title="In progress"
              status="IN_PROGRESS"
              headingColor="text-blue-200"
              cards={cards}
              setCards={setCards}
              boardType={boardType}
          />
          <Column
              title="Complete"
              status="COMPLETED"
              headingColor="text-violet-400"
              cards={cards}
              setCards={setCards}
              boardType={boardType}
          />
          <Column
              title="Incomplete"
              status="INCOMPLETE"
              headingColor="text-red-500"
              cards={cards}
              setCards={setCards}
              boardType={boardType}
          />
          <BurnBarrel
              status="BURNBARREL"
              cards={cards}
              setCards={setCards}
              boardType={boardType}
          />
        </div>
      </div>
  );
};

export default UserStoryKanban;