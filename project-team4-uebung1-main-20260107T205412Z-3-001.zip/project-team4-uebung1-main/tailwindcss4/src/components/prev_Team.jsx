import React, { useState } from 'react';

function Prev_Team() {

  //Maximum number of characters a member can have
  const MaxMemberCharLength = 60;

  // MemberList:
  const [Member, setMember] = useState([]);
  const [NewMember, setNewMember] = useState("");


  // InputHandler for adding new Members:
  function handleInputChange(event) {
    setNewMember(event.target.value);
  }

  // US08: adds TeamMember if name is not empty or is not over MaxMemberCharLength char long
  function AddMember() {
    if (NewMember.trim() !== "" && NewMember.length <= MaxMemberCharLength) {
      setMember(t => [...t, NewMember]);
      setNewMember("");
      }
    }

  // US09 : delete selected TeamMember through his index
  function DeleteMember(index) {
    const UpdatedMember = Member.filter((_, i) => i !== index);
    setMember(UpdatedMember);
  }

  return (
    <div className="font-black bg-gradient-to-t sm:bg-gradient-to-b md:bg-gradient-to-r lg:bg-gradient-to-l from-pink-600 to-rose-600 w-screen h-screen">
      <div className="team-display pl-4 bg-gradient-to-t sm:bg-gradient-to-b md:bg-gradient-to-r lg:bg-gradient-to-l from-pink-600 to-rose-600 w-screen h-screen">
        
         {/* Title */}
        <h1 className="text-5xl text-[#000000]">Team View</h1>

        {/* Section: add a selected TeamMember */}
        <div className="pt-4 pb-4">
          <label className="block text-zinc-700 font-bold md:text-left mb-1 md:mb-0 pr-4" htmlFor="inline-full-name">
            Add a Member
          </label>
        </div>

        <div className="md:w-2/3 pt-4">
          <input
            type="text"
            placeholder="Name of new Member"
            value={NewMember}
            onChange={handleInputChange}
            className="bg-gray-200 appearance-none border-2 border-gray-200 rounded w-full py-2 px-4 text-gray-700 leading-tight focus:outline-none focus:bg-white focus:border-purple-500"
          />
        </div>

        <div className="pt-4">
          <div className="relative inline-flex group">
            <div className="absolute transition-all duration-1000 opacity-70 -inset-px bg-gradient-to-r from-[#b6ffae] via-[#bfff36] to-[#12ff22] rounded-xl blur-lg group-hover:opacity-100 group-hover:-inset-1 group-hover:duration-200 animate-tilt"></div>

            {/* Button to add TeamMember */}
            <button
              className="relative inline-flex items-center justify-center px-8 py-4 text-lg font-black text-white transition-all duration-200 bg-gray-900 font-pj rounded-xl focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-900"
              onClick={AddMember}
            >
              Add Member
            </button>
          </div>
        </div>

        {/* List of all TeamMembers */}
        <div className="pt-4 md:w-2/3">

          <ol>
            {Member.map((task, index) => (
              <li key={index} className="text-[2rem] font-black bg-[hsl(0,48%,23%)] flex items-center mb-2.5 p-[15px] rounded-[5px] border-[3px] border-solid border-[hsl(0,0%,85%)]">
                <div>
                  <span className="font-black text-white">{task}</span>
                </div>

                {/* Section: delete a selected TeamMember */}
                <div className="relative inline-flex group justify-end">
                  <div className="absolute transition-all duration-1000 opacity-70 -inset-px bg-gradient-to-r from-[#fa5c81] via-[#ff5656] to-[#FF0000] rounded-xl blur-lg group-hover:opacity-100 group-hover:-inset-1 group-hover:duration-200 animate-tilt"></div>

                  {/* Button to delete a selected TeamMember */}
                  <button
                    className="relative inline-flex items-center justify-center px-8 py-4 text-lg font-black text-white transition-all duration-200 bg-gray-900 font-pj rounded-xl focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-900"
                    onClick={() => DeleteMember(index)}
                  >
                    Delete Member
                  </button>
                </div>
              </li>
            ))}
          </ol>
        </div>
      </div>
    </div>
  );
}
export default Prev_Team;