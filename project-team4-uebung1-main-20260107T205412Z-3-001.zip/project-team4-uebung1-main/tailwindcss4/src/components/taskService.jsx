export async function saveTasks(projectId, tasksArray) {
    const response = await fetch(
      `http://localhost:8080/saveTasks?projectid=${projectId}`,
      {
        method: "POST",
        credentials: "include",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(tasksArray),
      }
    );
  
    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Save failed: ${response.status} – ${errorText}`);
    }
  
    return response.json();
  }