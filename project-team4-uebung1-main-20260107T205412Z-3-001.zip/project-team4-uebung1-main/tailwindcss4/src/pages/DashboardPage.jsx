import React, { useState, useEffect } from 'react';
import SidebarLayout from '../components/SidebarLayout';
import { useParams } from 'react-router-dom';
import { Box } from '@mui/material';
import BasicDateCalendar from '../components/BasicDateCalendar';
import ToDoList from '../components/ToDoList';
import TimeComparison from '../components/TimeComparison';
import TaskStatusPieChart from '../components/TaskPieChart';


// Trace: "DashboardPage" in https://git.informatik.uni-rostock.de/softwaretechnik-ws-2024-25/uebung1/team4/abgabedokument-sprint-4/-/blob/5f41bdf8c1770d6e342ab58ddca00db73b12077c/Klassendiagramm_Sprint_4.svg

const DashboardPage = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(null);
  const [error, setError] = useState(null);
  const { projectId } = useParams();
  const [meetings, setMeetings] = useState([]);
  const [tasks, setTasks] = useState([]);
  const [selectedSprint, setSelectedSprint] = useState(1);
  const [sprints, setSprints] = useState([]);

    useEffect(() => {
      const fetchSprints = async () => {
        const res = await fetch(
            `http://localhost:8080/getsprints?projectId=${projectId}`,
            {method: "GET", credentials: "include"}
        );
        if (res.ok) setSprints(await res.json());
      };
      if (projectId) fetchSprints();
    }, [projectId]);

  useEffect(() => {
    fetch(`http://localhost:8080/auth/status?projectid=${projectId}`, {
      credentials: 'include',
      method: 'GET',
    })
      .then((response) => {
        if (!response.ok) {
          throw new Error(`HTTP-Fehler ${response.status}: ${response.statusText}`);
        }
        return response.json();
      })
      .then((data) => {
        setIsAuthenticated(data.isAuthenticated);
      })
      .catch((err) => {
        console.error('Fehler beim Abrufen des Authentifizierungsstatus:', err);
        setError(`Fehler beim Abrufen des Authentifizierungsstatus: ${err.message}`);
      });
  }, []);

  useEffect(() => {
    if (isAuthenticated) {
      fetch(`http://localhost:8080/getmeetings?projectid=${projectId}`, {
        credentials: 'include',
        method: 'GET'
      })
        .then((response) => {
          if (!response.ok) {
            throw new Error(`HTTP-Fehler ${response.status}: ${response.statusText}`);
          }
          return response.json();
        })
        .then((data) => {
          setMeetings(data);
        })
        .catch((err) => {
          console.error('Fehler beim Abrufen der Meetings:', err);
          setError(`Fehler beim Abrufen der Meetings: ${err.message}`);
        });
    }
  }, [isAuthenticated, projectId]);

  useEffect(() => {
    if (isAuthenticated && projectId) {
      fetch(`http://localhost:8080/gettasks?projectid=${projectId}`, {
        credentials: 'include',
      })
        .then((res) => res.json())
        .then((data) => {
          console.log("Tasks geladen:", data);
          setTasks(data.filter(task => task.type === "task")); // optionaler Filter
        })
        .catch((err) => console.error("Fehler beim Laden der Tasks:", err));
    }
  }, [isAuthenticated, projectId]);
    
    if (error) {
      return <div style={{ color: 'red' }}>Error: {error}</div>;
    }

  if (error) {
    return <div>{error}</div>;
  }

  if (isAuthenticated === null) {
    return <div>Lade Authentifizierungsstatus...</div>;
  }

  if (isAuthenticated) {
    return (
      <SidebarLayout> 
        <Box display="flex" width="100%" gap={2} alignItems="flex-start">
          <Box flex={2} mt={4} display="flex" flexDirection="column" gap={2}>
          <h1 style={{ fontSize: "1.8rem", fontWeight: "bold", color: "white" }}>
            My Dashboard
          </h1>

            <select
                value={selectedSprint}
                onChange={(e) => setSelectedSprint(Number(e.target.value))}
                className="bg-[#121629] text-white p-2 rounded"
            >
              <option value={1}>unsorted</option>
              {sprints
                  .filter((s) => s.sprintid !== 1)
                  .map((s) => (
                      <option key={s.sprintid} value={s.sprintid}>
                        {s.name || `Sprint ${s.sprintid}`}
                      </option>
                  ))}
            </select>

            <ToDoList projectId={projectId} sprintId={selectedSprint}/>
            <Box mt={4}>
              <TimeComparison projectId={projectId} sprintId={selectedSprint}/>
            </Box>
          </Box>
          <Box display="flex" mt={8} flexDirection="column" gap={2} width="fit-content">
          <Box sx={{ border: '1px solid transparent', borderRadius: 2, p: 2 }}>
            <BasicDateCalendar events={meetings} />
          </Box>
          <Box sx={{ border: '1px solid transparent', borderRadius: 2, p: 2 }}>
            <TaskStatusPieChart projectId={projectId} sprintId={selectedSprint} />
          </Box>
          </Box>
        </Box>
      </SidebarLayout>
    );
    } else {
      window.location.href = 'http://localhost:8080/req/login';
      return null;
    }};

export default DashboardPage;