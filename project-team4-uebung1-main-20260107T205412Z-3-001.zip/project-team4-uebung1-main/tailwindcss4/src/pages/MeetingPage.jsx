import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import SidebarLayout from '../components/SidebarLayout';
import { Box } from '@mui/material';
import BasicDateCalendar from '../components/BasicDateCalendar';
import dayjs from 'dayjs';
import EditMeeting from '../components/EditMeeting';
import DeleteMeeting from '../components/DeleteMeeting';
import { notify } from '../components/Notification';

const MeetingPage = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(null);
  const [error, setError] = useState(null);
  const [meetings, setMeetings] = useState([]);
  const [newMeetings, setNewMeetings] = useState([]);
  const [singleMeeting, setSingleMeeting] = useState({ description: '', date: '', time: '', participants: [] });
  const [showModal, setShowModal] = useState(false);
  const [participant, setParticipant] = useState('');
  const [allMembers, setAllMembers] = useState([]);

  const { projectId } = useParams();

  useEffect(() => {
    fetch(`http://localhost:8080/auth/status?projectid=${projectId}`, {
      credentials: 'include',
      method: 'GET',
    })
      .then((response) => {
        if (!response.ok) {
          throw new Error(`HTTP-Fehler ${response.status}: ${response.statusText}`);
        }
        return response.json();
      })
      .then((data) => {
        setIsAuthenticated(data.isAuthenticated);
      })
      .catch((err) => {
        console.error('Fehler beim Abrufen des Authentifizierungsstatus:', err);
        setError(`Fehler beim Abrufen des Authentifizierungsstatus: ${err.message}`);
      });
  }, [projectId]);

  useEffect(() => {
    if (!isAuthenticated) return;

    fetch(`http://localhost:8080/getmeetings?projectid=${projectId}`, {
      credentials: 'include',
      method: 'GET',
    })
        .then((response) => {
          if (!response.ok) {
            throw new Error(`HTTP-Fehler ${response.status}: ${response.statusText}`);
          }
          return response.json();
        })
        .then((data) => {
          setMeetings(data);
        })
        .catch((err) => {
          console.error('Error fetching meetings:', err);
          setError(`Error fetching meetings: ${err.message}`);
        });
  }, [isAuthenticated, projectId]);

  useEffect(() => {
    if (isAuthenticated) {
      fetch(`http://localhost:8080/getprojectusers?projectid=${projectId}`, {
        credentials: 'include',
        method: 'GET',
      })
        .then((response) => {
          if (!response.ok) throw new Error("Error fetching project members");
          return response.json();
        })
        .then((data) => setAllMembers(data))
        .catch((err) => {
          console.error("Error fetching project members:", err);
          setError(`Error fetching project members: ${err.message}`);
        });
    }
  }, [isAuthenticated, projectId]);
  

  const handleOpenNewMeetingModal = (clickedDay) => {
    setSingleMeeting((prev) => ({
      ...prev,
      date: dayjs(clickedDay).format('YYYY-MM-DD'),
    }));
    setShowModal(true);
  };

  const handleAddSingleMeeting = (e) => {
    e.preventDefault();
    setNewMeetings([...newMeetings, singleMeeting]);
    setShowModal(false);
    setSingleMeeting({ description: '', date: '', time: '', participants: [] });
  };

  const handleSaveAllMeetings = () => {
    if (newMeetings.length === 0) {
      alert("No new meetings to save.");
      return;
    }
    fetch(`http://localhost:8080/createmeeting?projectid=${projectId}`, {
      credentials: 'include',
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newMeetings)
    })
      .then((response) => {
        if (!response.ok) {
          throw new Error(`HTTP-Fehler ${response.status}: ${response.statusText}`);
        } 
        
        return response.json();
       
      })
      .then((savedMeetings) => {
        notify.success("Meetings saved successfully.");
        setMeetings(savedMeetings);
        setNewMeetings([]);
      })
      .catch((err) => {
        console.error('Error while creating meeting:', err);
        setError(`Error while creating meeting: ${err.message}`);
      });
  };

  if (error) {
    return <div className="text-red-600 p-4">{error}</div>;
  }

  if (isAuthenticated === null) {
    return <div className="p-4">Lade Authentifizierungsstatus...</div>;
  }

  if (!isAuthenticated) {
    window.location.href = 'http://localhost:8080/req/login';
    return null;
  }

  if (error) {
    return <div className="text-red-600 p-4">{error}</div>;
  }
  if (isAuthenticated === null) {
    return <div className="p-4">Lade Authentifizierungsstatus...</div>;
  }
  if (!isAuthenticated) {
    window.location.href = 'http://localhost:8080/req/login';
    return null;
  }
  return (
    <SidebarLayout>
      <Box display="flex" width="100%" gap={2}>
        <Box className="p-4" flex={1} sx={{ border: '1px solid transparent', borderRadius: 2 }}>
          <h2 className="text-xl font-bold mb-2">Current Meetings:</h2>
          <ul className="space-y-2 mb-6">
            {meetings.map((m) => (
              <li key={m.meetingId} className="p-2 border-transparent bg-[#121629] rounded text-white flex items-center justify-between">
                <div>
                  <div>MeetingID: {m.meetingId}</div>
                  <div>Description: {m.description}</div>
                  <div>Date: {m.date}</div>
                  <div>Time: {m.time}</div>
                </div>
                <div className="flex gap-2">
                  <EditMeeting meeting={m} setMeetings={setMeetings} projectId={projectId} loseModal={() => setShowModal(false)}/>
                  <DeleteMeeting meeting={m} setMeetings={setMeetings} projectId={projectId} closeModal={() => setShowModal(false)} />
                </div>
              </li>
            ))}
          </ul>

          {newMeetings.length > 0 && (
            <>
              <h2 className="text-xl font-bold mb-2">Not saved meetings:</h2>
              <ul className="space-y-2 mb-6">
                {newMeetings.map((nm, idx) => (
                  <li key={idx} className="p-2 border-transparent bg-[#121629] rounded text-white">
                    <div>Description: {nm.description}</div>
                    <div>Date: {nm.date}</div>
                    <div>Time: {nm.time}</div>
                  </li>
                ))}
              </ul>
            </>
          )}

          <div className="flex gap-4">
            <button
              onClick={() => setShowModal(true)}
              className="px-4 py-2 rounded"
            >
              Add Meeting
            </button>
            <button
              onClick={handleSaveAllMeetings}
              className="px-4 py-2 rounded"
            >
              Save
            </button>
          </div>

          {showModal && (
            <div className="fixed inset-0 flex items-center justify-center bg-[#121629]/80 p-4 z-50">
              <div className="bg-[#232946] p-6 w-100 rounded shadow-md text-white">
                <h2 className="text-xl font-bold mb-4">Add Meeting</h2>
                <form onSubmit={handleAddSingleMeeting} className="flex flex-col space-y-4">
                  <input
                    type="text"
                    className="border border-transparent p-2 bg-[#121629] rounded"
                    placeholder="Description"
                    value={singleMeeting.description}
                    onChange={(e) => setSingleMeeting({ ...singleMeeting, description: e.target.value })}
            
                    required
                  />
                  <input
                    type="date"
                    className="border border-transparent p-2 bg-[#121629] rounded"
                    value={singleMeeting.date}
                    onChange={(e) =>
                      setSingleMeeting({ ...singleMeeting, date: e.target.value })
                    }
                    required
                  />
                  <input
                    type="time"
                    className="border border-transparent p-2 bg-[#121629] rounded"
                    value={singleMeeting.time}
                    onChange={(e) =>
                      setSingleMeeting({ ...singleMeeting, time: e.target.value })
                    }
                    required
                  />
                  <select
                    multiple
                    value={singleMeeting.participants}
                    onChange={(e) => {
                      const selected = Array.from(e.target.selectedOptions, (opt) => opt.value);
                      if (selected.includes("__all__")) {
                        const emailsOnly = allMembers.map((user) => user.email);
                        setSingleMeeting((prev) => ({ ...prev, participants: emailsOnly }));
                      } else {
                        setSingleMeeting((prev) => ({ ...prev, participants: selected }));
                      }
                    }}
                    
                    
                    className="bg-[#121629] text-white p-2 rounded"
                  >
                    <option value="__all__">All members</option>
                      {allMembers.map((user) => (
                        <option key={user.email} value={user.email}>
                          {user.username} ({user.email})
                        </option>
                      ))}
                  </select>
                  <div>
                    Participants:{' '}
                    {Array.isArray(singleMeeting.participants) && singleMeeting.participants.length > 0
                      ? singleMeeting.participants.map((email) => {
                          const user = allMembers.find((u) => u.email === email);
                          return user ? `${user.username} (${user.email})` : email;
                        }).join(', ')
                      : 'None'}
                  </div>


                  <div className="flex justify-end">
                    <button
                      type="button"
                      onClick={() => setShowModal(false)}
                      className="mr-2 px-4 py-2 bg-gray-300 text-black rounded"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
                    >
                      Add
                    </button>
                  </div>
                </form>
              </div>
            </div>
          )}
        </Box>
        <Box sx={{ border: '1px solid transparent', borderRadius: 2, p: 2, width: 'fit-content' }}>
          <BasicDateCalendar
            events={meetings} 
            onOpenMeetingModal={handleOpenNewMeetingModal}
          />
        </Box>
      </Box>
    </SidebarLayout>
  );
};

export default MeetingPage;