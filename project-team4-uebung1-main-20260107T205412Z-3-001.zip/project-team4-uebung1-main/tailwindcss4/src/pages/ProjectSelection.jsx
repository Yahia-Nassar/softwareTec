import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import NewProjectPopup from '../components/NewProjectPopup';
import SearchFilterSortPanel from '../components/SearchFilterSortPanel';

function ProjectSelection() {
  const [isAuthenticated, setIsAuthenticated] = useState(null);
  const [projects, setProjects] = useState([]);
  const [filteredProjects, setFilteredProjects] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    fetch('http://localhost:8080/auth/status', { credentials: 'include' })
        .then((r) => {
          if (!r.ok) throw new Error();
          return r.json();
        })
        .then((d) => setIsAuthenticated(d.isAuthenticated))
        .catch(() => setError('Fehler beim Abrufen des Authentifizierungsstatus'));
  }, []);

  useEffect(() => {
    fetch('http://localhost:8080/getprojects', { credentials: 'include' })
        .then((r) => {
          if (!r.ok) throw new Error();
          return r.json();
        })
        .then((data) => {
          const list = data.map((p) => ({ ...p, title: p.name }));
          setProjects(list);
          setFilteredProjects(list);
        })
        .catch(() => setError('Fehler beim Abrufen der Projekte'));
  }, []);

  const handleProjectClick = (id) => navigate(`/${id}/dashboard`);

  const handleCreateProject = (name) => {
    fetch('http://localhost:8080/createproject', {
      method: 'POST',
      credentials: 'include',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name }),
    })
        .then((r) => {
          if (!r.ok) throw new Error();
          return r.json();
        })
        .then((data) => {
          const newProj = { ...data, title: data.name };
          const updated = [...projects, newProj];
          setProjects(updated);
          setFilteredProjects(updated);
        })
        .catch(() => setError('Fehler beim Erstellen des Projekts'));
  };

  if (isAuthenticated === null) return <div>Lade Authentifizierungsstatus...</div>;

  if (!isAuthenticated) {
    window.location.href = 'http://localhost:8080/req/login';
    return null;
  }

  return (
      <div
          style={{
            backgroundColor: '#232946',
            minHeight: '100vh',
            width: '100%',
            padding: '20px',
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
          }}
      >
        <header
            style={{
              fontFamily: 'Inter, sans-serif, bold',
              color: 'white',
              textAlign: 'left',
            }}
        >
          <h1>Select your project</h1>
          {error && <p style={{ color: 'red' }}>{error}</p>}
        </header>

        <div style={{marginTop: '30px' }}>
          <SearchFilterSortPanel
            fields={[]}
            getItems={() => projects}
            onFilteredItems={setFilteredProjects}
        />
        </div>
        

        <div
            style={{
              width: '100%',
              maxWidth: '600px',
              marginTop: '20px',
              display: 'flex',
              flexDirection: 'column',
              gap: '10px',
              maxHeight: '600px',
              overflowY: 'auto',
            }}
        >
          {filteredProjects.map((project) => (
              <button
                  key={project.id}
                  onClick={() => handleProjectClick(project.id)}
                  style={{
                    width: '100%',
                    backgroundColor: 'white',
                    color: '#232946',
                    border: 'none',
                    padding: '15px',
                    borderRadius: '5px',
                    textAlign: 'left',
                    fontSize: '16px',
                    cursor: 'pointer',
                  }}
              >
                {project.name}
              </button>
          ))}
          
        </div>
        <div style={{ maxWidth: '600px', width: '100%', marginTop: '10px' }}>
    <NewProjectPopup onCreate={handleCreateProject} />
  </div>
</div>
  );
}

export default ProjectSelection;