import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Team from '../components/Team.jsx';
import SidebarLayout from '../components/SidebarLayout';

const TeamPage = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(null);
  const [error, setError] = useState(null);
  const navigate = useNavigate();  // useNavigate Hook

  // Authentication:
  useEffect(() => {
    fetch('http://localhost:8080/auth/status', {
      credentials: 'include',
    })
      .then((response) => {
        if (!response.ok) {
          throw new Error(`HTTP-Fehler ${response.status}: ${response.statusText}`);
        }
        return response.json();
      })
      .then((data) => {
        setIsAuthenticated(data.isAuthenticated);
      })
      .catch((err) => {
        console.error('Fehler beim Abrufen des Authentifizierungsstatus:', err);
        setError(`Fehler beim Abrufen des Authentifizierungsstatus: ${err.message}`);
      });
  }, []);

  if (error) {
    return <div>{error}</div>;
  }
  // wait for authentication to finish
  if (isAuthenticated === null) {
    return <div>Lade Authentifizierungsstatus...</div>;
  }

  if (isAuthenticated) {
    return (
      <SidebarLayout>
        <div className="Inhalt">
        <Team />
      </div>
      </SidebarLayout>
    );
  } else {
    window.location.href = 'http://localhost:8080/req/login';
  }
};

export default TeamPage;