import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import SidebarLayout from '../components/SidebarLayout';
import USView from '../components/USView';

const USViewPage = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(null);
  const [error, setError] = useState(null);
  const { projectId } = useParams();

  useEffect(() => {
    fetch(`http://localhost:8080/auth/status?projectid=${projectId}`, {
      credentials: 'include',
      method: 'GET',
    })
      .then((response) => {
        if (!response.ok) {
          throw new Error(`HTTP-Fehler ${response.status}: ${response.statusText}`);
        }
        return response.json();
      })
      .then((data) => {
        setIsAuthenticated(data.isAuthenticated);
      })
      .catch((err) => {
        console.error('Fehler beim Abrufen des Authentifizierungsstatus:', err);
        setError(`Fehler beim Abrufen des Authentifizierungsstatus: ${err.message}`);
      });
  }, [projectId]);

  if (error) {
    return <div>{error}</div>;
  }

  if (isAuthenticated === null) {
    return <div>Lade Authentifizierungsstatus...</div>;
  }

  if (isAuthenticated) {
    return (
      <SidebarLayout>
        <USView />
      </SidebarLayout>
    );
  } else {
    window.location.href = 'http://localhost:8080/req/login';
  }
};

export default USViewPage;